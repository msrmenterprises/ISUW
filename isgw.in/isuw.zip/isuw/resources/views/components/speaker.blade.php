@extends('master')
@section('content')
<section class="page-section pt-pb-100 bg-white">
         <div class="container">
            		
               <h2 style="color:#f60;" >ISUW Speakers</h2>			    
           <p></p>
            <div class="row justify-content-left ">
			@foreach ($speakers as $speaker)
			@if ($speaker->isActive==1)
               <div class="col-lg-3 ">
		         <div class="logo-div">
                  <div class="sprk-box sprk-detail">
                     <img src="{{$speaker->imageUrl}}" class="img-fluid " alt="{{$speaker->imageAlt}}">
                     <h5>{{$speaker->name}}</h5>
                     <p>{{$speaker->company}}</p>
                     <p><a  href="/speaker/{{$speaker->id}}" class="text-warning">Read bio...</a></p>
                  </div>
				  </div>
                  </div>	
				  @endif
				  @endforeach			 
            </div>
         </div>
      </section>
@endsection