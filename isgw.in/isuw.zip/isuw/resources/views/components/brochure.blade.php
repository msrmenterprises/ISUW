@extends('master')
@section('content')

 <div class="container">
 <div class="row justify-content-left ">
<p></p>


<h2 style="color: #f60;margin-left: 55px;">ISUW 2021 Brochure</h2>
<iframe src="https://www.isgw.in/uploads/images/Final-Brochure-ISUW-2021-1.pdf" height="600" width="150" title="Iframe Example" style="
    width: 800px;
    text-align: center;
    margin-left: 67px;
"></iframe>

<p></p>
</div>
</div>

@endsection
