@extends('master')
@section('content')

 <div class="container">
 <div class="row justify-content-left ">
<p></p>

<h2 style="color: #f60;">ISUW 2021 EXHIBITORS</h2>



<div class="col-lg-3"><div class="logo-div"><a href="http://www.slscorp.com/" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2021/02/SLS.jpg" alt="" width="213" height="102" style="width:95%"></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://www.bsesdelhi.com/web/bypl#loaded" target="_blank" rel="noopener noreferrer"><img style="margin: 0 auto; height: 44px; margin-top: 27px;" src="http://www.isgw.in/wp-content/uploads/2018/02/BYPL.gif" alt=""></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://www.bsesdelhi.com/web/brpl" target="_blank" rel="noopener noreferrer"><img style="margin: 0 auto; height: 50px; width: 151px; margin-top: 23px;" src="http://www.isgw.in/wp-content/uploads/2019/01/rajdhani.jpg" alt=""></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="http://www.tatapower-ddl.com/" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2017/04/82e95c5adb5b4433b0c9d63f77396e63.jpg" alt="" width="213" height="102"></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://www.tatapower.com/" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2019/01/Tata-Power-Stacked-Logo-blue-01.jpg" style="margin-top:-10px;"></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="http://www.fluentgrid.com/" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2020/02/Fluentgrid-logoTM.jpg" alt="" width="213" height="102"></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="http://www.g3-plc.com/home/" target="_blank" rel="noopener noreferrer"><img style="width: 150px; padding: 25px;" src="http://www.isgw.in/wp-content/uploads/2017/12/logo-G3.png" alt="" width="213" height="102"></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://indiasmartgrid.org/" target="_blank" rel="noopener noreferrer"><img style="width: 150px; padding: 25px;" src="http://www.isgw.in/wp-content/uploads/2021/01/ISGF-LOGO-HD.jpg" alt="" width="213" height="102"></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://www.sap.com/india/index.html" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2020/01/SAP_Best_R_grad_blk.png" alt=""></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://wi-sun.org/" target="_blank" rel="noopener noreferrer"><img style="width: 150px; padding: 25px;" src="http://www.isgw.in/wp-content/uploads/2019/02/wisun.png" alt="" width="213" height="102"></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://www.hms-networks.com/" target="_blank" rel="noopener noreferrer"><img style="width: 180px; padding: 25px; height=60px;" src="http://www.isgw.in/wp-content/uploads/2021/02/HMS_logo_with_tagline.png" alt="" width="180" height="102"></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="http://ulepl.com/" target="_blank" rel="noopener noreferrer"><img style="width: 138px;padding: 0px;height: 115px;" src="http://www.isgw.in/wp-content/uploads/2021/02/UL-Group-Logo-Transperant.png" alt="" width="213" height="102"></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://www.cuculus.net/en/" target="_blank" rel="noopener noreferrer"><img style="width: 189px;padding: 0px;height: 115px;" src="http://www.isgw.in/wp-content/uploads/2021/02/CUCULAS.png" alt="" width="213" height="102"></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://subhasree.in/" target="_blank" rel="noopener noreferrer"><img style="width: 180px;height: 115px;" src="http://www.isgw.in/wp-content/uploads/2021/02/Subhasree.png"></a> </div></div>																																							
<div class="col-lg-3"><div class="logo-div"><a href="https://www.sew.ai/" target="_blank" rel="noopener noreferrer"><img style="width: 150px; padding: 25px;" src="http://www.isgw.in/wp-content/uploads/2021/02/SEW-Logo.png" alt="" width="213" height="102"></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://www.nokia.com/" target="_blank" rel="noopener noreferrer"><img style="width: 150px; padding: 25px;" src="http://www.isgw.in/wp-content/uploads/2019/03/NOKIA_LOGO_RGB_LR.png" alt="" width="213" height="102"></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://www.altec.com/" target="_blank" rel="noopener noreferrer"><img style="width: 150px; padding: 25px;" src="http://www.isgw.in/wp-content/uploads/2021/02/Altec-black-w-124.jpg" alt="" width="213" height="102"></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://bescom.co.in/SCP/Myhome.aspx" target="_blank" rel="noopener noreferrer"><img style="width: 150px;" src="http://www.isgw.in/wp-content/uploads/2019/02/BESCOM-1.jpg" alt="" width="213" height="102"></a> </div></div>		
<div class="col-lg-3"><div class="logo-div"><a href="https://waterfall-security.com/" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2021/02/WF_Logo_442X136-nm6rry2dnkbngs1r2h0a2n4q6hc9d4gk3wgtshj1mo.jpg"></a> </div></div>		
<div class="col-lg-3"><div class="logo-div"><a href="https://addgrup.com/" target="_blank" rel="noopener noreferrer"><img style="width: 150px;" src="http://www.isgw.in/wp-content/uploads/2021/02/logo-640x640-1.png"></a> </div></div>	
<div class="col-lg-3"><div class="logo-div"><a href="https://www.igef.net/" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2021/02/igef_logo.jpg"></a> </div></div>	
<div class="col-lg-3"><div class="logo-div"><a href="https://aws.amazon.com/" target="_blank" rel="noopener noreferrer"><img style="width: 150px;height: 120px;" src="http://www.isgw.in/wp-content/uploads/2021/02/AWS_logo_RGB.png"></a> </div></div>
<div class="col-lg-3"><div class="logo-div"><a href="http://www.anvilcables.com/" target="_blank" rel="noopener noreferrer"><img style="width: 180px;height: 115px;" src="http://www.isgw.in/wp-content/uploads/2021/02/anvil.jpg"></a> </div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://yitran.com/" target="_blank" rel="noopener noreferrer"><img style="width: 180px;height: 115px;" src="http://www.isgw.in/wp-content/uploads/2021/02/Yitran-logo-2.jpg"></a> </div></div>	
<div class="col-lg-3"><div class="logo-div"><a href="https://www.tabreed.ae/" target="_blank" rel="noopener noreferrer"><img style="width: 180px;height: 115px;" src="http://www.isgw.in/wp-content/uploads/2021/02/TABREED-India.png"></a> </div></div>																																							
<div class="col-lg-3"><div class="logo-div"><a href="http://www.mpwz.co.in/" target="_blank" rel="noopener noreferrer"><img style="width: 180px;height: 115px;" src="https://www.isgw.in/wp-content/uploads/2021/02/MPPKVVCL-logo_Partner-Utility-1.jpg"></a> </div></div>		
<div class="col-lg-3"><div class="logo-div"><a href="https://www.tsecl.in/irj/go/km/docs/internet/TRIPURA/webpage/pages/Home.html" target="_blank" rel="noopener noreferrer"><img style="width: 180px;height: 115px;" src="https://www.isgw.in/wp-content/uploads/2021/02/Tripura.jpg"></a> </div></div>																																																																												





<p></p>
</div>
</div>

@endsection