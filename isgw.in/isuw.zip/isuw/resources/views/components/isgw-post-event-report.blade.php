@extends('master')
@section('content')

 <div class="container">
 <div class="row justify-content-left ">
<p></p>
<h3 style="color: #f60;">ISUW 2021 Post Event Report</h3>
<p></p>
<iframe src="/uploads/images/Post Event Report (ISUW 2021).pdf" height="600" width="150" title="Iframe Example" style="
    width: 800px;
    text-align: center;
    margin-left: 67px;
"></iframe>

<p></p>
</div>
</div>

@endsection
