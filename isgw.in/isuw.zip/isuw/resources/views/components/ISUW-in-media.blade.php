@extends('master')
@section('content')

 <div class="container">
 <div class="row justify-content-left ">
<p></p>

<table align="left" cellspacing="0" border="0" style="width:100%">
	
	<tr>
		<td style="border-bottom: 1px solid #000000" colspan=8 height="31" align="center" valign=bottom bgcolor="#92D050"><font size=5 color="#000000">ISUW IN MEDIA</td>
		</tr>
			
					<tr>
						<td width="5%"style="align: left" valign=middle bgcolor="#00b050"><font face="Georgia" color="#000000">S.No</td>
						<td width="5%" style="align: left" valign=middle bgcolor="#00b050"><font face="Georgia" color="#000000">News Category</td>
						<td width="10%" style="align: left" valign=middle bgcolor="#00b050"><font face="Georgia" color="#000000">Outlet and <br/>Journalist Name</td>
						<td width="10%" style="align: left" valign=middle bgcolor="#00b050"><font face="Georgia" color="#000000">Media Type </td>
						<td width="20%" style="align: left" valign=middle bgcolor="#00b050"><font face="Georgia" color="#000000">Link</td>
						<td width="10%" style="align: left" valign=middle bgcolor="#00b050"><font face="Georgia" color="#000000">News Headline</td>
						<td width="10%" style="align: left" valign=middle bgcolor="#00b050"><font face="Georgia" color="#000000">Media Category</td>
						<td width="5%" style="align: left" valign=middle bgcolor="#00b050"><font face="Georgia" color="#000000">Industry</td>
					</tr>

	<tr>
		<td>1</td>
		<td>ISUW 2021</font></td>
		<td>Tripura Chronical</font></td>
		<td>Online</font></td>
		<td><u><font color="#0563C1"><a href="https://tripurachronicle.in/Tripura/tsecl-bags-gold-award-for-of-india-smart-grid-forum-isgf-innovation-awards-2021-22712.cms">https://tripurachronicle.in/Tripura/tsecl-bags
		-gold-award-for-of-india-smart-grid-forum-
		isgf-innovation-awards-2021-22712.cms</a></font></u></td>
		<td>India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Energy and Natural Resources</font></td>
	</tr>
	<tr>
		<td>2</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">swisscrypto
		blockchain 
		(swisscryptoblo1)</font></td>
		<td>Social Media</font></td>
		<td><font face="Arial">http://twitter.com/swisscryptoblo1/statuses/1352034179710545922</font></td>
		<td><font face="Arial">165 followers</font></td>
		<td><font face="Arial">2021-01-20 23:24:02</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>3</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">CleanAcres (CleanAcresCTC)</font></td>
		<td>Social Media</font></td>
		<td><font face="Arial">http://twitter.com/CleanAcresCTC/statuses/1351750813677309952</font></td>
		<td><font face="Arial">351 followers</font></td>
		<td><font face="Arial">2021-01-20 04:38:02</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>4</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Energy Central</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://energycentral.com/</font></td>
		<td><font face="Arial">   United States</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Energy and Natural Resources</font></td>
	</tr>
	<tr>
		<td>5</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">HT Syndication</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://www.htsyndication.com/pr-newswire
		/article/isgf-announces-the-7th-edition-of-india-smart-utility
		-week-2021%2c-an-international-conference-and-exhibition-on-smart
		-energy-and-smart-mobility-for-smarter-cities-from-02---05-march-2021/48254756</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">News &amp; Information Service</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>6</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Indian Spectator</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://indianspectator.com/prnewswire/?
		rkey=20210119EN52789&amp;filter=21881</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>7</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Webindia123.com</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://news.webindia123.com/news/
		press_showdetailsPR.asp?id=1179824</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Trade Publications</font></td>
		<td><font face="Arial">Financial</font></td>
	</tr>
	<tr>
		<td>8</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td>Latestly</font></td>
		<td>Online</font></td>
		<td><u><font color="#0563C1"><a href="https://startupsuccessstories.in/isgf-announces-the-7th-edition-of
		-india-smart-utility-week-2021-an-international-conference-and-exhibition-on-smart-energy-and-smart-
		mobility-for-smarter-cities-from-02-05-march-2021/">https://startupsuccessstories.in/isgf-announces-the-
		7th-edition-of-india-smart-utility-week-2021-an-international-conference-and-exhibition-on-smart-energy-
		and-smart-mobility-for-smarter-cities-from-02-05-march-2021/</a></font></u></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>9</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td>Latestly</font></td>
		<td>Online</font></td>
		<td><u><font color="#0563C1"><a href="https://www.latestly.com/agency-news/business-news-isgf-announces-the-7th-edition-of-india-smart-utility-week-2021-an-international-conference-and-exhibition-on-smart-energy-and-smart-mobility-for-smarter-cities-from-02-05-march-202-2276067.html">https://www.latestly.com/agency-news/business-news-isgf-announces-the-7th-edition-of-india-smart-utility-week-2021-an-international-conference
		-and-exhibition-on-smart-energy-and-smart-mobility-for-smarter-cities-from-02-05-march-202-2276067.html</a></font></u></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>10</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">5 Dariya News</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://www.5dariyanews.com/Full-Story-Latest-from-PR-Newswire.aspx?rkey=20210119EN52789&amp;filter=3325</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>11</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Abhitak News [English]</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://www.abhitaknews.com/english/news/press-releases.aspx?rkey=20210119EN52789&amp;filter=1889</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">News &amp; Information Service</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>12</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Accommodation Times</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://accommodationtimes.com/pr-newswire/?rkey=20210119EN52789&amp;filter=18279</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Real Estate</font></td>
	</tr>
	<tr>
		<td>13</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Asianbuck</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://www.asianbuck.com/asianbuck-prnews/?rkey=20210119EN52789&amp;filter=8421</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>14</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">B Live News</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://b-live.in/prnewswire/?rkey=20210119EN52789&amp;filter=18861</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>15</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Bangalore Waves</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://www.bangalorewaves.com/news/bangalorewaves-business-news.php?rkey=20210119EN52789&amp;filter=2267</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">News &amp; Information Service</font></td>
		<td><font face="Arial">Tech</font></td>
	</tr>
	<tr>
		<td>16</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Biharprabha News</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://news.biharprabha.com/prnewswire
		/?rkey=20210119EN52789&amp;filter=2270</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">News &amp; Information Service</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>17</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Biz Wire Express</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://www.bizwireexpress.com/showstoryPRN.php?rkey=20210119EN52789&amp;filter=2276</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">News &amp; Information Service</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>18</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">BizNext India</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://www.biznextindia.com/pr-newswire/
		?rkey=20210119EN52789&amp;filter=19403</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>19</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Business News 
		This Week</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://businessnewsthisweek.com/prnews/
		?rkey=20210119EN52789&amp;filter=601</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>20</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Business Sandesh</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://www.businesssandesh.in/breaking-news/?rkey=20210119EN52789&amp;filter=7621</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>21</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Business Today
		India</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://www.businesstoday.in/prnewswire/?rkey=20210119EN52789&amp;filter=2418</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Trade Publications</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>22</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">City Air News</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://cityairnews.com/content/pr-newswire?rkey=20210119EN52789&amp;filter=1968</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>23</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Crack of Dawn</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://crackofdawn.in/press-release/?rkey=20210119EN52789&amp;filter=20900</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>24</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">CurrentNew</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://currentnew.in/prnewswire/?rkey=20210119EN52789&amp;filter=21269</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Business Services</font></td>
	</tr>
	<tr>
		<td>25</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Dalal Street Investment Journal</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://www.dsij.in/newswiredetails.aspx?FileName=202101192330PR_NEWS_EURO_ND__EN52789</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Financial Data, Research &amp; Analytics</font></td>
		<td><font face="Arial">Financial</font></td>
	</tr>
	<tr>
		<td>26</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">First Report</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://firstreport.in/pr-newswire/?rkey=20210119EN52789&amp;filter=6490</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>27</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Global Prime 
		News</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://globalprimenews.com/prnewswire/?rkey=20210119EN52789&amp;filter=19416</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>28</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Green Lichen</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://greenlichen.com/pr-newswire/?rkey=20210119EN52789&amp;filter=15918</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Environment</font></td>
	</tr>
	<tr>
		<td>29</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">GroundReport</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://groundreport.in/pr-news-english-2/?rkey=20210119EN52789&amp;filter=20940</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>30</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Hello Mumbai</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://www.hellomumbainews.com/hello-business/?rkey=20210119EN52789&amp;filter=12313</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>31</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">IANS [Indo-Asian News Service]</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://ians.in/index.php?param=prnewswiredetail/PRN-1100904</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">News &amp; Information Service</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>32</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">IBG News</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://ibgnews.com/pr-newswire-news/?rkey=20210119EN52789&amp;filter=19585</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>33</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">IBTN9</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://ibtn9.com/pr-newswire/?rkey=20210119EN52789&amp;filter=12202</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>34</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">India Briefing</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://www.india-briefing.com/news/partnernews/?rkey=20210119EN52789&amp;filter=3400</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Financial</font></td>
	</tr>
	<tr>
		<td>35</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">India Editor</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://www.indiaeditor.com/corporate-pr-news/?rkey=20210119EN52789&amp;filter=20728</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>36</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">India Herald</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://www.indiaherald.com/prnewswire?rkey=20210119EN52789&amp;filter=18307</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>37</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">India Online</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://news.indiaonline.in/prnewswire?rkey=20210119EN52789&amp;filter=4991</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>38</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">India Today</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://www.indiatoday.in/pr-newswire?rkey=20210119EN52789&amp;filter=4315</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Magazine</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>39</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Indian Nerve</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://indiannerve.com/in-press/?rkey=20210119EN52789&amp;filter=6492</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">News &amp; Information Service</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>40</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Indian Power 
		Sector</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://indianpowersector.com/prnews/?rkey=20210119EN52789&amp;filter=4997</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Trade Publications</font></td>
		<td><font face="Arial">Energy and Natural Resources</font></td>
	</tr>
	<tr>
		<td>41</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Indore Dil Se</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://indoredilse.com/english-news/?rkey=20210119EN52789&amp;filter=10474</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>42</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Insight Online
		News</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://insightonlinenews.in/english-press-release/?rkey=20210119EN52789&amp;filter=20283</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>43</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">InstaNews 24x7</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://english.instanews24x7.com/press-releases?rkey=20210119EN52789&amp;filter=20045</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>44</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">KhabarLive - Hyderabad News</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://www.hydnews.net/pr-newswire?rkey=20210119EN52789&amp;filter=20977</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>45</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Mangalorean</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://www.mangalorean.com/pr-newswire/?rkey=20210119EN52789&amp;filter=17665</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>46</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Nasheman</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://nasheman.in/newswire/?rkey=20210119EN52789&amp;filter=11016</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>47</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">New Delhi Times</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://www.newdelhitimes.com/news-release/?rkey=20210119EN52789&amp;filter=5147</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Newspaper</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>48</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">News Superfast</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://media.newswire.ca/newssuperfastblog.html?rkey=20210119EN52789&amp;filter=10033</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>49</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">News with Chai</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://newswithchai.com/pr-newswire/?rkey=20210119EN52789&amp;filter=17771</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>50</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">NewsBlare</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://www.newsblare.com/pr-newswire/?rkey=20210119EN52789&amp;filter=20902</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>51</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">NewsBlaze India</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://newsblaze.in/pr-newswire?rkey=20210119EN52789&amp;filter=12696</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>52</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">NewsCrazy</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://newscrazy.in/prnewswire/?rkey=20210119EN52789&amp;filter=21273</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Business Services</font></td>
	</tr>
	<tr>
		<td>53</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">NewsDrinker</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://newsdrinker.me/prnewswire/?rkey=20210119EN52789&amp;filter=21268</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Business Services</font></td>
	</tr>
	<tr>
		<td>54</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">NewsR.in</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://www.newsr.in/prnewswire.php?rkey=20210119EN52789&amp;filter=5070</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Newspaper</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>55</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">NewsViewsClub</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://newsviews.club/prnewswire/?rkey=20210119EN52789&amp;filter=21264</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">General</font></td>
	</tr>
	<tr>
		<td>56</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">NewZNew</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://www.newznew.com/press-releases/?rkey=20210119EN52789&amp;filter=16908</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>57</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">NRI News 24 x 7</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://nrinews24x7.com/pr-news/?rkey=20210119EN52789&amp;filter=4972</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>58</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">ODISHA BARTA</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://odishabarta.com/pressrelease.html?rkey=20210119EN52789&amp;filter=20444</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>59</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Odisha Bytes</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://www.odishabytes.com/pr-newswire/?rkey=20210119EN52789&amp;filter=18897</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>60</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Odisha News Tune</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://odishanewstune.com/press-releases/?rkey=20210119EN52789&amp;filter=19427</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>61</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Odisha Ray</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://odisharay.com/pressreleases.php?rkey=20210119EN52789&amp;filter=20944</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>62</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">One News Page Global Edition</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://www.onenewspage.com/prnewswire.php?rkey=20210119EN52789&amp;filter=3968</font></td>
		<td><font face="Arial">   Global</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>63</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">PerfectNewsLive</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://perfectnews.live/prnewswire/?rkey=20210119EN52789&amp;filter=21266</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Business Services</font></td>
	</tr>
	<tr>
		<td>64</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Paper News
		Network</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://papernewsnetwork.com/isgf-announces-the-7th-edition-of-india-smart-utility-
		week-2021-an-international-conference-and-exhibition-on-smart-energy-and-
		smart-mobility-for-smarter-cities-from-02-05-march-2021/</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>65</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">PongaPandit</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://pongapandit.in/prnewswire/?rkey=20210119EN52789&amp;filter=21274</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">General</font></td>
	</tr>
	<tr>
		<td>66</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">PR Newswire</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://www.prnewswire.com/in/news-releases/isgf-announces-the-7th-
		edition-of-india-smart-utility-week-2021-an-international-conference-and-exhibition-on-smart
		-energy-and-smart-mobility-for-smarter-cities-from-02-05-march-2021-811826697.html</font></td>
		<td><font face="Arial">   Global</font></td>
		<td><font face="Arial">PR Newswire</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>67</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Prativad</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://www.prativad.com/Newswireeng.php?rkey=20210119EN52789&amp;filter=19411</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>68</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Press Trust of India</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://www.ptinews.com/pressrelease/44812_press-subISGF-announces-the-
		7th-edition-of-India-Smart-Utility-Week-2021--an-International-Conference-and-Exhibition
		-on-Smart-Energy-and-Smart-Mobility</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>69</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Report Odisha</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://reportodisha.com/press-releases/?rkey=20210119EN52789&amp;filter=19014</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>70</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Report365</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://report365.in/prnewswire/?rkey=20210119EN52789&amp;filter=21271</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Business Services</font></td>
	</tr>
	<tr>
		<td>71</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Reporters Today</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://englishnews.reporterstoday.com/pr-newswire/?rkey=20210119EN52789&amp;filter=20068</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>72</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Review Street</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://reviewstreet.in/news-reviews-mobiles-gadgets-pcs-automobile
		/prnewswireindia/?rkey=20210119EN52789&amp;filter=15937</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>73</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">RNews1 Network</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://www.rnews1.com/p/pr-newswire.html?rkey=20210119EN52789&amp;filter=7546</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>74</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Sambad English</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://sambadenglish.com/prnews/?rkey=20210119EN52789&amp;filter=4968</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Newspaper</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>75</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">SME Channels</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://www.smechannels.com/pr?rkey=20210119EN52789&amp;filter=4607</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Tech</font></td>
	</tr>
	<tr>
		<td>76</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">SME Street</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://smestreet.in/infocus/prnewswireindia/?rkey=20210119EN52789&amp;filter=15935</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>77</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Social News XYZ</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://www.socialnews.xyz/pr-newswire/?rkey=20210119EN52789&amp;filter=15405</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>78</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Solar Surge</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://www.solarsurge.in/pr-newswire/?rkey=20210119EN52789&amp;filter=17110</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Energy and Natural Resources</font></td>
	</tr>
	<tr>
		<td>79</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Telangana Today</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://telanganatoday.com/pr-newswire?rkey=20210119EN52789&amp;filter=11682</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>80</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">The Hawk India</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://www.thehawk.in/news/prnewswire?rkey=20210119EN52789&amp;filter=4853</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Newspaper</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>81</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">The Reporting
		Today</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://www.thereportingtoday.com/newswire/?rkey=20210119EN52789&amp;filter=20784</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>82</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Think News 
		Today</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://thinknews.today/prnewswire/?rkey=20210119EN52789&amp;filter=21262</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">General</font></td>
	</tr>
	<tr>
		<td>83</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Times Tech</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://timestech.in/trends-forecast/?rkey=20210119EN52789&amp;filter=15939</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Tech</font></td>
	</tr>
	<tr>
		<td>84</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Tripuraindia</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://www.tripuraindia.in/press-release?rkey=20210119EN52789&amp;filter=18753</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>85</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">United News
		of India</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://www.uniindia.com/isgf-announces-the-7th-edition-of-india-smart
		-utility-week-2021-an-international-conference-and-exhibition-on-smart-energy-and-smart-mobility
		-for-smarter-cities-from-02--05-march-2021/prnewswire/news/2296912.html</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>86</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">Uttarakhand News
		Network</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">https://uttarakhandnewsnetwork.com/press-release-pr-news-wire/?rkey=20210119EN52789&amp;filter=14497</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>87</td>
		<td>ISUW 2021 Press Release 1</font></td>
		<td><font face="Arial">WindowtoNews</font></td>
		<td><font face="Arial">Online</font></td>
		<td><font face="Arial">http://windowtonews.com/pr-newswire-english.php?rkey=20210119EN52789&amp;filter=19687</font></td>
		<td><font face="Arial">   India</font></td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</font></td>
		<td><font face="Arial">Media &amp; Information</font></td>
	</tr>
	<tr>
		<td>88</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font color="#0563C1"><a href="https://www.saurenergy.com/solar-energy-news/coronavirus-impact-on-power-collections-and-more">https://www.saurenergy.com/solar-energy-news/coronavirus-impact-on-power-collections-and-more</a></font></u></b></td>
		<td><font size=3 color="#000000">India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>89</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font color="#0563C1"><a href="https://factsntrens.wordpress.com/2020/03/20/smart-utilities-management-market-trends-scope-forecast-by-2026/">https://factsntrens.wordpress.com/2020/03/20/smart-utilities
		-management-market-trends-scope-forecast-by-2026/</a></font></u></b></td>
		<td><font size=3 color="#000000">India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>90</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td>Print</td>
		<td><font size=3 color="#000000"></td>
		<td><font size=3 color="#000000">India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>91</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font size=3 color="#0563C1"><a href="https://www.engerati.com/smart-infrastructure/india-smart-utility-week-takes-place-in-new-delhi/">https://www.engerati.com/smart-infrastructure/india
		-smart-utility-week-takes-place-in-new-delhi/</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>92</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font size=3 color="#0563C1"><a href="http://www.newsmakeinindia.in/india-smart-utility-week-2020.html/">or =&nbsp;http://www.newsmakeinindia.in/india-smart-utility-week-2020.html/</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>93</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font size=3 color="#0563C1"><a href="https://www.divyadelhi.com/honourable-minister--rk-singh-to-deliver-special-address-at-india-smart-utility-week-2020-">&nbsp;Honourable Minister RK Singh to deliver special address at India Smart Utility Week 2020&nbsp;http&nbsp;link =https://www.divyadelhi.com/honourable-minister--rk-singh-to-deliver-special-address-at-india-smart-utility-week-2020-</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>94</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">Hindi</td>
		<td><font face="Arial">Online</td>
		<td><u><font face="FreeSans" size=3 color="#0563C1"><a href="https://thedelhitodaynews.blogspot.com/2020/03/2020.html">https://thedelhitodaynews.blogspot.com/2020/03/2020.html</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>95</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font size=3 color="#0563C1"><a href="http://www.itsforhome.com/pub/index.php/2020/03/10/Maker-Village-receives-smart-incubator-award/">http://www.itsforhome.com/pub/index.php/2020/03/10/Maker
		-Village-receives-smart-incubator-award/</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>96</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font size=3 color="#0563C1"><a href="https://timesofindia.indiatimes.com/city/kochi/maker-village-receives-smart-incubator-award/articleshow/74567475.cms">https://timesofindia.indiatimes.com/city/kochi/maker-village
		-receives-smart-incubator-award/articleshow/74567475.cms</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>97</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font size=3 color="#0563C1"><a href="https://www.smartinnovationnorway.com/nyheter/presenterer-eu-prosjekter-under-india-smart-utility-week/">https://www.smartinnovationnorway.com/nyheter/presenterer-
		eu-prosjekter-under-india-smart-utility-week/</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>98</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font size=3 color="#0563C1"><a href="https://affairscloud.com/new-delhi-hosts-india-smart-utility-week-2020-isuw/">https://affairscloud.com/new-delhi-hosts-india-smart-utility-week-2020-isuw/</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>99</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font size=3 color="#0563C1"><a href="https://www.psuconnect.in/news/POSOCO-Bags-ISGF--Simons-Award-/21824/">https://www.psuconnect.in/news/POSOCO-Bags-ISGF--Simons-Award-/21824/</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>100</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font size=3 color="#0563C1"><a href="https://www.google.com/url?q=https://www.5nax.in/tnpsc/exams/daily-current-affairs-march-7-2020/&amp;source=gmail&amp;ust=1583996920061000&amp;usg=AFQjCNE4hx3JgaU4c9n2V5WupjtXRr9Ejw">https://www.google.com/url?q=https://www.5nax.in/tnpsc/exams/daily-current
		-affairs-march-7-2020/&amp;source=gmail&amp;ust=1583996920061000
		&amp;usg=AFQjCNE4hx3JgaU4c9n2V5WupjtXRr9Ejw</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>101</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font size=3 color="#0563C1"><a href="https://affairscloud.com/current-affairs-hindi-quiz-march-7-2020/">https://affairscloud.com/current-affairs-hindi-quiz-march-7-2020/</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>102</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font size=3 color="#0563C1"><a href="https://www.aspirantszone.com/current-affairs-8-march-2020-quiz/">https://www.aspirantszone.com/current-affairs-8-march-2020-quiz/</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>103</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font size=3 color="#0563C1"><a href="http://truthdive.com/2020/03/10/can-smart-meters-solve-indias-electricity-problem-the-opinion-analysis/">http://truthdive.com/2020/03/10/can-smart-meters-solve-indias
		-electricity-problem-the-opinion-analysis/</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>104</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font size=3 color="#0563C1"><a href="http://www.uniindia.com/~/maker-village-wins-isgf-smart-incubator-of-the-year-for-deep-tech-areas/States/news/1913539.html">http://www.uniindia.com/~/maker-village-wins-isgf-smart-incubator-
		of-the-year-for-deep-tech-areas/States/news/1913539.html</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>105</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font size=3 color="#0563C1"><a href="http://www.newsexperts.in/maker-village-wins-isgf-smart-incubator-year-deep-tech-areas/">http://www.newsexperts.in/maker-village-wins-isgf-smart-incubator-year-deep-tech-areas/</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>106</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font size=3 color="#0563C1"><a href="http://www.itsforhome.com/pub/index.php/2020/03/10/Maker-Village-wins-ISGF-Smart-Incubator-of-the-Year-for-Deep-Tech-Areas/">http://www.itsforhome.com/pub/index.php/2020/03/10/Maker-Village-wins
		-ISGF-Smart-Incubator-of-the-Year-for-Deep-Tech-Areas/</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>107</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font size=3 color="#0563C1"><a href="https://affairscloud.com/current-affairs-hindi-march-7-2020/">https://affairscloud.com/current-affairs-hindi-march-7-2020/</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>108</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font size=3 color="#0563C1"><a href="https://thedelhitodaynews.blogspot.com/2020/03/2020.html">&nbsp;https://thedelhitodaynews.blogspot.com/2020/03/2020.html&nbsp;&nbsp;</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>109</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font size=3 color="#0563C1"><a href="http://www.nacleanenergy.com/articles/37103/india-smart-grid-forum-becomes-energy-web-ambassador">http://www.nacleanenergy.com/articles/37103/india
		-smart-grid-forum-becomes-energy-web-ambassador</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>110</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font size=3 color="#0563C1"><a href="https://www.engerati.com/smart-infrastructure/india-smart-utility-week-takes-place-in-new-delhi/">https://www.engerati.com/smart-infrastructure/india-smart-utility-week-takes-place-in-new-delhi/</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>111</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font size=3 color="#0563C1"><a href="https://auto.economictimes.indiatimes.com/news/aftermarket/tata-power-aims-to-expand-ev-charging-stations-with-tata-motors-dealers-and-group-entities-/74478070">https://auto.economictimes.indiatimes.com/news/aftermarket/
		tata-power-aims-to-expand-ev-charging-stations-with-tata
		-motors-dealers-and-group-entities-/74478070</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>112</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font size=3 color="#0563C1"><a href="https://www.blogarama.com/technology-blogs/500546-amzur-blog/33724731-india-smart-grid-forum-charging-for-electric-vehicles">https://www.blogarama.com/technology-blogs/500546-amzur-blog/33724731
		-india-smart-grid-forum-charging-for-electric-vehicles</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>113</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font size=3 color="#0563C1"><a href="https://www.saurenergy.com/press-release/bwi/honourable-minister-shri-rk-singh-to-deliver-special-address-at-india-smart-utility-week-2020-on-march-04-2020">https://www.saurenergy.com/press-release/bwi/honourable-minister
		-shri-rk-singh-to-deliver-special-address-at-india-
		smart-utility-week-2020-on-march-04-2020&nbsp;</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>114</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font size=3 color="#0563C1"><a href="http://networking.itbusinessnet.com/2020/03/amzur-announces-that-raymond-kaiser-director-of-energy-management-systems-has-been-invited-as-the-keynote-speaker-at-this-years-india-smart-grid-forum/">http://networking.itbusinessnet.com/2020/03/amzur-announces-that-raymond
		-kaiser-director-of-energy-management-systems-has-been-invited-as-the-keynote-speaker
		-at-this-years-india-smart-grid-forum/</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>115</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font size=3 color="#0563C1"><a href="https://www.energetica-india.net/news/power-minister-rk-singh-to-deliver-special-address-at-india-smart-utility-week-2020">https://www.energetica-india.net/news/power-minister-rk-singh-to
		-deliver-special-address-at-india-smart-utility-week-2020</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>115</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font size=3 color="#0563C1"><a href="https://timestech.in/honourable-minister-shri-rk-singh-to-deliver-special-address-at-isuw-2020-on-march-04-2020/">https://timestech.in/honourable-minister-shri-rk-singh-to
		-deliver-special-address-at-isuw-2020-on-march-04-2020/</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>116</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font size=3 color="#0563C1"><a href="https://timestech.in/honourable-minister-shri-rk-singh-to-deliver-special-address-at-isuw-2020-on-march-04-2020/">https://timestech.in/honourable-minister-shri-rk-singh-to-deliver
		-special-address-at-isuw-2020-on-march-04-2020/&nbsp;&nbsp;</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>117</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font size=3 color="#0563C1"><a href="https://www.prnewswire.com/in/news-releases/india-smart-utility-week-2019-to-be-inaugurated-by-shri-sanjiv-nandan-sahay-secretary-ministry-of-power-on-march-04-2020-894838724.html?">https://www.prnewswire.com/in/news-releases/india-smart-utility-week-2019-to-be-inaugurated
		-by-shri-sanjiv-nandan-sahay-secretary-ministry-of-power-on-march-04-2020-894838724.html?</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>118</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font size=3 color="#0563C1"><a href="https://powerline.net.in/2020/02/27/interview-with-reji-kumar-pillai/">https://powerline.net.in/2020/02/27/interview-with-reji-kumar-pillai/</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>119</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font size=3 color="#0563C1"><a href="https://www.thechainmagazine.com/india-smart-utility-week-2019-to-be-inaugurated-by-shri-sanjiv-nandan-sahay-secretary-ministry-of-power-on-march-04-2020/">https://www.thechainmagazine.com/india-smart-utility-week-2019-to-be-inaugurated
		-by-shri-sanjiv-nandan-sahay-secretary-ministry-of-power-on-march-04-2020/</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>120</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font size=3 color="#0563C1"><a href="http://xitfilms.ru/kino/P+Elango,+MD,+HOEC+On+Reforms+To+Enhance+Domestic+Exploration+Of+Oil+&amp;amp+Gas+CNBC-TV18">http://xitfilms.ru/kino/P+Elango,+MD,+HOEC+On+Reforms+To+Enhance
		+Domestic+Exploration+Of+Oil+&amp;amp+Gas+CNBC-TV18</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>121</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font size=3 color="#0563C1"><a href="http://xitfilms.ru/kino/ISUW+2019+Maneesha+V+Ramesh+,+Amrita+Vishwa+Vidyapeetham+WORKSHOP+ON+FUTURE+SKILLS+2030">http://xitfilms.ru/kino/ISUW+2019+Maneesha+V+Ramesh+,
		+Amrita+Vishwa+Vidyapeetham+WORKSHOP+ON+FUTURE+SKILLS+2030</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>122</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font size=3 color="#0563C1"><a href="https://www.devdiscourse.com/article/business/893899-india-smart-utility-week-2019-to-be-inaugurated-by-sanjiv-nandan-sahay-secretary-ministry-of-power-on-march-04-2020">https://www.devdiscourse.com/article/business/893899-india-smart-utility-week-2019
		-to-be-inaugurated-by-sanjiv-nandan-sahay-secretary-ministry-of-power-on-march-04-2020</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>123</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font size=3 color="#0563C1"><a href="https://www.ecoideaz.com/?s=smart+grid">https://www.ecoideaz.com/?s=smart+grid</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>124</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font size=3 color="#0563C1"><a href="https://www.cde.ual.es/conferencia-india-smart-utility-week-2020/">https://www.cde.ual.es/conferencia-india-smart-utility-week-2020/</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>125</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font size=3 color="#0563C1"><a href="https://www.nokia.com/about-us/news-and-events/events-calendar/india-smart-utilities-week-2020/">https://www.nokia.com/about-us/news-and-events/events
		-calendar/india-smart-utilities-week-2020/</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>126</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font size=3 color="#0563C1"><a href="https://osgp.org/en/news#India-Smart-Utility-Week-ISUW-2020">https://osgp.org/en/news#India-Smart-Utility-Week-ISUW-2020</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>127</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font size=3 color="#0563C1"><a href="https://smartwww.in/india-smart-utility-week-isuw-2020-one-of-the-top-five-international-events-on-smart-grids-smart-cities/">&nbsp;https://smartwww.in/india-smart-utility-week-isuw-2020-one-
		of-the-top-five-international-events-on-smart-grids-smart-cities/</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>128</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font size=3 color="#0563C1"><a href="http://newsdogshare.com/amp/article/5e04a98f83b48e62cb8cdafc/">http://newsdogshare.com/amp/article/5e04a98f83b48e62cb8cdafc/</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>129</td>
		<td>ISUW 2020</td>
		<td><font size=3 color="#000000">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font size=3 color="#0563C1"><a href="https://electronicsmaker.com/india-smart-utility-week-isuw-2020">https://electronicsmaker.com/india-smart-utility-week-isuw-2020</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>130</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://www.abhitaknews.com/english/news/press-releases.aspx?rkey=20200228EN33443&amp;filter=1889</td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>131</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>https://accommodationtimes.com/pr-newswire/?rkey=20200228EN33443&amp;filter=18279</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Real Estate</td>
	</tr>
	<tr>
		<td>132</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://www.asianbuck.com/asianbuck-prnews/?rkey=20200228EN33443&amp;filter=8421</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>133</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://www.ai-online.com/prnewswire/?rkey=20200228EN33443&amp;filter=1271</td>
		<td><font size=3>   Global</td>
		<td><font size=3>Trade Publications</td>
		<td><font size=3>Transportation/Logistics</td>
	</tr>
	<tr>
		<td>134</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>https://www.awesomeindia.in/press-release/?rkey=20200228EN33443&amp;filter=16869</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>134</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://b-live.in/prnewswire/?rkey=20200228EN33443&amp;filter=18861</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>135</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://www.bangalorewaves.com/news/bangalorewaves-business-news.php?rkey=20200228EN33443&amp;filter=2267</td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Tech</td>
	</tr>
	<tr>
		<td>136</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://news.biharprabha.com/prnewswire/?rkey=20200228EN33443&amp;filter=2270</td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>137</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://www.bizwireexpress.com/showstoryPRN.php?rkey=20200228EN33443&amp;filter=2276</td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>138</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://www.biznews.in/article/india-smart-utility-week-2019-to-be-inaugurated-by-shri-sanjiv-nandan-sahay-secretary-ministry-of-power-on-march-04-2020</td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Other</td>
	</tr>
	<tr>
		<td>139</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://www.biznextindia.com/pr-newswire/?rkey=20200228EN33443&amp;filter=19403</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>140</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://businessfortnight.com/pr-newswire/?rkey=20200228EN33443&amp;filter=5117</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>141</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://businessnewsthisweek.com/prnews/?rkey=20200228EN33443&amp;filter=601</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>142</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://www.businesssandesh.in/breaking-news/?rkey=20200228EN33443&amp;filter=7621</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>143</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://www.businesstoday.in/prnewswire/?rkey=20200228EN33443&amp;filter=2418</td>
		<td><font size=3>   India</td>
		<td><font size=3>Trade Publications</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>144</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://businessviews.in/business-views-press-release-news/?rkey=20200228EN33443&amp;filter=908</td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>145</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://corecommunique.com/prnewswire/?rkey=20200228EN33443&amp;filter=4754</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>146</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://corporateethos.com/pr-newswire/?rkey=20200228EN33443&amp;filter=6430</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>147</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>https://www.csomagazine.com/press-release/10635865</td>
		<td><font size=3>   United Kingdom</td>
		<td><font size=3>Trade Publications</td>
		<td><font size=3>Environment</td>
	</tr>
	<tr>
		<td>148</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://www.dsij.in/newswiredetails.aspx?FileName=202002280014PR_NEWS_EURO_ND__EN33443</td>
		<td><font size=3>   India</td>
		<td><font size=3>Financial Data, Research &amp; Analytics</td>
		<td><font size=3>Financial</td>
	</tr>
	<tr>
		<td>149</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>https://www.dkoding.in/press-release/india-smart-utility-week-2019-to-be-inaugurated
		-by-shri-sanjiv-nandan-sahay-secretary-ministry-of-power-on-march-04-2020/</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>150</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>https://www.energycentral.com/node/407474/edit?news_processing=1</td>
		<td><font size=3>   United States</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Energy and Natural Resources</td>
	</tr>
	<tr>
		<td>151</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>https://www.energydigital.com/press-release/10635865-0</td>
		<td><font size=3>   United Kingdom</td>
		<td><font size=3>Trade Publications</td>
		<td><font size=3>Energy and Natural Resources</td>
	</tr>
	<tr>
		<td>152</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>https://enterpriseworldnews.com/pr-newswire/?rkey=20200228EN33443&amp;filter=19539</td>
		<td><font size=3>   India</td>
		<td><font size=3>Banking &amp; Financial Institutions</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>153</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>https://www.feedspot.com/?_src=folder</td>
		<td><font size=3>   United States</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>154</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://firstreport.in/pr-newswire/?rkey=20200228EN33443&amp;filter=6490</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>155</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>https://globalprimenews.com/prnewswire/?rkey=20200228EN33443&amp;filter=19416</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>156</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://goevnts.com/pr-landing?rkey=20200228EN33443&amp;filter=4444</td>
		<td><font size=3>   Global</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Business Services</td>
	</tr>
	<tr>
		<td>157</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://greenlichen.com/pr-newswire/?rkey=20200228EN33443&amp;filter=15918</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Environment</td>
	</tr>
	<tr>
		<td>158</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://www.hellomumbainews.com/hello-business/?rkey=20200228EN33443&amp;filter=12313</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>159</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://ians.in/index.php?param=prnewswiredetail/PRN-1066108</td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>160</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>https://ibgnews.com/pr-newswire-news/?rkey=20200228EN33443&amp;filter=19585</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>161</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>https://ibtn9.com/pr-newswire/?rkey=20200228EN33443&amp;filter=12202</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>162</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://www.india-briefing.com/news/partnernews/?rkey=20200228EN33443&amp;filter=3400</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Financial</td>
	</tr>
	<tr>
		<td>163</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>https://www.apherald.com/prnewswire?rkey=20200228EN33443&amp;filter=18307</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>164</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://news.indiaonline.in/prnewswire?rkey=20200228EN33443&amp;filter=4991</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>165</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>https://www.indiatoday.in/pr-newswire?rkey=20200228EN33443&amp;filter=4315</td>
		<td><font size=3>   India</td>
		<td><font size=3>Magazine</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>166</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://indiannerve.com/in-press/?rkey=20200228EN33443&amp;filter=6492</td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>167</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://indianpowersector.com/prnews/?rkey=20200228EN33443&amp;filter=4997</td>
		<td><font size=3>   India</td>
		<td><font size=3>Trade Publications</td>
		<td><font size=3>Energy and Natural Resources</td>
	</tr>
	<tr>
		<td>168</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://indoredilse.com/english-news/?rkey=20200228EN33443&amp;filter=10474</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>169</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>https://english.instanews24x7.com/press-releases?rkey=20200228EN33443&amp;filter=20045</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>170</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://www.internationalfair.in/pdetails.php?rkey=20200228EN33443&amp;filter=9866</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Business Services</td>
	</tr>
	<tr>
		<td>171</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://www.itnewsonline.com/prnewswire/India-Smart-Utility-Week-2019-to-be-
		Inaugurated-by-Shri-Sanjiv-Nandan-Sahay-Secretary-Ministry-of-Power-on-March-04-2020/681967</td>
		<td><font size=3>   India</td>
		<td><font size=3>Trade Publications</td>
		<td><font size=3>Tech</td>
	</tr>
	<tr>
		<td>172</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://www.lang1234.info/prnewswire.html?rkey=20200228EN33443&amp;filter=10756</td>
		<td><font size=3>   United States</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Multicultural &amp; Demographic</td>
	</tr>
	<tr>
		<td>173</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>https://livechronicle.in/2020/02/28/india-smart-utility-week-2019-to-be-
		inaugurated-by-shri-sanjiv-nandan-sahay-secretary-ministry-of-power-on-march-04-2020/</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>174</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://www.mangalorean.com/pr-newswire/?rkey=20200228EN33443&amp;filter=17665</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>175</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>https://mybrandbook.co.in/redirect.php?p=11431&amp;rkey=20200228EN33443&amp;filter=19999</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Tech</td>
	</tr>
	<tr>
		<td>176</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://nasheman.in/newswire/?rkey=20200228EN33443&amp;filter=11016</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>177</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>https://www.newdelhitimes.com/news-release/?rkey=20200228EN33443&amp;filter=5147</td>
		<td><font size=3>   India</td>
		<td><font size=3>Newspaper</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>178</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://media.newswire.ca/newssuperfastblog.html?rkey=20200228EN33443&amp;filter=10033</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>179</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>https://newswithchai.com/pr-newswire/?rkey=20200228EN33443&amp;filter=17771</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>180</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>https://newsblaze.in/pr-newswire?rkey=20200228EN33443&amp;filter=12696</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>181</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://www.newscontrolroom.com/prnewswire/?rkey=20200228EN33443&amp;filter=19537</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>182</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://www.newsgram.com/press-releases/?rkey=20200228EN33443&amp;filter=590</td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>183</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://www.newsr.in/prnewswire.php?rkey=20200228EN33443&amp;filter=5070</td>
		<td><font size=3>   India</td>
		<td><font size=3>Newspaper</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>184</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>https://nrinews24x7.com/pr-news/?rkey=20200228EN33443&amp;filter=4972</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>185</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://www.odishabytes.com/pr-newswire/?rkey=20200228EN33443&amp;filter=18897</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>186</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://odishanewstune.com/press-releases/?rkey=20200228EN33443&amp;filter=19427</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>187</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://www.odishastory.com/pr-newswire/?rkey=20200228EN33443&amp;filter=19409</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>188</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://odishasuntimes.com/prnews/?rkey=20200228EN33443&amp;filter=4968</td>
		<td><font size=3>   India</td>
		<td><font size=3>Newspaper</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>189</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://www.odisha360.com/prn/?rkey=20200228EN33443&amp;filter=4962</td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>190</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>https://www.ohsem.me/pr-newswire/?rkey=20200228EN33443&amp;filter=5817</td>
		<td><font size=3>   Malaysia</td>
		<td><font size=3>Blog</td>
		<td><font size=3>Tech</td>
	</tr>
	<tr>
		<td>191</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://www.onenewspage.com/prnewswire.php?rkey=20200228EN33443&amp;filter=3968</td>
		<td><font size=3>   Global</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>192</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>https://www.prnewswire.com/in/news-releases/india-smart-utility-week-2019-to-
		be-inaugurated-by-shri-sanjiv-nandan-sahay-secretary
		-ministry-of-power-on-march-04-2020-894838724.html</td>
		<td><font size=3>   United States</td>
		<td><font size=3>PR Newswire</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>193</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://www.prativad.com/Newswireeng.php?rkey=20200228EN33443&amp;filter=19411</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>194</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://www.ptinews.com/pressrelease/39825_press-subIndia-Smart-Utility
		-Week-2019-to-be-Inaugurated-by-Shri-Sanjiv-Nandan-Sahay--
		Secretary--Ministry-of-Power-on-March-04--2020</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>195</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>https://reportodisha.com/press-releases/?rkey=20200228EN33443&amp;filter=19014</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>196</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>https://englishnews.reporterstoday.com/pr-newswire/?rkey=20200228EN33443&amp;filter=20068</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>197</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>https://reviewstreet.in/news-reviews-mobiles-gadgets-pcs-
		automobile/prnewswireindia/?rkey=20200228EN33443&amp;filter=15937</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>198</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://www.rnews1.com/p/pr-newswire.html?rkey=20200228EN33443&amp;filter=7546</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>199</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://english.samajalive.in/pr-newswire/?rkey=20200228EN33443&amp;filter=19527</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>200</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://www.smarttechtoday.com/prnews/?rkey=20200228EN33443&amp;filter=2496</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Tech</td>
	</tr>
	<tr>
		<td>201</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>https://smestreet.in/infocus/prnewswireindia/?rkey=20200228EN33443&amp;filter=15935</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>202</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>https://www.socialnews.xyz/pr-newswire/?rkey=20200228EN33443&amp;filter=15405</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>203</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>https://www.solarsurge.in/pr-newswire/?rkey=20200228EN33443&amp;filter=17110</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Energy and Natural Resources</td>
	</tr>
	<tr>
		<td>204</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://startuptostandout.com/pr-news-wire/?rkey=20200228EN33443&amp;filter=17982</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>205</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://techent.tv/newswire?rkey=20200228EN33443&amp;filter=5758</td>
		<td><font size=3>   Malaysia</td>
		<td><font size=3>Blog</td>
		<td><font size=3>Tech</td>
	</tr>
	<tr>
		<td>206</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>https://telanganatoday.com/pr-newswire?rkey=20200228EN33443&amp;filter=11682</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>207</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>https://www.thechainmagazine.com/india-smart-utility-week-2019-to-be-
		inaugurated-by-shri-sanjiv-nandan-sahay-secretary
		-ministry-of-power-on-march-04-2020/</td>
		<td><font size=3>   United Kingdom</td>
		<td><font size=3>Trade Publications</td>
		<td><font size=3>Industrial</td>
	</tr>
	<tr>
		<td>208</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://thehawk.in/prnewswire/?rkey=20200228EN33443&amp;filter=4853</td>
		<td><font size=3>   India</td>
		<td><font size=3>Newspaper</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>209</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>https://www.thesme.co.in/news-wire/?rkey=20200228EN33443&amp;filter=18812</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>210</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>https://thetechportal.com/press-releases-pr-newswire/?rkey=20200228EN33443&amp;filter=1985</td>
		<td><font size=3>   India</td>
		<td><font size=3>Trade Publications</td>
		<td><font size=3>Tech</td>
	</tr>
	<tr>
		<td>211</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://www.thetimesofbengal.com/newswire/?rkey=20200228EN33443&amp;filter=17730</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>212</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>https://www.thinkingtech.in/pr-newswire/?rkey=20200228EN33443&amp;filter=17106</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Tech</td>
	</tr>
	<tr>
		<td>213</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://timestech.in/trends-forecast/?rkey=20200228EN33443&amp;filter=15939</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Tech</td>
	</tr>
	<tr>
		<td>214</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>https://www.tmcnet.com/usubmit/-india-smart-utility-week-2019-be-inaugurated-shri-/2020/02/28/9106334.htm</td>
		<td><font size=3>   United States</td>
		<td><font size=3>Trade Publications</td>
		<td><font size=3>Tech</td>
	</tr>
	<tr>
		<td>215</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>https://www.tripuraindia.in/press-release?rkey=20200228EN33443&amp;filter=18753</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>216</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://www.uniindia.com/india-smart-utility-week-2019-to-be-inaugurated
		-by-shri-sanjiv-nandan-sahay-secretary-ministry-of-power-
		on-march-04-2020/prnewswire/news/1901477.html</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>217</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>https://updateodisha.com/pr-corner?rkey=20200228EN33443&amp;filter=19112</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>218</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>https://uttarakhandnewsnetwork.com/press-release-pr-news-wire/?rkey=20200228EN33443&amp;filter=14497</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>219</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>https://www.varindia.com/news/press--pr-news-wire?rkey=20200228EN33443&amp;filter=537</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Tech</td>
	</tr>
	<tr>
		<td>220</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>https://news.webindia123.com/news/press_showdetailsPR.asp?id=1129009</td>
		<td><font size=3>   India</td>
		<td><font size=3>Trade Publications</td>
		<td><font size=3>Financial</td>
	</tr>
	<tr>
		<td>221</td>
		<td>ISUW 2020</td>
		<td><font size=3>English</td>
		<td><font face="Arial">Online</td>
		<td><font size=3>http://windowtonews.com/pr-newswire-english.php?rkey=20200228EN33443&amp;filter=19687</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>222</td>
		<td>ISUW 2020</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font color="#0563C1"><a href="http://online.fliphtml5.com/dysdc/rpmk/#p=110">http://online.fliphtml5.com/dysdc/rpmk/#p=110</a></font></u></b></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td>223</td>
		<td>ISUW 2020</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font color="#0563C1"><a href="http://www.sustainabilityoutlook.in/content/datebook/india-smart-utility-week-2020-765806">http://www.sustainabilityoutlook.in/content/datebook
		/india-smart-utility-week-2020-765806</a></font></u></b></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td>224</td>
		<td>ISUW 2020</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font color="#0563C1"><a href="http://www.iea-isgan.org/?p=4470">http://www.iea-isgan.org/?p=4470</a></font></u></b></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td>225</td>
		<td>ISUW 2020</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font color="#0563C1"><a href="https://electronicsmaker.com/india-smart-utility-week-isuw-2020">https://electronicsmaker.com/india-smart-utility-week-isuw-2020</a></font></u></b></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td>226</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font color="#0563C1"><a href="http://www.itsforhome.com/pub/index.php/2018/03/09/Green-light-for-new-national-IoT-initiative-in-Trondheim/">http://www.itsforhome.com/pub/index.php/2018/03/09/Green-light-for-new-national-IoT-initiative-in-Trondheim/</a></font></u></b></td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>227</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font color="#0563C1"><a href="http://www.infraline.com/newsdetails.aspx?flag=1&amp;id=54883&amp;title=Next-Tranche-Of-Highway-Projects-Under-Tot-To-Be-Auctioned-In-Apr-Nitin-Gadkari">http://www.infraline.com/newsdetails.aspx?flag=1&amp;id=54883&amp;title=Next-Tranche-Of-Highway-Projects-Under-Tot-To-Be-Auctioned-In-Apr-Nitin-Gadkari</a></font></u></b></td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>228</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font color="#0563C1"><a href="http://www.dailypioneer.com/business/2018-03-08-210078.html">http://www.dailypioneer.com/business/2018-03-08-210078.html</a></font></u></b></td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>229</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font color="#0563C1"><a href="http://www.lse.co.uk/ShareChat.asp?ShareTicker=CYAN&amp;type=regular#18447127">http://www.lse.co.uk/ShareChat.asp?ShareTicker=CYAN&amp;type=regular#18447127</a></font></u></b></td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>230</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font color="#0563C1"><a href="http://www.andhranews.net/updates/Andhra_Pradesh_News_on_March_9,2018">http://www.andhranews.net/updates/Andhra_Pradesh_News_on_March_9,2018</a></font></u></b></td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>231</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font color="#0563C1"><a href="http://www.itsforhome.com/pub/index.php/2018/03/09/APEPDCL-bags-award-for-100-electrification/">http://www.itsforhome.com/pub/index.php/2018/03/
		09/APEPDCL-bags-award-for-100-electrification/</a></font></u></b></td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>232</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font color="#0563C1"><a href="http://www.itsforhome.com/pub/index.php/2018/03/10/APEPDCL-wins-award-ATC-with-PIC/">http://www.itsforhome.com/pub/index.php/
		2018/03/10/APEPDCL-wins-award-ATC-with-PIC/</a></font></u></b></td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>233</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font color="#0563C1"><a href="http://www.pressreleasepoint.com/cyanconnode-wins-platinum-isgf-innovation-awards">http://www.pressreleasepoint.com/cyanconnode-wins-platinum-isgf-innovation-awards</a></font></u></b></td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>234</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font color="#0563C1"><a href="https://in.ambafrance.org/List-of-agreements-and-contracts">https://in.ambafrance.org/List-of-agreements-and-contracts</a></font></u></b></td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>235</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font color="#0563C1"><a href="http://www.boursorama.com/actualites/encadre-contrats-et-accords-signes-lors-de-la-visite-de-macron-en-inde-553fc467e3ce4a4cd3d22f822f0cfbf1">http://www.boursorama.com/actualites/encadre-contrats-et-accords-signes
		-lors-de-la-visite-de-macron-en-inde-553fc467e3ce4a4cd3d22f822f0cfbf1</a></font></u></b></td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>236</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font color="#0563C1"><a href="https://www.pv-magazine-india.com/press-releases/rahul-walawalkar-honored-with-india-smart-grid-forum-presidents-award-2018/">https://www.pv-magazine-india.com/press-releases/rahul-walawalkar
		-honored-with-india-smart-grid-forum-presidents-award-2018/</a></font></u></b></td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>237</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font color="#0563C1"><a href="https://nseindia.com/corporates/corpInfo/equities/AnnouncementDetail.jsp?desc=Press+Release&amp;symbol=DPSCLTD&amp;tstamp=140320181052">https://nseindia.com/corporates/corpInfo/equities/AnnouncementDetail.
		jsp?desc=Press+Release&amp;symbol=DPSCLTD&amp;tstamp=140320181052</a></font></u></b></td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>238</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font color="#0563C1"><a href="https://intradayequitytips.wordpress.com/2018/03/14/india-power-corporation-wins-isgf-innovation-awards-2018/">https://intradayequitytips.wordpress.com/2018/03/14/
		india-power-corporation-wins-isgf-innovation-awards-2018/</a></font></u></b></td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>239</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font color="#0563C1"><a href="http://www.varindia.com/news/tata-powerddl-joins-hands-with-sap-to-curb-power-theft">http://www.varindia.com/news/tata-powerddl-joins-hands-with-sap-to-curb-power-theft</a></font></u></b></td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>240</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font color="#0563C1"><a href="http://www.4-traders.com/BRG-VERMOEGENSVERWALTUNG-3950146/news/BRG-Vermoegensverwaltung-IESA-Customized-Energy-Solutions-Dr-Rahul-Walawalkar-honored-with-Indi-26158901/">http://www.4-traders.com/BRG-VERMOEGENSVERWALTUNG-3950146/
		news/BRG-Vermoegensverwaltung-IESA-Customized-Energy-Solutions-
		Dr-Rahul-Walawalkar-honored-with-Indi-26158901/</a></font></u></b></td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>241</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font color="#0563C1"><a href="http://www.citrusinteractive.in/News/OpenNewsContent.aspx?NewsID=617951&amp;SecId=7&amp;SubSecID=15">http://www.citrusinteractive.in/News/OpenNewsContent
		.aspx?NewsID=617951&amp;SecId=7&amp;SubSecID=15</a></font></u></b></td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>242</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font color="#0563C1"><a href="http://solarquarter.com/index.php/world/73-asia-australia/india/8546-experts-from-50-countries-to-converge-at-the-4th-edition-of-india-smart-grid-week-to-discuss-emerging-transformation-of-the-india-s-energy-sector">http://solarquarter.com/index.php/world/73-asia-australia/india/
		8546-experts-from-50-countries-to-converge-at-the-4th-edition-of-india-smart-grid-
		week-to-discuss-emerging-transformation-of-the-india-s-energy-sector</a></font></u></b></td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>243</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><u><font color="#0563C1"><a href="http://www.businessworld.in/article/Experts-From-50-Countries-to-Converge-at-the-4th-Edition-of/21-02-2018-141286/">http://www.businessworld.in/article/Experts-From-50-Countries-to-
		Converge-at-the-4th-Edition-of/21-02-2018-141286/</a></font></u></b></td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>244</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.5dariyanews.com/Full-Story-Latest-from-PR-Newswire.aspx?rkey=20180220enIN201802191749_indiapublic&amp;filter=3325</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>245</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.abhitaknews.com/english/news/press-releases.aspx?rkey=20180220enIN201802191749_indiapublic&amp;filter=1889</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>246</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.asianbuck.com/asianbuck-prnews/?rkey=20180220enIN201802191749_indiapublic&amp;filter=8421</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>247</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://assignmenteditor.com/pr-newswire-3/?rkey=20180220enIN201802191749_indiapublic&amp;filter=1673</td>
		<td><font face="Arial">   Global</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>248</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.ai-online.com/prnewswire/?rkey=20180220enIN201802191749_indiapublic&amp;filter=1271</td>
		<td><font face="Arial">   Global</td>
		<td><font face="Arial">Trade Publications</td>
		<td><font face="Arial">Transportation</td>
	</tr>
	<tr>
		<td>249</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://b-live.in/prnewswire/?rkey=20180220enIN201802191749_indiapublic&amp;filter=5082</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>250</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.bangalorewaves.com/news/bangalorewaves-business-news
		.php?rkey=20180220enIN201802191749_indiapublic&amp;filter=2267</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Tech</td>
	</tr>
	<tr>
		<td>251</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://news.biharprabha.com/prnewswire/?rkey=201802
		20enIN201802191749_indiapublic&amp;filter=2270</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>252</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.bizwireexpress.com/showstoryPRN.php?rkey=
		20180220enIN201802191749_indiapublic&amp;filter=2276</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>253</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://businessfortnight.com/pr-newswire/?rkey=20180220enIN201802191749_indiapublic&amp;filter=5117</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>254</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://businessnewsthisweek.com/prnews/?rkey=20180220enIN201802191749_indiapublic&amp;filter=4605</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>255</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.businesssandesh.in/breaking-news/?rkey=20180220enIN201802191749_indiapublic&amp;filter=7621</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>256</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.businesstoday.in/prnewswire/?rkey=20180220enIN201802191749_indiapublic&amp;filter=2418</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Trade Publications</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>257</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://businessviews.in/business-views-press-release-news/
		?rkey=20180220enIN201802191749_indiapublic&amp;filter=908</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Other</td>
	</tr>
	<tr>
		<td>258</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://corecommunique.com/prnewswire/?rkey=20180220enIN201802191749_indiapublic&amp;filter=4754</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>259</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.dsij.in/newswiredetails.aspx?FileName=
		201802202330PR_NEWS_EURO_ND__enIN201802191749_indiapublic</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Financial Data, Research &amp; Analytics</td>
		<td><font face="Arial">Financial</td>
	</tr>
	<tr>
		<td>260</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://dataguru.in/prnewswire.do?rkey=20180220enIN201802191749_indiapublic&amp;filter=2488</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Tech</td>
	</tr>
	<tr>
		<td>261</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.energycentral.com/node/212892/edit?news_processing=1</td>
		<td><font face="Arial">   United States</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Energy</td>
	</tr>
	<tr>
		<td>262</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.enterpriseitworld.com/index.php/PR/
		?rkey=20180220enIN201802191749_indiapublic&amp;filter=4799</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Trade Publications</td>
		<td><font face="Arial">Tech</td>
	</tr>
	<tr>
		<td>263</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://thefastmail.com/index.php/page/detailnews/
		7069?rkey=20180220enIN201802191749_indiapublic&amp;filter=3911</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>264</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://firstreport.in/pr-newswire/?rkey=20180220
		enIN201802191749_indiapublic&amp;filter=6490</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>265</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://goevnts.com/pr-landing?rkey=20180220enIN201802191749_indiapublic&amp;filter=4444</td>
		<td><font face="Arial">   Global</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Business Services</td>
	</tr>
	<tr>
		<td>266</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.greenlifestylemag.com.au/industrynews?rkey
		=20180220enIN201802191749_indiapublic&amp;filter=1867</td>
		<td><font face="Arial">   Global</td>
		<td><font face="Arial">Trade Publications</td>
		<td><font face="Arial">Environment</td>
	</tr>
	<tr>
		<td>267</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.hellomumbainews.com/hello-business/?rkey=201802
		20enIN201802191749_indiapublic&amp;filter=12313</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>268</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.htsyndication.com/htsportal/pr-newswire/article/
		experts-from-50-countries-to-converge-at-the-4th-edition-of-india-smart-grid-week-
		to-discuss-trending-technologies-of-energy-sector/26005902</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>269</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://ians.in/index.php?param=prnewswiredetail/PRN-893132</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>270</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">https://ibtn9.com/pr-newswire/?rkey=20180220enIN201802191749_indiapublic&amp;filter=12202</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>271</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.india-briefing.com/news/partnernews/?r
		key=20180220enIN201802191749_indiapublic&amp;filter=3400</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Financial</td>
	</tr>
	<tr>
		<td>272</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://news.indiaonline.in/prnewswire?rkey=20180220
		enIN201802191749_indiapublic&amp;filter=4991</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>273</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">https://www.indiatoday.in/pr-newswire?rkey=20180220enIN
		201802191749_indiapublic&amp;filter=4315</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Magazine</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>274</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://indiannerve.com/in-press/?rkey=20180220enIN201802191749_indiapublic&amp;filter=6492</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>275</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://indianpowersector.com/prnews/?rkey=20180220enIN201802191749_indiapublic&amp;filter=4997</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Trade Publications</td>
		<td><font face="Arial">Energy</td>
	</tr>
	<tr>
		<td>276</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.indianotes.com/PRNewswire/prnewswire-news-details.
		php?id=enIN201802191749_indiapublic&amp;t=N&amp;v=P</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>277</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://infrabuddy.com/pr-newswire/?rkey=20180220enI
		N201802191749_indiapublic&amp;filter=423</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>278</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.internationalfair.in/pdetails.php?rkey=20180220enIN201802191749_indiapublic&amp;filter=9866</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Business Services</td>
	</tr>
	<tr>
		<td>279</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.livechennai.com/prnewswire/index.asp?rkey=20180220enIN201802191749_indiapublic&amp;filter=12088</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>280</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.marketnewsrelease.com/pr-newswire?rkey=20180220enIN201802191749_indiapublic&amp;filter=10091</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>281</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://mediainfoline.com/releases/?rkey=20180220enIN201802191749_indiapublic&amp;filter=3952</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>282</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://medicinman.net/pr-newswire/?rkey=20180220enIN201802191749_indiapublic&amp;filter=5136</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Trade Publications</td>
		<td><font face="Arial">Health</td>
	</tr>
	<tr>
		<td>283</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://nasheman.in/newswire/?rkey=20180220enIN201802191749_indiapublic&amp;filter=11016</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>284</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.newsbharati.com/prnewswire/?rkey=20180220enIN201802191749_indiapublic&amp;filter=5165</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>285</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://media.newswire.ca/newssuperfastblog.html?rkey=20180220enIN201802191749_indiapublic&amp;filter=10033</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>286</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.news-pr.in/display?rkey=20180220enIN201802191749_indiapublic&amp;filter=12235</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>287</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">https://newsblaze.in/pr-newswire?rkey=20180220enIN201802191749_indiapublic&amp;filter=12696</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>288</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.newsgram.com/press-releases/?rkey=20180220enIN201802191749_indiapublic&amp;filter=590</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>289</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.newsprelease.com/pr-newswire/?rkey=20180220enIN201802191749_indiapublic&amp;filter=10089</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>290</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.newsr.in/prnewswire.php?rkey=20180220enIN201802191749_indiapublic&amp;filter=5070</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Newspaper</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>291</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.northindiakaleidoscope.com/pr-newswire/
		?rkey=20180220enIN201802191749_indiapublic&amp;filter=6817</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>292</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://nrinews24x7.com/prnews.htm?rkey=20180220enIN201802191749_indiapublic&amp;filter=4972</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>293</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">https://eodishasamachar.com/en/pr-newswire-2/?rkey=
		20180220enIN201802191749_indiapublic&amp;filter=4272</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>294</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://odishasuntimes.com/prnews/?rkey=20180220enIN2
		01802191749_indiapublic&amp;filter=4968</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Newspaper</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>295</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.odisha360.com/prn/?rkey=20180220enIN201802191749_indiapublic&amp;filter=4962</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>296</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.ohsem.me/pr-newswire?rkey=20180220enIN201802191749_indiapublic&amp;filter=5817</td>
		<td><font face="Arial">   Malaysia</td>
		<td><font face="Arial">Blog</td>
		<td><font face="Arial">Tech</td>
	</tr>
	<tr>
		<td>297</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.onenewspage.com/prnewswire.php?rkey=20180220enIN201802191749_indiapublic&amp;filter=3968</td>
		<td><font face="Arial">   Global</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>298</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.prnewswire.co.in/news-releases/experts-from-50
		-countries-to-converge-at-the-4th-edition-of-india-smart-grid-week-to-discuss
		-trending-technologies-of-energy-sector-674662293.html</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">PR Newswire</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>299</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://prativad.com/newseng.htm?rkey=20180220enIN201802191749_indiapublic&amp;filter=4617</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>300</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.ptinews.com/pressrelease/28323_press-subExperts-
		From-50-Countries-to-Converge-at-the-4th-Edition-of-India-Smart-Grid-Week-to
		-Discuss-Trending-Technologies-of-Energy-Sector</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>301</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.rnews1.com/p/pr-newswire.html?rkey=20180220
		enIN201802191749_indiapublic&amp;filter=7546</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>302</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://media.newswire.ca/ren-alliance.html?rkey=20180220enIN201802191749_indiapublic&amp;filter=8978</td>
		<td><font face="Arial">   Global</td>
		<td><font face="Arial">Industry Association Sites</td>
		<td><font face="Arial">Energy</td>
	</tr>
	<tr>
		<td>303</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.scoopbig.com/prnewswire/?rkey=20180220enIN201802191749_indiapublic&amp;filter=4435</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>304</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.smarttechtoday.com/prnews/?rkey=20180220enIN201802191749_indiapublic&amp;filter=2496</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Tech</td>
	</tr>
	<tr>
		<td>305</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://specttrumnews.com/news/pr-newswire.aspx?rkey=20180220enIN201802191749_indiapublic&amp;filter=7051</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>306</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">https://startepreneur.com/press-releases/?rkey=20180220enIN201802191749_indiapublic&amp;filter=11454</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>307</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://techblogcorner.com/press-releases/?rkey=20180220enIN201802191749_indiapublic&amp;filter=1980</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Blog</td>
		<td><font face="Arial">Tech</td>
	</tr>
	<tr>
		<td>308</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://techcircle.vccircle.com/press-releases/?rkey=20180220enIN201802191749_indiapublic&amp;filter=2034</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Tech</td>
	</tr>
	<tr>
		<td>309</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://techent.tv/newswire?rkey=20180220enIN201802191749_indiapublic&amp;filter=5758</td>
		<td><font face="Arial">   Malaysia</td>
		<td><font face="Arial">Blog</td>
		<td><font face="Arial">Tech</td>
	</tr>
	<tr>
		<td>310</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.techgenyz.com/pr-newswire/?rkey=20180220enIN201802191749_indiapublic&amp;filter=6463</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Tech</td>
	</tr>
	<tr>
		<td>311</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">https://telanganatoday.com/pr-newswire?rkey=20180220enIN201802191749_indiapublic&amp;filter=11682</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>312</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">https://www.covaipost.com/pr-newswire?rkey=20180220enIN201802191749_indiapublic&amp;filter=11690</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>313</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.thehansindia.com/home/prnewswire?rkey=20180220enIN201802191749_indiapublic&amp;filter=2080</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>314</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://thehawk.in/prnewswire/?rkey=20180220enIN201802191749_indiapublic&amp;filter=4853</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Newspaper</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>315</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.thepowertimes.in/index.php/daily-updates/national.
		html?rkey=20180220enIN201802191749_indiapublic&amp;filter=2061</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Trade Publications</td>
		<td><font face="Arial">Energy</td>
	</tr>
	<tr>
		<td>316</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://media.newswire.ca/tecake.html?rkey=20180220enIN2
		01802191749_indiapublic&amp;filter=6362</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Tech</td>
	</tr>
	<tr>
		<td>317</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://thetechportal.com/press-releases-pr-newswire/?rkey=
		20180220enIN201802191749_indiapublic&amp;filter=1985</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Trade Publications</td>
		<td><font face="Arial">Tech</td>
	</tr>
	<tr>
		<td>318</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://timestech.info/trends-forecast/?rkey=20180220enIN
		201802191749_indiapublic&amp;filter=11572</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Tech</td>
	</tr>
	<tr>
		<td>319</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.tmcnet.com/usubmit/2018/02/20/8703831.htm</td>
		<td><font face="Arial">   United States</td>
		<td><font face="Arial">Trade Publications</td>
		<td><font face="Arial">Tech</td>
	</tr>
	<tr>
		<td>320</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.varindia.com/news/1529595?rkey=20180220enIN201802191749_indiapublic&amp;filter=537</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Tech</td>
	</tr>
	<tr>
		<td>321</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://media.newswire.ca/whatsnewonthenet.html?rkey=20180220enIN201802191749_indiapublic&amp;filter=299</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Blog</td>
		<td><font face="Arial">Tech</td>
	</tr>
	<tr>
		<td>322</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.5dariyanews.com/Full-Story-Latest-from-PR-Newswire
		.aspx?rkey=20180301enIN201802282776_indiapublic&amp;filter=3325</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>333</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.abhitaknews.com/english/news/press-releases.aspx?r
		key=20180301enIN201802282776_indiapublic&amp;filter=1889</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>334</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.asianbuck.com/asianbuck-prnews/?rkey=20180301enIN201802282776_indiapublic&amp;filter=8421</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>335</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://assignmenteditor.com/pr-newswire-3/?rkey=20180301enIN201802282776_indiapublic&amp;filter=1673</td>
		<td><font face="Arial">   Global</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>336</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.ai-online.com/prnewswire/?rkey=20180301enIN201802282776_indiapublic&amp;filter=1271</td>
		<td><font face="Arial">   Global</td>
		<td><font face="Arial">Trade Publications</td>
		<td><font face="Arial">Transportation</td>
	</tr>
	<tr>
		<td>337</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.bangalorewaves.com/news/bangalorewaves-business-news
		.php?rkey=20180301enIN201802282776_indiapublic&amp;filter=2267</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Tech</td>
	</tr>
	<tr>
		<td>338</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://news.biharprabha.com/prnewswire/?rkey=20180301enIN201802282776_indiapublic&amp;filter=2270</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>339</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.bizwireexpress.com/showstoryPRN.php?rkey=20180301enIN201802282776_indiapublic&amp;filter=2276</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>340</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.biznews.in/article/smart-energy-conference-india-smart
		-grid-week-to-be-inaugurated-by-power-minister-shri-raj-kumar-singh</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Other</td>
	</tr>
	<tr>
		<td>341</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://businessfortnight.com/pr-newswire/?rkey=20180301enIN201802282776_indiapublic&amp;filter=5117</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>342</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://businessnewsthisweek.com/prnews/?rkey=20180301enIN201802282776_indiapublic&amp;filter=4605</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>343</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.businesssandesh.in/breaking-news/?rkey=20180301enIN201802282776_indiapublic&amp;filter=7621</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>344</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.businesstoday.in/prnewswire/?rkey=20180301enIN201802282776_indiapublic&amp;filter=2418</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Trade Publications</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>345</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://corecommunique.com/prnewswire/?rkey=20180301enIN201802282776_indiapublic&amp;filter=4754</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>346</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.dsij.in/newswiredetails.aspx?FileName=201803010000PR_NEWS_EURO_ND__enIN201802282776_indiapublic</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Financial Data, Research &amp; Analytics</td>
		<td><font face="Arial">Financial</td>
	</tr>
	<tr>
		<td>347</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://dataguru.in/prnewswire.do?rkey=20180301enIN201802282776_indiapublic&amp;filter=2488</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Tech</td>
	</tr>
	<tr>
		<td>348</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.energycentral.com/node/218301/edit?news_processing=1</td>
		<td><font face="Arial">   United States</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Energy</td>
	</tr>
	<tr>
		<td>349</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://thefastmail.com/index.php/page/detailnews/7069?rkey=20180301enIN201802282776_indiapublic&amp;filter=3911</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>350</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://firstreport.in/pr-newswire/?rkey=20180301enIN201802282776_indiapublic&amp;filter=6490</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>351</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://goevnts.com/pr-landing?rkey=20180301enIN201802282776_indiapublic&amp;filter=4444</td>
		<td><font face="Arial">   Global</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Business Services</td>
	</tr>
	<tr>
		<td>352</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.hellomumbainews.com/hello-business/?rkey=20180301enIN201802282776_indiapublic&amp;filter=12313</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>353</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.htsyndication.com/htsportal/pr-newswire/article/smart
		-energy-conference-india-smart-grid-week-to-be-inaugurated
		-by-power-minister-shri-raj-kumar-singh/26142735</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>354</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://ians.in/index.php?param=prnewswiredetail/PRN-906900</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>355</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">https://ibtn9.com/pr-newswire/?rkey=20180301enIN201802282776_indiapublic&amp;filter=12202</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>356</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.india-briefing.com/news/partnernews/?rkey=20180301enIN201802282776_indiapublic&amp;filter=3400</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Financial</td>
	</tr>
	<tr>
		<td>357</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://news.indiaonline.in/prnewswire?rkey=20180301enIN201802282776_indiapublic&amp;filter=4991</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>358</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">https://www.indiatoday.in/pr-newswire?rkey=20180301enIN201802282776_indiapublic&amp;filter=4315</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Magazine</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>359</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://indiannerve.com/in-press/?rkey=20180301enIN201802282776_indiapublic&amp;filter=6492</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>360</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://indianpowersector.com/prnews/?rkey=20180301enIN201802282776_indiapublic&amp;filter=4997</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Trade Publications</td>
		<td><font face="Arial">Energy</td>
	</tr>
	<tr>
		<td>361</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.indianotes.com/PRNewswire/prnewswire-news-details.php?id=enIN201802282776_indiapublic&amp;t=N&amp;v=P</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>362</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://infrabuddy.com/pr-newswire/?rkey=20180301enIN201802282776_indiapublic&amp;filter=423</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>363</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.internationalfair.in/pdetails.php?rkey=20180301enIN201802282776_indiapublic&amp;filter=9866</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Business Services</td>
	</tr>
	<tr>
		<td>364</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.livechennai.com/prnewswire/index.asp?rkey=20180301enIN201802282776_indiapublic&amp;filter=12088</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>365</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.marketnewsrelease.com/pr-newswire?rkey=20180301enIN201802282776_indiapublic&amp;filter=10091</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>366</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://mediainfoline.com/releases/?rkey=20180301enIN201802282776_indiapublic&amp;filter=3952</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>367</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://medicinman.net/pr-newswire/?rkey=20180301enIN201802282776_indiapublic&amp;filter=5136</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Trade Publications</td>
		<td><font face="Arial">Health</td>
	</tr>
	<tr>
		<td>368</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://nasheman.in/newswire/?rkey=20180301enIN201802282776
		_indiapublic&amp;filter=11016&amp;Smart-Energy-Conference-India-Smart-Grid-Week
		-to-be-Inaugurated-by-Power-Minister-Shri-Raj-Kumar-Singh</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>369</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.newsbharati.com/prnewswire/?rkey=20180301enIN201802282776_indiapublic&amp;filter=5165</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>370</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://media.newswire.ca/newssuperfastblog.html?rkey=20180301enIN201802282776_indiapublic&amp;filter=10033</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>371</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.news-pr.in/display?rkey=20180301enIN201802282776_indiapublic&amp;filter=12235</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>372</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">https://newsblaze.in/pr-newswire?rkey=20180301enIN201802282776_indiapublic&amp;filter=12696</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>373</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.newsprelease.com/pr-newswire/?rkey=20180301enIN201802282776_indiapublic&amp;filter=10089</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>374</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.newsr.in/prnewswire.php?rkey=20180301enIN201802282776_indiapublic&amp;filter=5070</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Newspaper</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>375</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.northindiakaleidoscope.com/pr-newswire/?rkey=20180301enIN201802282776_indiapublic&amp;filter=6817</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>376</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://nrinews24x7.com/prnews.htm?rkey=20180301enIN201802282776_indiapublic&amp;filter=4972</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>377</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">https://eodishasamachar.com/en/pr-newswire-2/?rkey=20180301enIN201802282776_indiapublic&amp;filter=4272</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>378</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://odishasuntimes.com/prnews/?rkey=20180301enIN201802282776_indiapublic&amp;filter=4968</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Newspaper</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>379</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.odisha360.com/prn/?rkey=20180301enIN201802282776_indiapublic&amp;filter=4962</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>380</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.onenewspage.com/prnewswire.php?rkey=20180301enIN201802282776_indiapublic&amp;filter=3968</td>
		<td><font face="Arial">   Global</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>381</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.prnewswire.co.in/news-releases/smart-energy-conference-india-smart-grid-
		week-to-be-inaugurated-by-power-minister-shri-raj-kumar-singh-675492293.html</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">PR Newswire</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>382</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://prativad.com/newseng.htm?rkey=20180301enIN201802282776_indiapublic&amp;filter=4617</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>383</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.ptinews.com/pressrelease/28478_press-subSmart-Energy-
		Conference-India-Smart-Grid-Week-to-be-Inaugurated
		-by-Power-Minister-Shri-Raj-Kumar-Singh</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>384</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.rnews1.com/p/pr-newswire.html?rkey=
		20180301enIN201802282776_indiapublic&amp;filter=7546</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>385</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://media.newswire.ca/ren-alliance.html?rkey=20180301enIN201802282776_indiapublic&amp;filter=8978</td>
		<td><font face="Arial">   Global</td>
		<td><font face="Arial">Industry Association Sites</td>
		<td><font face="Arial">Energy</td>
	</tr>
	<tr>
		<td>386</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.samacharlive.com/Business/smart-energy-conference
		-india-smart-grid-week-to-be-inaugurated-by-power-minister-shri-raj-kumar-singh</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>387</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.scoopbig.com/prnewswire/?rkey=20180301en
		IN201802282776_indiapublic&amp;filter=4435</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>388</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.smarttechtoday.com/prnews/?rkey=20180301enIN201802282776_indiapublic&amp;filter=2496</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Tech</td>
	</tr>
	<tr>
		<td>389</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://specttrumnews.com/news/pr-newswire.aspx?rkey=20180301enIN201802282776_indiapublic&amp;filter=7051</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>390</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">https://startepreneur.com/press-releases/?rkey=20180301enIN201802282776_indiapublic&amp;filter=11454</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>391</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">https://telanganatoday.com/pr-newswire?rkey=20180301enIN201802282776_indiapublic&amp;filter=11682</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>392</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">https://www.covaipost.com/pr-newswire?rkey=20180301enIN201802282776_indiapublic&amp;filter=11690</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>393</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.thehansindia.com/home/prnewswire?rkey=20180301enIN201802282776_indiapublic&amp;filter=2080</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>394</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://thehawk.in/prnewswire/?rkey=20180301enIN201802282776_indiapublic&amp;filter=4853</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Newspaper</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>395</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.thepowertimes.in/index.php/daily-updates/national.html?rkey=20180301enIN201802282776_indiapublic&amp;filter=2061</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Trade Publications</td>
		<td><font face="Arial">Energy</td>
	</tr>
	<tr>
		<td>396</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">https://news.webindia123.com/news/press_showdetailsPR.asp?id=1093437&amp;cat=PR%20News%20Wire</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Trade Publications</td>
		<td><font face="Arial">Financial</td>
	</tr>
	<tr>
		<td>397</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.5dariyanews.com/Full-Story-Latest-from-PR-Newswire
		.aspx?rkey=20180220enIN201802191749_indiapublic&amp;filter=3325</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>398</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.abhitaknews.com/english/news/press-releases.aspx
		?rkey=20180220enIN201802191749_indiapublic&amp;filter=1889</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>399</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.asianbuck.com/asianbuck-prnews/?rkey=2018022
		0enIN201802191749_indiapublic&amp;filter=8421</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>400</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://assignmenteditor.com/pr-newswire-3/?rkey=20180220enIN201802191749_indiapublic&amp;filter=1673</td>
		<td><font face="Arial">   Global</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td> 205" 205</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.ai-online.com/prnewswire/?rkey=20180220enIN201802191749_indiapublic&amp;filter=1271</td>
		<td><font face="Arial">   Global</td>
		<td><font face="Arial">Trade Publications</td>
		<td><font face="Arial">Transportation</td>
	</tr>
	<tr>
		<td> 204" 204</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://b-live.in/prnewswire/?rkey=20180220enIN201802191749_indiapublic&amp;filter=5082</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>  203" 203</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.bangalorewaves.com/news/bangalorewaves-business-news.
		php?rkey=20180220enIN201802191749_indiapublic&amp;filter=2267</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Tech</td>
	</tr>
	<tr>
		<td>  202" 202</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://news.biharprabha.com/prnewswire/?rkey=20180220enI
		N201802191749_indiapublic&amp;filter=2270</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td> 201" 201</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.bizwireexpress.com/showstoryPRN.php?rkey=20180220enIN201802191749_indiapublic&amp;filter=2276</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td> 200" 200</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://businessfortnight.com/pr-newswire/?rkey=20180220enIN201802191749_indiapublic&amp;filter=5117</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>   199" 199</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://businessnewsthisweek.com/prnews/?rkey=20180220enIN201802191749_indiapublic&amp;filter=4605</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td> 198" 198</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.businesssandesh.in/breaking-news/?rkey=20180220enIN201802191749_indiapublic&amp;filter=7621</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>  197" 197</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.businesstoday.in/prnewswire/?rkey=20180220enIN201802191749_indiapublic&amp;filter=2418</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Trade Publications</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="186"   196" 196</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://businessviews.in/business-views-press-release-
		news/?rkey=20180220enIN201802191749_indiapublic&amp;filter=908</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Other</td>
	</tr>
	<tr>
		<td>  195" 195</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://corecommunique.com/prnewswire/?rkey=20180220enIN201802191749_indiapublic&amp;filter=4754</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="186"   194" 194</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.dsij.in/newswiredetails.aspx?FileName=201802202330PR_NEWS_EURO_ND__enIN201802191749_indiapublic</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Financial Data, Research &amp; Analytics</td>
		<td><font face="Arial">Financial</td>
	</tr>
	<tr>
		<td>  193" 193</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://dataguru.in/prnewswire.do?rkey=20180220enIN201802191749_indiapublic&amp;filter=2488</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Tech</td>
	</tr>
	<tr>
		<td> 192" 192</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.energycentral.com/node/212892/edit?news_processing=1</td>
		<td><font face="Arial">   United States</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Energy</td>
	</tr>
	<tr>
		<td> ="62"   191" 191</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.enterpriseitworld.com/index.php/PR/?rkey=20180220enIN201802191749_indiapublic&amp;filter=4799</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Trade Publications</td>
		<td><font face="Arial">Tech</td>
	</tr>
	<tr>
		<td>  190" 190</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://thefastmail.com/index.php/page/detailnews/7069?rkey=20180220enIN201802191749_indiapublic&amp;filter=3911</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td> 189" 189</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://firstreport.in/pr-newswire/?rkey=20180220enIN201802191749_indiapublic&amp;filter=6490</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>  188" 188</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://goevnts.com/pr-landing?rkey=20180220enIN201802191749_indiapublic&amp;filter=4444</td>
		<td><font face="Arial">   Global</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Business Services</td>
	</tr>
	<tr>
		<td> 187" 187</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.greenlifestylemag.com.au/industrynews?rkey=20180220enIN201802191749_indiapublic&amp;filter=1867</td>
		<td><font face="Arial">   Global</td>
		<td><font face="Arial">Trade Publications</td>
		<td><font face="Arial">Environment</td>
	</tr>
	<tr>
		<td>  186" 186</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.hellomumbainews.com/hello-business/?rkey=20180220enIN201802191749_indiapublic&amp;filter=12313</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>  185" 185</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.htsyndication.com/htsportal/pr-newswire/article/experts-from-
		50-countries-to-converge-at-the-4th-edition-of-india-smart-grid
		-week-to-discuss-trending-technologies-of-energy-sector/26005902</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>  184" 184</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://ians.in/index.php?param=prnewswiredetail/PRN-893132</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>  183" 183</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">https://ibtn9.com/pr-newswire/?rkey=20180220enIN201802191749_indiapublic&amp;filter=12202</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td> 182" 182</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.india-briefing.com/news/partnernews/?rkey=20180220enIN201802191749_indiapublic&amp;filter=3400</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Financial</td>
	</tr>
	<tr>
		<td> 181" 181</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://news.indiaonline.in/prnewswire?rkey=20180220enIN201802191749_indiapublic&amp;filter=4991</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>  180" 180</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">https://www.indiatoday.in/pr-newswire?rkey=20180220enIN201802191749_indiapublic&amp;filter=4315</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Magazine</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>  179" 179</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://indiannerve.com/in-press/?rkey=20180220enIN201802191749_indiapublic&amp;filter=6492</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="62"   178" 178</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://indianpowersector.com/prnews/?rkey=20180220enIN201802191749_indiapublic&amp;filter=4997</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Trade Publications</td>
		<td><font face="Arial">Energy</td>
	</tr>
	<tr>
		<td>  177" 177</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.indianotes.com/PRNewswire/prnewswire-news-
		details.php?id=enIN201802191749_indiapublic&amp;t=N&amp;v=P</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td> 176" 176</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://infrabuddy.com/pr-newswire/?rkey=20180220enIN201802191749_indiapublic&amp;filter=423</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="165"   175" 175</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.internationalfair.in/pdetails.php?rkey=20180220enIN201802191749_indiapublic&amp;filter=9866</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Business Services</td>
	</tr>
	<tr>
		<td>  174" 174</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.livechennai.com/prnewswire/index.asp?rkey=20180220enIN201802191749_indiapublic&amp;filter=12088</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="165"   173" 173</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.marketnewsrelease.com/pr-newswire?rkey=20180220enIN201802191749_indiapublic&amp;filter=10091</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>  172" 172</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://mediainfoline.com/releases/?rkey=20180220enIN201802191749_indiapublic&amp;filter=3952</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>  171" 171</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://medicinman.net/pr-newswire/?rkey=20180220enIN201802191749_indiapublic&amp;filter=5136</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Trade Publications</td>
		<td><font face="Arial">Health</td>
	</tr>
	<tr>
		<td>  170" 170</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://nasheman.in/newswire/?rkey=20180220enIN201802191749_indiapublic&amp;filter=11016</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>  169" 169</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.newsbharati.com/prnewswire/?rkey=20180220enIN201802191749_indiapublic&amp;filter=5165</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>  168" 168</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://media.newswire.ca/newssuperfastblog.html?rkey=20180220enIN201802191749_indiapublic&amp;filter=10033</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>  167" 167</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.news-pr.in/display?rkey=20180220enIN201802191749_indiapublic&amp;filter=12235</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>  166" 166</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">https://newsblaze.in/pr-newswire?rkey=20180220enIN201802191749_indiapublic&amp;filter=12696</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>  165" 165</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.newsgram.com/press-releases/?rkey=20180220enIN201802191749_indiapublic&amp;filter=590</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>  164" 164</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.newsprelease.com/pr-newswire/?rkey=20180220enIN201802191749_indiapublic&amp;filter=10089</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>  163" 163</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.newsr.in/prnewswire.php?rkey=20180220enIN201802191749_indiapublic&amp;filter=5070</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Newspaper</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>  162" 162</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.northindiakaleidoscope.com/pr-newswire/?rkey=20180220enIN201802191749_indiapublic&amp;filter=6817</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="62"   161" 161</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://nrinews24x7.com/prnews.htm?rkey=20180220enIN201802191749_indiapublic&amp;filter=4972</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td> 160" 160</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">https://eodishasamachar.com/en/pr-newswire-2/?rkey=20180220enIN201802191749_indiapublic&amp;filter=4272</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td> 159" 159</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://odishasuntimes.com/prnews/?rkey=20180220enIN201802191749_indiapublic&amp;filter=4968</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Newspaper</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="62"   158" 158</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.odisha360.com/prn/?rkey=20180220enIN201802191749_indiapublic&amp;filter=4962</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>  157" 157</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.ohsem.me/pr-newswire?rkey=20180220enIN201802191749_indiapublic&amp;filter=5817</td>
		<td><font face="Arial">   Malaysia</td>
		<td><font face="Arial">Blog</td>
		<td><font face="Arial">Tech</td>
	</tr>
	<tr>
		<td>  156" 156</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.onenewspage.com/prnewswire.php?rkey=20180220enIN201802191749_indiapublic&amp;filter=3968</td>
		<td><font face="Arial">   Global</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="41"   155" 155</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.prnewswire.co.in/news-releases/experts-from-50-countries-to-converge-at-the
		-4th-edition-of-india-smart-grid-week-to-discuss-trending
		-technologies-of-energy-sector-674662293.html</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">PR Newswire</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td> 154" 154</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://prativad.com/newseng.htm?rkey=20180220enIN201802191749_indiapublic&amp;filter=4617</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="62"   153" 153</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.ptinews.com/pressrelease/28323_press-subExperts-From-50-Countries-to-Converge-at-the
		-4th-Edition-of-India-Smart-Grid-Week-to-Discuss-
		Trending-Technologies-of-Energy-Sector</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>  152" 152</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.rnews1.com/p/pr-newswire.html?rkey=20180220enIN201802191749_indiapublic&amp;filter=7546</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="165"   151" 151</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://media.newswire.ca/ren-alliance.html?rkey=20180220enIN201802191749_indiapublic&amp;filter=8978</td>
		<td><font face="Arial">   Global</td>
		<td><font face="Arial">Industry Association Sites</td>
		<td><font face="Arial">Energy</td>
	</tr>
	<tr>
		<td> 150" 150</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.scoopbig.com/prnewswire/?rkey=20180220enIN201802191749_indiapublic&amp;filter=4435</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="62"   149" 149</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.smarttechtoday.com/prnews/?rkey=20180220enIN201802191749_indiapublic&amp;filter=2496</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Tech</td>
	</tr>
	<tr>
		<td> 148" 148</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://specttrumnews.com/news/pr-newswire.aspx?rkey=20180220enIN201802191749_indiapublic&amp;filter=7051</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>  147" 147</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">https://startepreneur.com/press-releases/?rkey=20180220enIN201802191749_indiapublic&amp;filter=11454</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td> 146" 146</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://techblogcorner.com/press-releases/?rkey=20180220enIN201802191749_indiapublic&amp;filter=1980</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Blog</td>
		<td><font face="Arial">Tech</td>
	</tr>
	<tr>
		<td>  145" 145</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://techcircle.vccircle.com/press-releases/?rkey=20180220enIN201802191749_indiapublic&amp;filter=2034</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">News &amp; Information Service</td>
		<td><font face="Arial">Tech</td>
	</tr>
	<tr>
		<td>  144" 144</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://techent.tv/newswire?rkey=20180220enIN201802191749_indiapublic&amp;filter=5758</td>
		<td><font face="Arial">   Malaysia</td>
		<td><font face="Arial">Blog</td>
		<td><font face="Arial">Tech</td>
	</tr>
	<tr>
		<td>  143" 143</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.techgenyz.com/pr-newswire/?rkey=20180220enIN201802191749_indiapublic&amp;filter=6463</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Tech</td>
	</tr>
	<tr>
		<td> 142" 142</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">https://telanganatoday.com/pr-newswire?rkey=20180220enIN201802191749_indiapublic&amp;filter=11682</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td> 141" 141</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">https://www.covaipost.com/pr-newswire?rkey=20180220enIN201802191749_indiapublic&amp;filter=11690</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="165"   140" 140</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.thehansindia.com/home/prnewswire?rkey=20180220enIN201802191749_indiapublic&amp;filter=2080</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>  139" 139</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://thehawk.in/prnewswire/?rkey=20180220enIN201802191749_indiapublic&amp;filter=4853</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Newspaper</td>
		<td><font face="Arial">Media &amp; Information</td>
	</tr>
	<tr>
		<td>  138" 138</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.thepowertimes.in/index.php/daily-updates/national
		.html?rkey=20180220enIN201802191749_indiapublic&amp;filter=2061</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Trade Publications</td>
		<td><font face="Arial">Energy</td>
	</tr>
	<tr>
		<td> 137" 137</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://media.newswire.ca/tecake.html?rkey=20180220enIN201802191749_indiapublic&amp;filter=6362</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Tech</td>
	</tr>
	<tr>
		<td>  136" 136</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://thetechportal.com/press-releases-pr-newswire/?rkey=2018022
		0enIN201802191749_indiapublic&amp;filter=1985</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Trade Publications</td>
		<td><font face="Arial">Tech</td>
	</tr>
	<tr>
		<td>  135" 135</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://timestech.info/trends-forecast/?rkey=20180220enIN201802191749_indiapublic&amp;filter=11572</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Tech</td>
	</tr>
	<tr>
		<td>  134" 134</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.tmcnet.com/usubmit/2018/02/20/8703831.htm</td>
		<td><font face="Arial">   United States</td>
		<td><font face="Arial">Trade Publications</td>
		<td><font face="Arial">Tech</td>
	</tr>
	<tr>
		<td>  133" 133</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://www.varindia.com/news/1529595?rkey=20180220enIN201802191749_indiapublic&amp;filter=537</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Online News Sites &amp; Other Influencers</td>
		<td><font face="Arial">Tech</td>
	</tr>
	<tr>
		<td> 132" 132</td>
		<td>ISGW 2018 NEWS</td>
		<td><font face="Arial">English</td>
		<td><font face="Arial">Online</td>
		<td><font face="Arial">http://media.newswire.ca/whatsnewonthenet.html?rkey=20180220enIN201802191749_indiapublic&amp;filter=299</td>
		<td><font face="Arial">   India</td>
		<td><font face="Arial">Blog</td>
		<td><font face="Arial">Tech</td>
	</tr>
	<tr>
		<td>   131" 131</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>5 Dariya News</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.5dariyanews.com/Full-Story-Latest-from-PR-Newswire
		.aspx?rkey=20190226enIN201902257063_indiapublic&amp;filter=3325</td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="62"   130" 130</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Abhitak News [English]</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.abhitaknews.com/english/news/press-releases.aspx
		?rkey=20190226enIN201902257063_indiapublic&amp;filter=1889</td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="62"   129" 129</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Asianbuck</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.asianbuck.com/asianbuck-prnews/?rkey=20190226enIN201902257063_indiapublic&amp;filter=8421</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>   128" 128</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Bangalore Waves</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.bangalorewaves.com/news/bangalorewaves-business
		-news.php?rkey=20190226enIN201902257063_indiapublic&amp;filter=2267</td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Tech</td>
	</tr>
	<tr>
		<td> ="62"   127" 127</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Biharprabha News</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://news.biharprabha.com/prnewswire/?rkey=20190226enIN201902257063_indiapublic&amp;filter=2270</td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 126" 126</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Biz Wire Express</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.bizwireexpress.com/showstoryPRN.php?rkey=20190226enIN201902257063_indiapublic&amp;filter=2276</td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>  125" 125</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Business Fortnight</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://businessfortnight.com/pr-newswire/?rkey=20190226enIN201902257063_indiapublic&amp;filter=5117</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="41"   124" 124</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Business News 
		This Week</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://businessnewsthisweek.com/prnews/?rkey=20190226enIN201902257063_indiapublic&amp;filter=601</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="186"   123" 123</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Business Sandesh</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.businesssandesh.in/breaking-news/?rkey=20190226enIN201902257063_indiapublic&amp;filter=7621</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>   122" 122</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Business Today
		India</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.businesstoday.in/prnewswire/?rkey=20190226enIN201902257063_indiapublic&amp;filter=2418</td>
		<td><font size=3>   India</td>
		<td><font size=3>Trade Publications</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>   121" 121</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Connect Gujarat</td>
		<td><font size=3>Online</td>
		<td><font size=3>https://connectgujarat.com/pr-newswire/?rkey=20190226enIN201902257063_indiapublic&amp;filter=14881</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="165"   120" 120</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Core Sector Communique</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://corecommunique.com/prnewswire/?rkey=20190226enIN201902257063_indiapublic&amp;filter=4754</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="62"   119" 119</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Corporate Ethos</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://corporateethos.com/pr-newswire/?rkey=20190226enIN201902257063_indiapublic&amp;filter=6430</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="186"   118" 118</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Creative Bharat</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://creativebharat.com/pr-news-wire/india-smart-utility-week-
		2019-to-be-inaugurated-by-shri-ak-bhalla-secretary
		-ministry-of-power-on-march-13-2019/</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>   117" 117</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Dalal Street 
		Investment Journal</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.dsij.in/newswiredetails.aspx?FileName=201902260000PR_NEWS_EURO_ND__enIN201902257063_indiapublic</td>
		<td><font size=3>   India</td>
		<td><font size=3>Financial Data, Research &amp; Analytics</td>
		<td><font size=3>Financial</td>
	</tr>
	<tr>
		<td>   116" 116</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>EnergyCentral.com</td>
		<td><font size=3>Online</td>
		<td><font size=3>https://www.energycentral.com/node/346873/edit?news_processing=1</td>
		<td><font size=3>   United States</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Energy</td>
	</tr>
	<tr>
		<td>   115" 115</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Fast Mail</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://thefastmail.com/index.php/page/detailnews/7069?rkey=20190226enIN201902257063_indiapublic&amp;filter=3911</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="207"   114" 114</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>First Report</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://firstreport.in/pr-newswire/?rkey=20190226enIN201902257063_indiapublic&amp;filter=6490</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="165"   113" 113</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>GoEvnts.com</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://goevnts.com/pr-landing?rkey=20190226enIN201902257063_indiapublic&amp;filter=4444</td>
		<td><font size=3>   Global</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Business Services</td>
	</tr>
	<tr>
		<td> ="145"   112" 112</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Green Lichen</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://greenlichen.com/pr-newswire/?rkey=20190226enIN201902257063_indiapublic&amp;filter=15918</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Environment</td>
	</tr>
	<tr>
		<td> ="165"   111" 111</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Hello Mumbai</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.hellomumbainews.com/hello-business/?rkey=20190226enIN201902257063_indiapublic&amp;filter=12313</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>   110" 110</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>HT Syndication</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.htsyndication.com/htsportal/pr-newswire/article/india-smart-
		utility-week-2019-to-be-inaugurated-by-shri-ak-bhalla%2C-
		secretary%2C-ministry-of-power-on-march-13%2C-2019/33129209</td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 109" 109</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>IANS India</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://ians.in/index.php?param=prnewswiredetail/PRN-1028446</td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="62"   108" 108</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>IBTN9</td>
		<td><font size=3>Online</td>
		<td><font size=3>https://ibtn9.com/pr-newswire/?rkey=20190226enIN201902257063_indiapublic&amp;filter=12202</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="62"   107" 107</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>India Briefing</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.india-briefing.com/news/partnernews/?rkey=20190226enIN201902257063_indiapublic&amp;filter=3400</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Financial</td>
	</tr>
	<tr>
		<td> ="145"   106" 106</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>India Online</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://news.indiaonline.in/prnewswire?rkey=20190226enIN201902257063_indiapublic&amp;filter=4991</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 105" 105</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>India Today</td>
		<td><font size=3>Online</td>
		<td><font size=3>https://www.indiatoday.in/pr-newswire?rkey=20190226enIN201902257063_indiapublic&amp;filter=4315</td>
		<td><font size=3>   India</td>
		<td><font size=3>Magazine</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="145"   104" 104</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Indian Nerve</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://indiannerve.com/in-press/?rkey=20190226enIN201902257063_indiapublic&amp;filter=6492</td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 103" 103</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Indian Power Sector</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://indianpowersector.com/prnews/?rkey=20190226enIN201902257063_indiapublic&amp;filter=4997</td>
		<td><font size=3>   India</td>
		<td><font size=3>Trade Publications</td>
		<td><font size=3>Energy</td>
	</tr>
	<tr>
		<td>  102" 102</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Indore Dil Se</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://indoredilse.com/english-news/?rkey=20190226enIN201902257063_indiapublic&amp;filter=10474</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="62"   101" 101</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Infrabuddy</td>
		<td><font size=3>Online</td>
		<td><font size=3>https://www.infrabuddy.com/pr-news/?rkey=20190226enIN201902257063_indiapublic&amp;filter=14749</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="186"   100" 100</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>International Fair</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.internationalfair.in/pdetails.php?rkey=20190226enIN201902257063_indiapublic&amp;filter=9866</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Business Services</td>
	</tr>
	<tr>
		<td>  99" 99</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>MedicinMan</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://medicinman.net/pr-newswire/?rkey=20190226enIN201902257063_indiapublic&amp;filter=5136</td>
		<td><font size=3>   India</td>
		<td><font size=3>Trade Publications</td>
		<td><font size=3>Health</td>
	</tr>
	<tr>
		<td>  98" 98</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Nasheman</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://nasheman.in/newswire/?rkey=20190226enIN201902257063_indiapublic&amp;filter=11016</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 97" 97</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>New Delhi Times</td>
		<td><font size=3>Online</td>
		<td><font size=3>https://www.newdelhitimes.com/news-release/?rkey=20190226enIN201902257063_indiapublic&amp;filter=5147</td>
		<td><font size=3>   India</td>
		<td><font size=3>Newspaper</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>   96" 96</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>News Bharati</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.newsbharati.com/prnewswire/?rkey=20190226enIN201902257063_indiapublic&amp;filter=5165</td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 95" 95</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>News Superfast</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://media.newswire.ca/newssuperfastblog.html?rkey=20190226enIN201902257063_indiapublic&amp;filter=10033</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="165"   94" 94</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>News-PR</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.news-pr.in/display?rkey=20190226enIN201902257063_indiapublic&amp;filter=12235</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="227"   93" 93</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>NewsBlaze India</td>
		<td><font size=3>Online</td>
		<td><font size=3>https://newsblaze.in/pr-newswire?rkey=20190226enIN201902257063_indiapublic&amp;filter=12696</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>  92" 92</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>NewsGram</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.newsgram.com/press-releases/?rkey=20190226enIN201902257063_indiapublic&amp;filter=590</td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td>   91" 91</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>NewsR.in</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.newsr.in/prnewswire.php?rkey=20190226enIN201902257063_indiapublic&amp;filter=5070</td>
		<td><font size=3>   India</td>
		<td><font size=3>Newspaper</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="41"   90" 90</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Odisha Samachar</td>
		<td><font size=3>Online</td>
		<td><font size=3>https://eodishasamachar.com/en/?page_id=16613&amp;rkey=20190226enIN201902257063_indiapublic&amp;filter=4272</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="97"   89" 89</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Odisha Sun
		Times</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://odishasuntimes.com/prnews/?rkey=20190226enIN201902257063_indiapublic&amp;filter=4968</td>
		<td><font size=3>   India</td>
		<td><font size=3>Newspaper</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="97"   88" 88</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Odisha360</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.odisha360.com/prn/?rkey=20190226enIN201902257063_indiapublic&amp;filter=4962</td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="68"   87" 87</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>One News Page
		Global Edition</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.onenewspage.com/prnewswire.php?rkey=20190226enIN201902257063_indiapublic&amp;filter=3968</td>
		<td><font size=3>   Global</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="85"   86" 86</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>PR Newswire</td>
		<td><font size=3>Online</td>
		<td><font size=3>https://www.prnewswire.com/in/news-releases/india-smart-utility-week-2019-to-be-inaugurated-by-shri-ak-bhalla-secretary-ministry-of-power-on-march-13-2019-830149102.html</td>
		<td><font size=3>   United States</td>
		<td><font size=3>PR Newswire</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="185"   85" 85</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Prativad</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://prativad.com/newseng.htm?rkey=20190226enIN201902257063_indiapublic&amp;filter=4617</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="68"   84" 84</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Press Trust 
		of India</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.ptinews.com/pressrelease/33973_press-subIndia-Smart-Utility-Week-2019
		-to-be-Inaugurated-by-Shri-AK-Bhalla--Secretary--
		Ministry-of-Power-on-March-13--2019</td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="51"   83" 83</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Review Street</td>
		<td><font size=3>Online</td>
		<td><font size=3>https://reviewstreet.in/news-reviews-mobiles-gadgets-pcs-automobile
		/prnewswireindia/?rkey=20190226enIN201902257063
		_indiapublic&amp;filter=15937</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="51"   82" 82</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Smart Tech Today</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.smarttechtoday.com/prnews/?rkey=20190226enIN201902257063_indiapublic&amp;filter=2496</td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Tech</td>
	</tr>
	<tr>
		<td> ="68"   81" 81</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>SME Street</td>
		<td><font size=3>Online</td>
		<td><font size=3>https://smestreet.in/infocus/prnewswireindia/?rkey=20190226enIN201902257063_indiapublic&amp;filter=15935</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="51"   80" 80</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>TechGenYZ</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.techgenyz.com/pr-newswire/?rkey=20190226enIN201902257063_indiapublic&amp;filter=6463</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Tech</td>
	</tr>
	<tr>
		<td> ="68"   79" 79</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Telangana Today</td>
		<td><font size=3>Online</td>
		<td><font size=3>https://telanganatoday.com/pr-newswire?rkey=20190226enIN201902257063_indiapublic&amp;filter=11682</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="68"   78" 78</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>The Hans India</td>
		<td><font size=3>Online</td>
		<td><font size=3>https://www.thehansindia.com/home/prnewswire?rkey=20190226enIN201902257063_indiapublic&amp;filter=2080</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="68"   77" 77</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>The Hawk India</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://thehawk.in/prnewswire/?rkey=20190226enIN201902257063_indiapublic&amp;filter=4853</td>
		<td><font size=3>   India</td>
		<td><font size=3>Newspaper</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> ="68"   76" 76</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>The Power Times</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.thepowertimes.in/index.php/daily-updates/national
		.html?rkey=20190226enIN201902257063_indiapublic&amp;filter=2061</td>
		<td><font size=3>   India</td>
		<td><font size=3>Trade Publications</td>
		<td><font size=3>Energy</td>
	</tr>
	<tr>
		<td> ="51"   75" 75</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>The Tech Portal</td>
		<td><font size=3>Online</td>
		<td><font size=3>https://thetechportal.com/press-releases-pr-newswire/?rkey=20190226enIN201902257063_indiapublic&amp;filter=1985</td>
		<td><font size=3>   India</td>
		<td><font size=3>Trade Publications</td>
		<td><font size=3>Tech</td>
	</tr>
	<tr>
		<td> ="51"   74" 74</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>The Times
		of Bengal</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.thetimesofbengal.com/newswire-updates?rkey=
		20190226enIN201902257063_indiapublic&amp;filter=16472</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 68"   73" 73</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Times Tech</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://timestech.in/trends-forecast/?rkey=20190226enIN201902257063_indiapublic&amp;filter=15939</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Tech</td>
	</tr>
	<tr>
		<td> 101"   72" 72</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>TMCnet</td>
		<td><font size=3>Online</td>
		<td><font size=3>https://www.tmcnet.com/usubmit/-india-smart-utility-week
		-2019-be-inaugurated-shri-/2019/02/26/8907093.htm</td>
		<td><font size=3>   United States</td>
		<td><font size=3>Trade Publications</td>
		<td><font size=3>Tech</td>
	</tr>
	<tr>
		<td> 68"   71" 71</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Uttarakhand News Network</td>
		<td><font size=3>Online</td>
		<td><font size=3>https://uttarakhandnewsnetwork.com/press-release-pr-news-wire
		/?rkey=20190226enIN201902257063_indiapublic&amp;filter=14497</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 51"   70" 70</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Webindia123.com</td>
		<td><font size=3>Online</td>
		<td><font size=3>https://news.webindia123.com/news/press_showdetailsPR.asp?id=1136057</td>
		<td><font size=3>   India</td>
		<td><font size=3>Trade Publications</td>
		<td><font size=3>Financial</td>
	</tr>
	<tr>
		<td> 68"   69" 69</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>PTI</td>
		<td><font size=3>Online</td>
		<td><u><font size=3 color="#0563C1"><a href="http://www.ptinews.com/pressrelease/30058_press-subSmart-Utilities-for-Electrified-India">http://www.ptinews.com/pressrelease/30058_press-subSmart-Utilities-for-Electrified-India</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 135"   68" 68</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>5 Dariya News</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.5dariyanews.com/Full-Story-Latest-from-PR-Newswire.aspx?rkey=20180606enIN201806042881_indiapublic&amp;filter=3325</td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 68"   67" 67</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Abhitak News [English]</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.abhitaknews.com/english/news/press-releases.aspx?rkey=20180606enIN201806042881_indiapublic&amp;filter=1889</td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 168"   66" 66</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Asianbuck</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.asianbuck.com/asianbuck-prnews/?rkey=20180606enIN201806042881_indiapublic&amp;filter=8421</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 51"   65" 65</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Automotive 
		Industries 
		magazine</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.ai-online.com/prnewswire/?rkey=2018060
		6enIN201806042881_indiapublic&amp;filter=1271</td>
		<td><font size=3>   Global</td>
		<td><font size=3>Trade Publications</td>
		<td><font size=3>Transportation</td>
	</tr>
	<tr>
		<td> 151"   64" 64</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Bangalore Waves</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.bangalorewaves.com/news/bangalorewaves-business-
		news.php?rkey=20180606enIN201806042881_
		indiapublic&amp;filter=2267</td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Tech</td>
	</tr>
	<tr>
		<td> 51"   63" 63</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Biharprabha News</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://news.biharprabha.com/prnewswire/?rkey=20180606enIN201806042881_indiapublic&amp;filter=2270</td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 85"   62" 62</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Biz Wire Express</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.bizwireexpress.com/showstoryPRN.php?rkey=20180606enIN201806042881_indiapublic&amp;filter=2276</td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 51"   61" 61</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Business 
		Fortnight</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://businessfortnight.com/pr-newswire/?rkey=20180606enIN201806042881_indiapublic&amp;filter=5117</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 68"   60" 60</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Business News
		This Week</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://businessnewsthisweek.com/prnews/?rkey=20180606enIN201806042881_indiapublic&amp;filter=601</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 68"   59" 59</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Business Sandesh</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.businesssandesh.in/breaking-news/?rkey=20180606enIN201806042881_indiapublic&amp;filter=7621</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 51"   58" 58</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Business Today
		India</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.businesstoday.in/prnewswire/?rkey=20180606enIN201806042881_indiapublic&amp;filter=2418</td>
		<td><font size=3>   India</td>
		<td><font size=3>Trade Publications</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 51"   57" 57</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Business Views</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://businessviews.in/business-views-press-release-news
		/?rkey=20180606enIN201806042881_indiapublic&amp;filter=908</td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 68"   56" 56</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Core Sector Communique</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://corecommunique.com/prnewswire/?rkey=20180606enIN201806042881_indiapublic&amp;filter=4754</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 51"   55" 55</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Dalal Street 
		Investment Journal</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.dsij.in/newswiredetails.aspx?FileName=20180
		6060100PR_NEWS_EURO_ND__enIN201806042881_indiapublic</td>
		<td><font size=3>   India</td>
		<td><font size=3>Financial Data, Research &amp; Analytics</td>
		<td><font size=3>Financial</td>
	</tr>
	<tr>
		<td> 51"   54" 54</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>EnergyCentral.com</td>
		<td><font size=3>Online</td>
		<td><font size=3>https://www.energycentral.com/node/262715/edit?news_processing=1</td>
		<td><font size=3>   United States</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Energy</td>
	</tr>
	<tr>
		<td> 51"   53" 53</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Enterprise IT World</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.enterpriseitworld.com/index.php/PR/?rkey=
		20180606enIN201806042881_indiapublic&amp;filter=4799</td>
		<td><font size=3>   India</td>
		<td><font size=3>Trade Publications</td>
		<td><font size=3>Tech</td>
	</tr>
	<tr>
		<td> 51"   52" 52</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Fast Mail</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://thefastmail.com/index.php/page/detailnews/
		7069?rkey=20180606enIN201806042881_indiapublic&amp;filter=3911</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 51"   51" 51</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>GoEvnts.com</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://goevnts.com/pr-landing?rkey=20180606enIN201806042881_indiapublic&amp;filter=4444</td>
		<td><font size=3>   Global</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Business Services</td>
	</tr>
	<tr>
		<td> 68"   50" 50</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Hello Mumbai</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.hellomumbainews.com/hello-business/?rkey=201
		80606enIN201806042881_indiapublic&amp;filter=12313</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 68"   49" 49</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>HT Syndication</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.htsyndication.com/htsportal/pr-newswire/article
		/smart-utilities-for-electrified-india/27893638</td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 68"   48" 48</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>IANS India</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://ians.in/index.php?param=prnewswiredetail/PRN-1002720</td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 68"   47" 47</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>IBTN9</td>
		<td><font size=3>Online</td>
		<td><font size=3>https://ibtn9.com/pr-newswire/?rkey=20180606enIN201806042881_indiapublic&amp;filter=12202</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 51"   46" 46</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>India Briefing</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.india-briefing.com/news/partnernews/?rkey=20180606enIN201806042881_indiapublic&amp;filter=3400</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Financial</td>
	</tr>
	<tr>
		<td> 68"   45" 45</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>India Online</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://news.indiaonline.in/prnewswire?rkey=20180606enIN201806042881_indiapublic&amp;filter=4991</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 68"   44" 44</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>India Today</td>
		<td><font size=3>Online</td>
		<td><font size=3>https://www.indiatoday.in/pr-newswire?rkey=20180606enIN201806042881_indiapublic&amp;filter=4315</td>
		<td><font size=3>   India</td>
		<td><font size=3>Magazine</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 68"   43" 43</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Indian Nerve</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://indiannerve.com/in-press/?rkey=20180606enIN201806042881_indiapublic&amp;filter=6492</td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 68"   42" 42</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Indian Power
		Sector</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://indianpowersector.com/prnews/?rkey=20180606enIN201806042881_indiapublic&amp;filter=4997</td>
		<td><font size=3>   India</td>
		<td><font size=3>Trade Publications</td>
		<td><font size=3>Energy</td>
	</tr>
	<tr>
		<td> 68"   41" 41</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Indore Dil Se</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://indoredilse.com/english-news/?rkey=20180606enIN201806042881_indiapublic&amp;filter=10474</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 51"   40" 40</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>International Fair</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.internationalfair.in/pdetails.php?rkey=20180606enIN201806042881_indiapublic&amp;filter=9866</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Business Services</td>
	</tr>
	<tr>
		<td> 51"   39" 39</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Market News
		Release</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.marketnewsrelease.com/pr-newswire?rkey=20180606enIN201806042881_indiapublic&amp;filter=10091</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 68"   38" 38</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Media Infoline</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://mediainfoline.com/releases/?rkey=20180606enIN201806042881_indiapublic&amp;filter=3952</td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 51"   37" 37</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>MedicinMan</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://medicinman.net/pr-newswire/?rkey=20180606enIN201806042881_indiapublic&amp;filter=5136</td>
		<td><font size=3>   India</td>
		<td><font size=3>Trade Publications</td>
		<td><font size=3>Health</td>
	</tr>
	<tr>
		<td> 51"   36" 36</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Nasheman</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://nasheman.in/newswire/?rkey=20180606enIN201806042881_indiapublic&amp;filter=11016</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 68"   35" 35</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>New Delhi Times</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.newdelhitimes.com/news-release/?rkey=20180606enIN201806042881_indiapublic&amp;filter=5147</td>
		<td><font size=3>   India</td>
		<td><font size=3>Newspaper</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 68"   34" 34</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>News Bharati</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.newsbharati.com/prnewswire/?rkey=20180606enIN201806042881_indiapublic&amp;filter=5165</td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 51"   33" 33</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>News Superfast</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://media.newswire.ca/newssuperfastblog.html?rkey=20180606enIN201806042881_indiapublic&amp;filter=10033</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 68"   32" 32</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>News-PR</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.news-pr.in/display?rkey=20180606enIN201806042881_indiapublic&amp;filter=12235</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 85"   31" 31</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>NewsBlaze India</td>
		<td><font size=3>Online</td>
		<td><font size=3>https://newsblaze.in/pr-newswire?rkey=20180606enIN201806042881_indiapublic&amp;filter=12696</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 68"   30" 30</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>NewsGram</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.newsgram.com/press-releases/?rkey=20180606enIN201806042881_indiapublic&amp;filter=590</td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 68"   29" 29</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Newsprelease.com</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.newsprelease.com/pr-newswire/?rkey=20180606enIN201806042881_indiapublic&amp;filter=10089</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 51"   28" 28</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>NewsR.in</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.newsr.in/prnewswire.php?rkey=20180606enIN201806042881_indiapublic&amp;filter=5070</td>
		<td><font size=3>   India</td>
		<td><font size=3>Newspaper</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 51"   27" 27</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Next Generation 
		Communications @
		TMCnet</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://next-generation-communications.tmcnet.com
		/news/2018/06/06/8767035.htm</td>
		<td><font size=3>   United States</td>
		<td><font size=3>Trade Publications</td>
		<td><font size=3>Tech</td>
	</tr>
	<tr>
		<td> 51"   26" 26</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>NRI News 24 x 7</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://nrinews24x7.com/prnews.htm?rkey=20180606enIN201806042881_indiapublic&amp;filter=4972</td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 68"   25" 25</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Odisha Samachar</td>
		<td><font size=3>Online</td>
		<td><font size=3>https://eodishasamachar.com/en/pr-newswire-2/?rkey=20180606enIN201806042881_indiapublic&amp;filter=4272</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 51"   24" 24</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Odisha360</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.odisha360.com/prn/?rkey=20180606enIN201806042881_indiapublic&amp;filter=4962</td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 68"   23" 23</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Ohsem Me</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.ohsem.me/pr-newswire?rkey=20180606enIN201806042881_indiapublic&amp;filter=5817</td>
		<td><font size=3>   Malaysia</td>
		<td><font size=3>Blog</td>
		<td><font size=3>Tech</td>
	</tr>
	<tr>
		<td> 68"   22" 22</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>One News Page Global Edition</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.onenewspage.com/prnewswire.php?rkey=2018060
		6enIN201806042881_indiapublic&amp;filter=3968</td>
		<td><font size=3>   Global</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 51"   21" 21</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>PR Newswire India</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.prnewswire.co.in/news-releases/
		smart-utilities-for-electrified-india-684658141.html</td>
		<td><font size=3>   India</td>
		<td><font size=3>PR Newswire</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 68"   20" 20</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Prativad</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://prativad.com/newseng.htm?rkey=20180606enIN201806042881_indiapublic&amp;filter=4617</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 68"   19" 19</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Rajasthan News 1</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.rnews1.com/p/pr-newswire.html?rkey=20180606enIN201806042881_indiapublic&amp;filter=7546</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 68"   18" 18</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>REN Alliance</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://media.newswire.ca/ren-alliance.html?rkey=20180606enIN201806042881_indiapublic&amp;filter=8978</td>
		<td><font size=3>   Global</td>
		<td><font size=3>Industry Association Sites</td>
		<td><font size=3>Energy</td>
	</tr>
	<tr>
		<td> 68"   17" 17</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Scoop Big</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.scoopbig.com/prnewswire/?rkey=20180606enIN201806042881_indiapublic&amp;filter=4435</td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 51"   16" 16</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Smart Tech Today</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.smarttechtoday.com/prnews/?rkey=20180606enIN201806042881_indiapublic&amp;filter=2496</td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Tech</td>
	</tr>
	<tr>
		<td> 85"   15" 15</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>SME Software Solutions</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://smesoftwaresolutions.com/press-release-prn.htm?rkey=20180606enIN201806042881_indiapublic&amp;filter=2492</td>
		<td><font size=3>   India</td>
		<td><font size=3>News &amp; Information Service</td>
		<td><font size=3>Tech</td>
	</tr>
	<tr>
		<td> 68"   14" 14</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Specttrum News</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://specttrumnews.com/news/pr-newswire.aspx?rkey=20180606enIN201806042881_indiapublic&amp;filter=7051</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 68"   13" 13</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Startpreneur.com</td>
		<td><font size=3>Online</td>
		<td><font size=3>https://startepreneur.com/press-releases/?rkey=20180606enIN201806042881_indiapublic&amp;filter=11454</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 68"   12" 12</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Tech Blog Corner</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://techblogcorner.com/press-releases/?rkey=20180606enIN201806042881_indiapublic&amp;filter=1980</td>
		<td><font size=3>   India</td>
		<td><font size=3>Blog</td>
		<td><font size=3>Tech</td>
	</tr>
	<tr>
		<td> 68"   11" 11</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>TechENT</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://techent.tv/newswire?rkey=20180606enIN201806042881_indiapublic&amp;filter=5758</td>
		<td><font size=3>   Malaysia</td>
		<td><font size=3>Blog</td>
		<td><font size=3>Tech</td>
	</tr>
	<tr>
		<td> 85"   10" 10</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Telangana Today</td>
		<td><font size=3>Online</td>
		<td><font size=3>https://telanganatoday.com/pr-newswire?rkey=20180606enIN201806042881_indiapublic&amp;filter=11682</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 232"   9" 9</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>The Covai Post</td>
		<td><font size=3>Online</td>
		<td><font size=3>https://www.covaipost.com/pr-newswire?rkey=20180606enIN201806042881_indiapublic&amp;filter=11690</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 213"   8" 8</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>The Hans India</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.thehansindia.com/home/prnewswire?rkey=20180606enIN201806042881_indiapublic&amp;filter=2080</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 50"   7" 7</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>The Hawk India</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://thehawk.in/prnewswire/?rkey=20180606enIN201806042881_indiapublic&amp;filter=4853</td>
		<td><font size=3>   India</td>
		<td><font size=3>Newspaper</td>
		<td><font size=3>Media &amp; Information</td>
	</tr>
	<tr>
		<td> 50"   6" 6</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>The Power Times</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://www.thepowertimes.in/index.php/daily-updates/national.html?rkey=20180606enIN201806042881_indiapublic&amp;filter=2061</td>
		<td><font size=3>   India</td>
		<td><font size=3>Trade Publications</td>
		<td><font size=3>Energy</td>
	</tr>
	<tr>
		<td> 167"   5" 5</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>The TeCake</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://media.newswire.ca/tecake.html?rkey=20180606enIN201806042881_indiapublic&amp;filter=6362</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Tech</td>
	</tr>
	<tr>
		<td> 33"   4" 4</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>Times Tech</td>
		<td><font size=3>Online</td>
		<td><font size=3>http://timestech.info/trends-forecast/?rkey=20180606enIN201806042881_indiapublic&amp;filter=11572</td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Tech</td>
	</tr>
	<tr>
		<td> 67"   3" 3</td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>TMCnet</td>
		<td><font size=3>Online</td>
		<td><font size=3>https://www.tmcnet.com/usubmit/-smart-utilities-electrified-india-/2018/06/06/8767035.htm</td>
		<td><font size=3>   United States</td>
		<td><font size=3>Trade Publications</td>
		<td><font size=3>Tech</td>
	</tr>
	<tr>
		<td></td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>VAR India</td>
		<td><font size=3>Online</td>
		<td><u><font color="#0563C1"><a href="http://www.varindia.com/news/1529595?rkey=20180606enIN201806042881_indiapublic&amp;filter=537">http://www.varindia.com/news/1529595?rkey=20180606
		enIN201806042881_indiapublic&amp;filter=537</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>Online News Sites &amp; Other Influencers</td>
		<td><font size=3>Tech</td>
	</tr>
	<tr>
		<td></td>
		<td>ISUW 2019 NEWS</td>
		<td><font size=3>What's New on the Net</td>
		<td><font size=3>Online</td>
		<td><u><font color="#0563C1"><a href="http://media.newswire.ca/whatsnewonthenet.html?rkey=20180606enIN201806042881_indiapublic&amp;filter=299">http://media.newswire.ca/whatsnewonthenet.html?rkey=20180606
		enIN201806042881_indiapublic&amp;filter=299</a></font></u></b></td>
		<td><font size=3>   India</td>
		<td><font size=3>Blog</td>
		<td><font size=3>Tech</td>
	</tr>
</table>
<p></p>
</div>
</div>

@endsection
