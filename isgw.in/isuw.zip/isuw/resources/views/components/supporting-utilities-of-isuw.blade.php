@extends('master')
@section('content')

 <div class="container">
 <div class="row justify-content-left ">
<p></p>

<h3><span style="color: #ff6600;">Supporting Utilities of ISUW</span></h3>
<p></p>

<div class="col-lg-3"><div class="logo-div"><a href="http://www.mpwz.co.in/portal/Indore_home.portal" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2020/02/MPPKVVCL-Recruitment.png" /></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://www.ndmc.gov.in/" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2020/02/NDMC.png" /></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://www.noidapower.com/" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2020/02/Noida-Power-Company-Ltd..jpg" /></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://www.adanielectricity.com/" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2020/02/logo-adani-electricity-1.png" /></a></div></div>

<p></p>
</div>
</div>

@endsection