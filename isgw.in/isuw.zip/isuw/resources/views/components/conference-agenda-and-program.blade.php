@extends('master')
@section('content')

 <div class="container">
 <div class="row justify-content-left ">
<p></p>

<h3 style="color: #f60;margin-left: 55px;">ISUW 2022 Agenda</h3>
<h4 style="color: green;margin-left: 58px;"><a href="https://events.firstviewgroup.com/AfricaRooftopSolarCongress2021#/agenda?lang=en" target="_blank">For Agenda Click here </a></h4>
<iframe src="https://www.isgw.in/uploads/images/ISUW-2021-AGENDA-DETAILED_27-Feb.docx.pdf" height="600" width="150" title="Iframe Example" style="
    width: 524px;
    text-align: center;
    margin-left: 78px;
"></iframe>

<p></p>
</div>
</div>

@endsection
