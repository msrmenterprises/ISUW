@extends('master')
@section('content')

 <div class="container">
 <div class="row justify-content-left ">
<p></p>
<div class="row">
<h2 style="color:#f60;">ISGW Mobile Apps</h2>
<p>Please Download the Mobile App<br>
<a href="https://play.google.com/store/apps/details?id=com.ecs.isgw" rel="attachment wp-att-4700"><img loading="lazy" src="http://www.isgw.in/wp-content/uploads/2015/01/button-get-it-on-google-play.png" alt="button-get-it-on-google-play" width="800" height="237" style="width:300px;height:106px;" class="size-full wp-image-4700" srcset="http://www.isgw.in/wp-content/uploads/2015/01/button-get-it-on-google-play.png 800w, http://www.isgw.in/wp-content/uploads/2015/01/button-get-it-on-google-play-300x89.png 300w" sizes="(max-width: 800px) 100vw, 800px"></a><br>
<a href="https://itunes.apple.com/us/app/india-smart-grid-week/id973060872?ls=1&amp;mt=8" rel="attachment wp-att-5707"><img loading="lazy" src="http://www.isgw.in/wp-content/uploads/2015/12/apple-button.png" alt="apple-button" width="1620" height="481" style="width:300px;height:105px;" class="size-full wp-image-5707" srcset="http://www.isgw.in/wp-content/uploads/2015/12/apple-button.png 1620w, http://www.isgw.in/wp-content/uploads/2015/12/apple-button-300x89.png 300w, http://www.isgw.in/wp-content/uploads/2015/12/apple-button-768x228.png 768w, http://www.isgw.in/wp-content/uploads/2015/12/apple-button-1024x304.png 1024w" sizes="(max-width: 1620px) 100vw, 1620px"></a></p>
<p>You also download ISGW 2016 App by typing ISGW from your Android phone or Apple phone</p>

<p></p>
</div>
</div>

@endsection
