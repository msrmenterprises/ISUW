@extends('master')
@section('content')

 <div class="container">
 <div class="row justify-content-left ">
<p></p>
<h2 style="color:#f60;"> <br><strong>About India Smart Grid Forum (ISGF)</strong> </h2>
<h2 class="headingclass"> <br><strong>India Smart Utility Week (ISUW) </strong> </h2>
<p style="text-align:justify;">ISGF is a public private partnership initiative of Govt. of India with the mandate of accelerating smart grid deployments across the country. With 170+ members comprising of ministries, utilities, technology providers, academia and research, ISGF has evolved as a Think-Tank of global repute on Smart Energy and Smart Cities. Mandate of ISGF is to accelerate energy transition through clean energy, electric grid modernization and electric mobility; work with national and international agencies in standards development and help utilities, regulators and the Industry in technology selection, training and capacity building.</p>
<p><b>Website:</b><a href="https://indiasmartgrid.org/">https://indiasmartgrid.org/</a> <b>| Email: </b><a href="contactus@indiasmartgrid.org">contactus@indiasmartgrid.org</a></p>
<p></p>
</div>
</div>

@endsection