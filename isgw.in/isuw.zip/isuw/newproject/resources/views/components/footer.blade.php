<section class="footer py-5 text-white">
         <div class="container">
		 <div class="register-now" style="
    text-align: center;"><a href="http://www.isgw.in/isuw-registration-2021/" target="_blank"><img src="http://www.isgw.in/wp-content/uploads/2017/09/Register_Now_Button.png" style="width:15%;"></a></div>
            <p></p>
			<p></p>
			<div class="row ">
               <div class="col-lg-3">
                  <div class="widget">
                     <h6>ISUW 2021 Venue</h6>
                     <p><i class="fa fa-home" aria-hidden="true"></i> ON DIGITAL PLATFORM</p>
                      <h6>  For General Queries</h6>
					 <p><i class="fa fa-phone" aria-hidden="true"></i> Call us at: 011 -41057658<br>
                        <i class="fa fa-envelope-o" aria-hidden="true"></i> isuw@isuw.in<br></p>
						<h6><a href="https://goo.gl/maps/YDuKXJGDNiVaLXYJ6" title="Find us on map" style="color:white;">
						<i class="fa fa-map-marker" aria-hidden="true"></i> Find us on map</a></h6>
						<h6>Mark your Calendar</h6>
						Follow Live Updates:
                     <p></p>
                     <ul class="social-media d-flex">
                        <li class="ms-0"><a href="#"><img src="images/facebook.png"></a></li>
                        <li><a href="#"><img src="images/twitter.png"></a></li>
                        <li><a href="#"><img src="images/linkedin.png"></a></li>
						<li><a href="#"><img src="images/insta.jpg" style="width:25px; height:25px;"></a></li>
                        <li><a href="#"><img src="images/youtube.png"></a></li>
                        <li><a href="#"><img src="images/flickr.png"></a></li>
                     </ul>
                  </div>
               </div>
              <div class="col-lg-3">
                  <div class="widget">
                     <h6>ISGF Innovation Award 2022</h6>
					 Last date to apply for<br>
Nomination: 15 Dec 2021<br>
                     <ol class="list-group list-group-numbered">
                     <li>Best Smart Grid Project in India by Utility/ Technology Company</li>
                     <li>Most Successful Program for Rooftop Solar by DISCOM</li>
                     <li>Smart Technology</li>
                     <li>Emerging Innovation in Electric Mobility Domain</li>
                     <li>Adoption of Disruptive Technology/Solution by a Utility/Industry</li>
                     <li>Smart Start-up of the Year</li> 
                     <li>Smart Incubator of the Year</li>
					 <li>Best Survival Effort, Business Continuity and Innovation to deal with Crisis Periods (Pandemic/ Natural Calamity) – Utility/Industry</li>
                     <li> Best Business Growth and Innovation amongst previous years ISGF Innovation Award Winners</li>
 
                     </ol>
					 <div class="register-now">
					 <a href="http://www.isgw.in/isuw-registration-2021/" class="button" target="_blank">Read details</a>
					 <a href="http://www.isgw.in/isuw-registration-2021/" class="button" target="_blank">Submit Notification</a>
					 </div>
					 <br/>
					 <p>For queries, Email us at awards@isuw.in</p>
                  </div>
               </div>
               <div class="col-lg-3">
                  <div class="widget">
                     <h6>ISUW 2021 Event Structure</h6>
                     <h5 class="text-warning">Day 1 : Tuesday, 02 March 2022</h5>
                     <p>Conference &amp; Exhibition</p>
                     <h5 class="text-warning">Day 2 : Wednesday, 03 March 2022</h5>
                     <p>Conference &amp; Exhibition</p>
                     <h5 class="text-warning">Day 3 : Thursday, 04 March 2022</h5>
                     <p>Conference &amp; Exhibition | ISGF Innovation Awards 2022</p>
                     
                  </div>
				   <div class="register-now">
					 <a href="http://www.isgw.in/isuw-registration-2021/" class="button" target="_blank">View details Program Agenda</a>
					 </div>
               </div>
               <div class="col-lg-3">
                  <div class="widget">
                     <h6>Social Media Iframe</h6>
                  </div>
               </div>
            </div>
         </div>
         <hr>
         <div class="footer-bottom">
		 <p>Previous Year Editions</p>
		  <ul> 
		       <li><a href="#">2015</a></li>
		       <li><a href="#">2016</a></li>
               <li><a href="#">2017</a></li>
               <li><a href="#">2018</a></li>
               <li><a href="#">2019</a></li>
               <li><a href="#">2020</a></li>
               <li><a href="#">2021</a></li>
            </ul>
			<br>
            <ul>
               <li><a href="#">Home</a></li>
               <li><a href="#">Privacy Policy</a></li>
               <li><a href="#">Terms and Conditions</a></li>
               <li><a href="#">Refund and Cancellation</a></li>
               <li><a href="#">Contact Us</a></li>
               <li><a href="#">Important Information for Foreign Delegates</a></li>
               <li><a href="#">ISUW Mobile App</a></li>
               <li><a href="#">Copyright © ISGF.</a></li>
            </ul>
         </div>
		 <div class="k_fixed_bro">
    <a href="https://register.indiasmartgrid.org/" class="buttonbrochure" target="_blank">Download Brochure</a>
	</div>
      </section>