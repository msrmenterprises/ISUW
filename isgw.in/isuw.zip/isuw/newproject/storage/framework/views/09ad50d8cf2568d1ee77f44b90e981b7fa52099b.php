<div class="pre-header">
         <div class="container">
            <div class="row">
               <div class="col-lg-7  col-7">
                  <ul class="info">
                     <li class="text-warning">Highlights of 2021</li>
                     <li class="mrq">
                        <marquee>1570+ Participants |  9 Supporting Ministries|  26 Key Partners | 31Exhibitors| 42 Supporting Organisations  | 25 Supporting Media Partners | 21 Theme and Session Partners | 23 Countries | 264 Participants from Utilities | 13 Themes Sessions | 4 Special Plenary Sessions | 7 Parallel Events | 5 Bi-lateral Workshops | 269 Speakers from 20+ Countries | 50 Technical Papers Published | 200+ Delegates in 4 Tracks of Master Classes | 50 Delegates in 2 Technical Tours | 8 Award Categories of ISGF Innovation Awards | 127 Award Nominations from 84 Organisations | 27 Winners of ISGF Innovation Awards | 16 Certificate of Merit | 12110 Social Media Votes for Award Winners </marquee>
                     </li>
                  </ul>
               </div>
               <div class="col-lg-5  col-5">
                  <ul class="social-media">
                     <li><a href="#"><img src="images/facebook.png"></a></li>
                     <li><a href="#"><img src="images/twitter.png"></a></li>
                     <li><a href="#"><img src="images/linkedin.png"></a></li>
					 <li><a href="#"><img src="images/insta.jpg" style="width:25px; height:25px;"></a></li>
                     <li><a href="#"><img src="images/youtube.png"></a></li>
                     <li><a href="#"><img src="images/flickr.png"></a></li>
                     <li><a href="#" class="getstarted ">Register Now</a></li>
                  </ul>
               </div>
            </div>
         </div>
      </div>
      <div class="site-header">
         <img src="images/top-img.png" class="img-fluid">
      </div>
      <header id="header" class="navbar-expand-lg">
         <div class="container ">
         <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
         <span class="navbar-toggler-icon"></span>
         </button>
         <div class="collapse navbar-collapse navbar" id="navbarSupportedContent">
            <ul class="">
               <li><a class="nav-link scrollto active ps-0" href="#">Home</a></li>
               <li class="dropdown">
                  <a href="#" class=" " data-bs-toggle="dropdown"><span>PARTNERS</span> <i class="fa fa-chevron-down"></i></a>
                  <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                     <li><a href="#">Partnership Opportunities</a></li>
                      <li><a href="#">Key Partners 2021</a></li>
                      <li><a href="#">Supporting Organization 2021</a></li>
                      <li><a href="#">Supporting Ministries</a></li>
                      <li><a href="#">Media and Marketing Partners</a></li>
                      <li><a href="#">Theme And Session Partners</a></li>
                      <li><a href="#">Supporting Utilities</a></li>
                     <li><a href="#">Participating Utilities</a></li>
                     <li><a href="#">Participated Utilities</a></li>
                  </ul>
               </li>
			   <li class="dropdown">
                  <a href="#" class=" " data-bs-toggle="dropdown"><span>PROGRAMS</span> <i class="fa fa-chevron-down"></i></a>
                  <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                     <li><a href="#">Conference Themes</a></li>
                      <li><a href="#">Conference Agenda and Program</a></li>
                      <li><a href="#">Technical Paper – ISUW 2022</a></li>
                      <li><a href="#">Innovation Awards 2022</a></li>
                  </ul>
               </li>
              
               <li><a class="nav-link scrollto" href="#">SPEAKERS</a></li>
			    <li class="dropdown">
                  <a href="#" class=" " data-bs-toggle="dropdown"><span>EXHIBITORS</span> <i class="fa fa-chevron-down"></i></a>
                  <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                     <li><a href="#">Exhibition Themes</a></li>
                      <li><a href="#">Exhibition Packages</a></li>
                      <li><a href="#">Exhibition Gallery</a></li>
                      <li><a href="#">Confirmed Exhibitors</a></li>
                  </ul>
               </li>
			   
			    <li class="dropdown">
                  <a href="#" class=" " data-bs-toggle="dropdown"><span>ABOUT ISUW 2021</span> <i class="fa fa-chevron-down"></i></a>
                  <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                     <li><a href="#">ISUW 2021</a></li>
					 <li><a href="#">Brochure 2021</a></li>
                  </ul>
               </li>
				 <li><a class="nav-link scrollto" href="#">PRESENTATION</a></li>
				   <li class="dropdown">
                  <a href="#" class=" " data-bs-toggle="dropdown"><span>GALLERY</span> <i class="fa fa-chevron-down"></i></a>
                  <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                     <li><a href="#">Photos</a></li>
					  <li><a href="#">Videos</a></li>
					   <li><a href="#">Media Coverage</a></li>
					    <li><a href="#">Press Release</a></li>
                  </ul>
               </li>
               
			   <li class="dropdown">
                  <a href="#" class=" " data-bs-toggle="dropdown"><span>CONTACT US</span> <i class="fa fa-chevron-down"></i></a>
                  <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                     <li><a href="#">Contact us</a></li>
					 <li><a href="#">Enquiry</a></li>
                  </ul>
               </li>
               <li><a class="getstarted scrollto" href="#">Register Now</a></li>
            </ul> 
            <!-- .navbar -->
         </div>
      </div></header><?php /**PATH C:\xampp\htdocs\newproject\resources\views/header.blade.php ENDPATH**/ ?>