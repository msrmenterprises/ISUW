<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<style>
.button {
  padding: 10px 20px;
  font-size: 12px;
  text-align: center;
  cursor: pointer;
  outline: none;
  color: #fff;
  background-color: #EF7B00;
  border: none;
  border-radius: 15px;
}
a:hover {
    color: white;
}
.buttonbrochure {
  padding: 13px 24px;
  font-size: 14px;
  text-align: center;
  cursor: pointer;
  outline: none;
  color: #fff;
  background-color: #EF7B00;
  border: none;
  border-radius: 15px;
}

.k_fixed_bro {
    position: fixed;
    bottom: 3%;
    right: 0px;
}
</style>
    <head>
         <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <!-- Bootstrap CSS -->
      <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;500;700&amp;display=swap" rel="stylesheet">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
      <link href="css/bootstrap.min.css" rel="stylesheet">
      <link href="css/style.css" rel="stylesheet">
      <link href="css/slider.css" rel="stylesheet">
      <title>ISO</title>
    </head>
    <body class="antialiased">
       Sandeep
    <?php echo $__env->make('components.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="banner ">
         <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
               <div class="carousel-item">
                  <div class="first-div ">
                     <img src="http://www.isgw.in/wp-content/uploads/2020/03/Thank-you-banner-RAJ-KUMAR-SINGH.jpg" class="d-block w-100" alt="...">
                  </div>
               </div>
               <div class="carousel-item">
                  <div class="first-div ">
                     <img src="http://www.isgw.in/wp-content/uploads/2020/03/Thank-you-banner-RAJ-KUMAR-SINGH.jpg" class="d-block w-100" alt="...">
                  </div>
               </div>
               <div class="carousel-item active">
                  <div class="first-div ">
                     <img src="http://www.isgw.in/wp-content/uploads/2020/03/Thank-you-banner-RAJ-KUMAR-SINGH.jpg" class="d-block w-100" alt="...">
                  </div>
               </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
            </button>
         </div>
      </div>
      <section class="page-section key-spoort">
         <div class="container">
            <div class="section-title d-none">
               <h2>About Us</h2>
            </div>
            <div class="row">
               <div class="col-lg-3">
                  <div class="card-box ministry">
                     <h2>Supporting 
                        Ministries 2021
                     </h2>
                     <div class="logo-div"><img src="images/mlogo01.png" class="logo-img " alt="..."></div>
                     <div class="logo-div"><img src="images/mlogo02.png" class="logo-img " alt="..."></div>
                     <div class="logo-div"><img src="images/mlogo03.png" class="logo-img " alt="..."></div>
                     <div class="logo-div"><img src="images/mlogo04.png" class="logo-img " alt="..."></div>
                     <div class="logo-div"><img src="images/mlogo05.png" class="logo-img " alt="..."></div>
                     <div class="logo-div"><img src="images/mlogo06.png" class="logo-img " alt="..."></div>
					 <!--<h2>Thematic Session Partners
                     </h2>
                     <div class="logo-div"><img src="images/mlogo01.png" class="logo-img " alt="..."></div>
					 <div class="logo-div"><img src="images/mlogo01.png" class="logo-img " alt="..."></div>-->
					  <div class="row justify-content-center mt-4">
                       <h2>Thematic Session Partners
                     </h2>
                        <div class="col-lg-8 utilitesSlick slick-initialized slick-slider"><button type="button" class="slick-prev pull-left slick-arrow" style="display: block;"><img src="images/arrow-left2.png"></button>
								
						  <div aria-live="polite" class="slick-list draggable"><div class="slick-track" role="listbox" style="opacity: 1; width: 876px; transform: translate3d(-146px, 0px, 0px);"><div class="logo-div slick-slide slick-cloned" data-slick-index="-1" aria-hidden="true" tabindex="-1" style="width: 116px;"><img src="images/host04.png" class="logo-img " alt="..."></div><div class="logo-div slick-slide slick-current slick-active" data-slick-index="0" aria-hidden="false" tabindex="-1" role="option" aria-describedby="slick-slide20" style="width: 116px;"><img src="images/host04.png" class="logo-img " alt="..."></div><div class="logo-div slick-slide" data-slick-index="1" aria-hidden="true" tabindex="-1" role="option" aria-describedby="slick-slide21" style="width: 116px;"><img src="images/host04.png" class="logo-img " alt="..."></div><div class="logo-div slick-slide" data-slick-index="2" aria-hidden="true" tabindex="-1" role="option" aria-describedby="slick-slide22" style="width: 116px;"><img src="images/host04.png" class="logo-img " alt="..."></div><div class="logo-div slick-slide" data-slick-index="3" aria-hidden="true" tabindex="-1" role="option" aria-describedby="slick-slide23" style="width: 116px;"><img src="images/host04.png" class="logo-img " alt="..."></div><div class="logo-div slick-slide slick-cloned" data-slick-index="4" aria-hidden="true" tabindex="-1" style="width: 116px;"><img src="images/host04.png" class="logo-img " alt="..."></div></div></div>
						  
						  
						  
                        <button type="button" class="slick-next pull-right slick-arrow" style="display: block;"><img src="images/arrow-right2.png"></button></div>
                     </div>
                  </div>
				    
                     
                     
                  
               </div>
               <div class="col-lg-6">
                  <div class="card-box">
                     <div class="row justify-content-center">
                        <div class="col-lg-3">
                           <div class="spot-div">
                              <a href="#">
                                 <img src="images/spot01.png" class="logo-img " alt="...">
                                 <h3>Mark your 
                                    Calendar
                                 </h3>
                              </a>
                           </div>
                        </div>
                        <div class="col-lg-3">
                           <div class="spot-div">
                              <a href="#">
                                 <img src="images/spot02.png" class="logo-img " alt="...">
                                 <h3>Participation 
                                    Opportunities
                                 </h3>
                              </a>
                           </div>
                        </div>
                        <div class="col-lg-3">
                           <div class="spot-div">
                              <a href="#">
                                 <img src="images/spot03.png" class="logo-img " alt="...">
                                 <h3>Technical 
                                    Papers
                                 </h3>
                              </a>
                           </div>
                        </div>
                        <div class="col-lg-3">
                           <div class="spot-div">
                              <a href="#">
                                 <img src="images/spot04.png" class="logo-img " alt="..." style="height:47px;">
                                 <h3>Innovation 
                                    Awards
                                 </h3>
                              </a>
                           </div>
                        </div>
                     </div>
                     <h2 class="mt-4">Key Partners 2021
                     </h2>
                     <div class="row justify-content-center">
                        <div class="col-lg-12">
                           <div class="logo-title">
                              <h4>Powered by</h4>
                           </div>
                        </div>
                        <div class="col-lg-3">
                           <div class="logo-div"><img src="images/AWS_logo_RGB.png" class="logo-img " alt="..."></div>
                        </div>
                     </div>
					    <div class="row justify-content-center mt-4">
                        <div class="col-lg-12">
                           <div class="logo-title">
                              <h4>Platinum Partners</h4>
                           </div>
                        </div>
                        <div class="col-lg-3">
                           <div class="logo-div"><img src="images/HItachi-ABB-logo.jpg" class="logo-img " alt="..."></div>
                        </div>
                      
                     </div>
					   <div class="row justify-content-center mt-4">
                        <div class="col-lg-12">
                           <div class="logo-title">
                              <h4>ISGF Innovation Award Partner</h4>
                           </div>
                        </div>
                        <div class="col-lg-3">
                           <div class="logo-div"><img src="images/NEDO.png" class="logo-img " alt="..."></div>
                        </div>
                        <!--<div class="col-lg-3">
                           <div class="logo-div"><img src="images/host02.png" class="logo-img " alt="..."></div>
                        </div>
                        <div class="col-lg-3">
                           <div class="logo-div"><img src="images/host03.png" class="logo-img " alt="..."></div>
                        </div>
                        <div class="col-lg-3">
                           <div class="logo-div"><img src="images/host04.png" class="logo-img " alt="..."></div>
                        </div>-->
                     </div>
					   <div class="row justify-content-center mt-4">
                        <div class="col-lg-12">
                           <div class="logo-title">
                              <h4>Gold Partner</h4>
                           </div>
                        </div>
                        <div class="col-lg-3">
                           <div class="logo-div"><img src="images/SEW-Logo.png" class="logo-img " alt="..."></div>
                        </div>
                        
                     </div>
                     <div class="row justify-content-center mt-4">
                        <div class="col-lg-12">
                           <div class="logo-title">
                              <h4>Session Partner</h4>
                           </div>
                        </div>
                        <div class="col-lg-3">
                           <div class="logo-div"><img src="images/SAP_Best_R_grad_blk.png" class="logo-img " alt="..."></div>
                        </div>
                       
                     </div>
                     <div class="row justify-content-center mt-4">
                        <div class="col-lg-12">
                           <div class="logo-title">
                              <h4>Technology Partners</h4>
                           </div>
                        </div>
                        <div class="col-lg-3">
                           <div class="logo-div"><img src="images/Fluentgrid-logoTM.jpg" class="logo-img " alt="..."></div>
                        </div>
                        
                     </div>
                     <div class="row justify-content-center mt-4">
                        <div class="col-lg-12">
                           <div class="logo-title">
                              <h4>Silver Partners</h4>
                           </div>
                        </div>
                        <div class="col-lg-3">
                           <div class="logo-div"><img src="images/logo-G3.png" class="logo-img " alt="..."></div>
                        </div>
                        <div class="col-lg-3">
                           <div class="logo-div"><img src="images/wisun.png" class="logo-img " alt="..."></div>
                        </div>
                        <div class="col-lg-3">
                           <div class="logo-div"><img src="images/NOKIA_LOGO_RGB_LR.png" class="logo-img " alt="..."></div>
                        </div>
                        <div class="col-lg-3">
                           <div class="logo-div"><img src="images/Altec-black-w-124.jpg" class="logo-img " alt="..."></div>
                        </div>
                     </div>
                     <div class="row justify-content-center mt-4">
                        <div class="col-lg-12">
                           <div class="logo-title">
                              <h4>Country Partners</h4>
                           </div>
                        </div>
                        <div class="col-lg-3">
                           <div class="logo-div"><img src="images/SWEDISH-ENERGY-AGENCY.png" class="logo-img " alt="..."></div>
                        </div>
                        <div class="col-lg-3">
                           <div class="logo-div"><img src="images/Team-Sweden-logga-1.jpg" class="logo-img " alt="..."></div>
                        </div>
                        <div class="col-lg-3">
                           <div class="logo-div"><img src="images/EU-INDIA-1.png" class="logo-img " alt="..."></div>
                        </div>
                        <div class="col-lg-3">
                           <div class="logo-div"><img src="images/EU-Flag_High-Res-1.jpg" class="logo-img " alt="..."></div>
                        </div>
                     </div>
                     <div class="row justify-content-center mt-4">
                        <div class="col-lg-12">
                           <div class="logo-title">
                              <h4>Bronze Partners</h4>
                           </div>
                        </div>
                        <div class="col-lg-3">
                           <div class="logo-div"><img src="images/host01.png" class="logo-img " alt="..."></div>
                        </div>
                        <div class="col-lg-3">
                           <div class="logo-div"><img src="images/host02.png" class="logo-img " alt="..."></div>
                        </div>
                        <div class="col-lg-3">
                           <div class="logo-div"><img src="images/host03.png" class="logo-img " alt="..."></div>
                        </div>
                        <div class="col-lg-3">
                           <div class="logo-div"><img src="images/host04.png" class="logo-img " alt="..."></div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-lg-3">
                  <div class="card-box">
                     <div class="row justify-content-center">
                        <div class="col-lg-12">
                           <h2>ISUW Utilities 2021</h2>
                        </div>
                        <!--<div class="col-lg-6">
                           <div class="logo-div"><img src="images/host01.png" class="logo-img " alt="..."></div>
                        </div>
                        <div class="col-lg-6">
                           <div class="logo-div"><img src="images/host02.png" class="logo-img " alt="..."></div>
                        </div>-->
                     </div>
					    <div class="row justify-content-center">
						  <div class="col-lg-12">
                           <div class="logo-title">
                              <h4>Host Utilities</h4>
                           </div>
                        </div>
                        <!--<div class="col-lg-12">
                           <h2>Host Utilities</h2>
                        </div>-->
                        <div class="col-lg-6">
                           <div class="logo-div"><img src="images/host01.png" class="logo-img " alt="..."></div>
                        </div>
                        <div class="col-lg-6">
                           <div class="logo-div"><img src="images/host02.png" class="logo-img " alt="..."></div>
                        </div>
                     </div>
					   <div class="row justify-content-center">
                        <div class="col-lg-12">
						<div class="logo-title">
                           <h4>Co-Host Utilities</h4>
						   </div>
                        </div>
                        <div class="col-lg-6">
                           <div class="logo-div"><img src="images/host01.png" class="logo-img " alt="..."></div>
                        </div>
                        <div class="col-lg-6">
                           <div class="logo-div"><img src="images/host02.png" class="logo-img " alt="..."></div>
                        </div>
                     </div>
					   <div class="row justify-content-center">
                        <div class="col-lg-12">
						<div class="logo-title">
                           <h4>Partner Utilities</h4>
						   </div>
                        </div>
                        <div class="col-lg-6">
                           <div class="logo-div"><img src="images/host01.png" class="logo-img " alt="..."></div>
                        </div>
                        <div class="col-lg-6">
                           <div class="logo-div"><img src="images/host02.png" class="logo-img " alt="..."></div>
                        </div>
                     </div>
					  
                     <!--<div class="row justify-content-center mt-4">
                        <div class="col-lg-12">
                           <h2>Platinum Partner</h2>
                        </div>
                        <div class="col-lg-6">
                           <div class="logo-div"><img src="images/host01.png" class="logo-img " alt="..."></div>
                        </div>
                        <div class="col-lg-6">
                           <div class="logo-div"><img src="images/host02.png" class="logo-img " alt="..."></div>
                        </div>
                     </div>
                     <div class="row justify-content-center mt-4">
                        <div class="col-lg-12">
                           <h2>ISGF Innovation 
                              Awards Partner
                           </h2>
                        </div>
                        <div class="col-lg-6">
                           <div class="logo-div"><img src="images/host01.png" class="logo-img " alt="..."></div>
                        </div>
                        <div class="col-lg-6">
                           <div class="logo-div"><img src="images/host02.png" class="logo-img " alt="..."></div>
                        </div>
                     </div>
                     <div class="row justify-content-center mt-4">
                        <div class="col-lg-12">
                           <h2>Gold Partner</h2>
                        </div>
                        <div class="col-lg-6">
                           <div class="logo-div"><img src="images/host01.png" class="logo-img " alt="..."></div>
                        </div>
                        <div class="col-lg-6">
                           <div class="logo-div"><img src="images/host02.png" class="logo-img " alt="..."></div>
                        </div>
                     </div>
                     <div class="row justify-content-center mt-4">
                        <div class="col-lg-12">
                           <h2>Session Partner</h2>
                        </div>
                        <div class="col-lg-6">
                           <div class="logo-div"><img src="images/host01.png" class="logo-img " alt="..."></div>
                        </div>
                        <div class="col-lg-6">
                           <div class="logo-div"><img src="images/host02.png" class="logo-img " alt="..."></div>
                        </div>
                     </div>
                     <div class="row justify-content-center mt-4">
                        <div class="col-lg-12">
                           <h2>Technology Partner</h2>
                        </div>
                        <div class="col-lg-6">
                           <div class="logo-div"><img src="images/host01.png" class="logo-img " alt="..."></div>
                        </div>
                        <div class="col-lg-6">
                           <div class="logo-div"><img src="images/host02.png" class="logo-img " alt="..."></div>
                        </div>
                     </div>-->
					  <div class="row justify-content-center">
                        <div class="col-lg-12">
						<div class="logo-title">
                           <h4>Participating Utilities</h4>
						   </div>
                        </div>
                        <div class="col-lg-6">
                           <div class="logo-div"><img src="images/host01.png" class="logo-img " alt="..."></div>
                        </div>
                        <div class="col-lg-6">
                           <div class="logo-div"><img src="images/host02.png" class="logo-img " alt="..."></div>
                        </div>
						<div class="col-lg-6">
                           <div class="logo-div"><img src="images/host02.png" class="logo-img " alt="..."></div>
                        </div>
						<div class="col-lg-6">
                           <div class="logo-div"><img src="images/host02.png" class="logo-img " alt="..."></div>
                        </div>
						<div class="col-lg-6">
                           <div class="logo-div"><img src="images/host02.png" class="logo-img " alt="..."></div>
                        </div>
						<div class="col-lg-6">
                           <div class="logo-div"><img src="images/host02.png" class="logo-img " alt="..."></div>
                        </div>
						<div class="col-lg-6">
                           <div class="logo-div"><img src="images/host02.png" class="logo-img " alt="..."></div>
                        </div>
						<div class="col-lg-6">
                           <div class="logo-div"><img src="images/host02.png" class="logo-img " alt="..."></div>
                        </div>
						<div class="col-lg-6">
                           <div class="logo-div"><img src="images/host02.png" class="logo-img " alt="..."></div>
                        </div>
				        
                     </div>
                     <!--<div class="row justify-content-center mt-4">
                        <div class="col-lg-12">
						  <div class="logo-title">
                           <h4>Participating 
                              Utilities
                           </h4>
						   </div>
                        </div>
                        <div class="col-lg-8 utilitesSlick">
								
						  <div class="logo-div"><img src="images/host01.png" class="logo-img " alt="..."></div>
						  <div class="logo-div"><img src="images/host01.png" class="logo-img " alt="..."></div>
						  <div class="logo-div"><img src="images/host01.png" class="logo-img " alt="..."></div>
						  <div class="logo-div"><img src="images/host01.png" class="logo-img " alt="..."></div>
                        </div>
                     </div>-->
                  </div>
               </div>
            </div>
         </div>
      </section>
      <section class="page-section isuw-speark">
         <div class="container">
            <div class="section-title pb-0">
			
               <h2 class="text-black" style="background-color:#4EBC3C">ISUW Speakers 2021</h2>
		
			     <div class="col-lg-12 mb-4 text-end">
                  <a class="btn btn-light" style="margin-top: -32px;" href="#">View All</a>
               </div>
            </div>
            <div class="row justify-content-center ">
               <div class="col-lg-12 responsive slick-initialized slick-slider"><button type="button" class="slick-prev pull-left slick-arrow" style="display: block;"><img src="images/arrow-left.png"></button>
                  <div aria-live="polite" class="slick-list draggable"><div class="slick-track" role="listbox" style="opacity: 1; width: 3627px; transform: translate3d(-1116px, 0px, 0px);"><div class="sprk-box slick-slide slick-cloned" data-slick-index="-4" aria-hidden="true" tabindex="-1" style="width: 249px;">
                     <img src="images/img02.png" class="img-fluid " alt="...">
                     <h5>Abhishek Ranjan</h5>
                     <p>BSES Rajadhani Power</p>
                     <p><a href="#" class="text-warning" tabindex="-1">Read bio...</a></p>
                  </div><div class="sprk-box slick-slide slick-cloned" data-slick-index="-3" aria-hidden="true" tabindex="-1" style="width: 249px;">
                     <img src="images/img03.png" class="img-fluid " alt="...">
                     <h5>Abhishek Sarkar</h5>
                     <p>Practice KPMG</p>
                     <p><a href="#" class="text-warning" tabindex="-1">Read bio...</a></p>
                  </div><div class="sprk-box slick-slide slick-cloned" data-slick-index="-2" aria-hidden="true" tabindex="-1" style="width: 249px;">
                     <img src="images/img04.png" class="img-fluid " alt="...">
                     <h5>Adarsh Nagarajan</h5>
                     <p>Laboratory (NREL)</p>
                     <p><a href="#" class="text-warning" tabindex="-1">Read bio...</a></p>
                  </div><div class="sprk-box slick-slide slick-cloned" data-slick-index="-1" aria-hidden="true" tabindex="-1" style="width: 249px;">
                     <img src="images/img01.png" class="img-fluid " alt="...">
                     <h5>Abel Didier Tella</h5>
                     <p>Power Utilities of Africa</p>
                     <p><a href="#" class="text-warning" tabindex="-1">Read bio...</a></p>
                  </div><div class="sprk-box slick-slide slick-current slick-active" data-slick-index="0" aria-hidden="false" tabindex="-1" role="option" aria-describedby="slick-slide00" style="width: 249px;">
                     <img src="images/img01.png" class="img-fluid " alt="...">
                     <h5>Abel Didier Tella</h5>
                     <p>Power Utilities of Africa</p>
                     <p><a href="#" class="text-warning" tabindex="0">Read bio...</a></p>
                  </div><div class="sprk-box slick-slide slick-active" data-slick-index="1" aria-hidden="false" tabindex="-1" role="option" aria-describedby="slick-slide01" style="width: 249px;">
                     <img src="images/img02.png" class="img-fluid " alt="...">
                     <h5>Abhishek Ranjan</h5>
                     <p>BSES Rajadhani Power</p>
                     <p><a href="#" class="text-warning" tabindex="0">Read bio...</a></p>
                  </div><div class="sprk-box slick-slide slick-active" data-slick-index="2" aria-hidden="false" tabindex="-1" role="option" aria-describedby="slick-slide02" style="width: 249px;">
                     <img src="images/img03.png" class="img-fluid " alt="...">
                     <h5>Abhishek Sarkar</h5>
                     <p>Practice KPMG</p>
                     <p><a href="#" class="text-warning" tabindex="0">Read bio...</a></p>
                  </div><div class="sprk-box slick-slide slick-active" data-slick-index="3" aria-hidden="false" tabindex="-1" role="option" aria-describedby="slick-slide03" style="width: 249px;">
                     <img src="images/img04.png" class="img-fluid " alt="...">
                     <h5>Adarsh Nagarajan</h5>
                     <p>Laboratory (NREL)</p>
                     <p><a href="#" class="text-warning" tabindex="0">Read bio...</a></p>
                  </div><div class="sprk-box slick-slide" data-slick-index="4" aria-hidden="true" tabindex="-1" role="option" aria-describedby="slick-slide04" style="width: 249px;">
                     <img src="images/img01.png" class="img-fluid " alt="...">
                     <h5>Abel Didier Tella</h5>
                     <p>Power Utilities of Africa</p>
                     <p><a href="#" class="text-warning" tabindex="-1">Read bio...</a></p>
                  </div><div class="sprk-box slick-slide slick-cloned" data-slick-index="5" aria-hidden="true" tabindex="-1" style="width: 249px;">
                     <img src="images/img01.png" class="img-fluid " alt="...">
                     <h5>Abel Didier Tella</h5>
                     <p>Power Utilities of Africa</p>
                     <p><a href="#" class="text-warning" tabindex="-1">Read bio...</a></p>
                  </div><div class="sprk-box slick-slide slick-cloned" data-slick-index="6" aria-hidden="true" tabindex="-1" style="width: 249px;">
                     <img src="images/img02.png" class="img-fluid " alt="...">
                     <h5>Abhishek Ranjan</h5>
                     <p>BSES Rajadhani Power</p>
                     <p><a href="#" class="text-warning" tabindex="-1">Read bio...</a></p>
                  </div><div class="sprk-box slick-slide slick-cloned" data-slick-index="7" aria-hidden="true" tabindex="-1" style="width: 249px;">
                     <img src="images/img03.png" class="img-fluid " alt="...">
                     <h5>Abhishek Sarkar</h5>
                     <p>Practice KPMG</p>
                     <p><a href="#" class="text-warning" tabindex="-1">Read bio...</a></p>
                  </div><div class="sprk-box slick-slide slick-cloned" data-slick-index="8" aria-hidden="true" tabindex="-1" style="width: 249px;">
                     <img src="images/img04.png" class="img-fluid " alt="...">
                     <h5>Adarsh Nagarajan</h5>
                     <p>Laboratory (NREL)</p>
                     <p><a href="#" class="text-warning" tabindex="-1">Read bio...</a></p>
                  </div></div></div>
                  
                  
                  
                  
               <button type="button" class="slick-next pull-right slick-arrow" style="display: block;"><img src="images/arrow-right.png"></button></div>
            </div>
         </div>
      </section>
      <section class="page-section isuw-exhibitors">
         <div class="container">
            <div class="section-title">
               <h2>ISUW Exhibitors 2021</h2>
            </div>
            <div class="row justify-content-center ">
               <div class="col-lg-2">
                  <div class="logo-div"><img src="images/host01.png" class="logo-img " alt="..."></div>
               </div>
               <div class="col-lg-2">
                  <div class="logo-div"><img src="images/host02.png" class="logo-img " alt="..."></div>
               </div>
               <div class="col-lg-2">
                  <div class="logo-div"><img src="images/host02.png" class="logo-img " alt="..."></div>
               </div>
               <div class="col-lg-2">
                  <div class="logo-div"><img src="images/host02.png" class="logo-img " alt="..."></div>
               </div>
               <div class="col-lg-2">
                  <div class="logo-div"><img src="images/host02.png" class="logo-img " alt="..."></div>
               </div>
               <div class="col-lg-2">
                  <div class="logo-div"><img src="images/host01.png" class="logo-img " alt="..."></div>
               </div>
               <div class="col-lg-2">
                  <div class="logo-div"><img src="images/host02.png" class="logo-img " alt="..."></div>
               </div>
               <div class="col-lg-2">
                  <div class="logo-div"><img src="images/host02.png" class="logo-img " alt="..."></div>
               </div>
               <div class="col-lg-2">
                  <div class="logo-div"><img src="images/host02.png" class="logo-img " alt="..."></div>
               </div>
               <div class="col-lg-2">
                  <div class="logo-div"><img src="images/host02.png" class="logo-img " alt="..."></div>
               </div>
               <div class="col-lg-2">
                  <div class="logo-div"><img src="images/host01.png" class="logo-img " alt="..."></div>
               </div>
               <div class="col-lg-2">
                  <div class="logo-div"><img src="images/host02.png" class="logo-img " alt="..."></div>
               </div>
               <div class="col-lg-2">
                  <div class="logo-div"><img src="images/host02.png" class="logo-img " alt="..."></div>
               </div>
               <div class="col-lg-2">
                  <div class="logo-div"><img src="images/host02.png" class="logo-img " alt="..."></div>
               </div>
               <div class="col-lg-2">
                  <div class="logo-div"><img src="images/host02.png" class="logo-img " alt="..."></div>
               </div>
               <div class="col-lg-2">
                  <div class="logo-div"><img src="images/host01.png" class="logo-img " alt="..."></div>
               </div>
               <div class="col-lg-2">
                  <div class="logo-div"><img src="images/host02.png" class="logo-img " alt="..."></div>
               </div>
               <div class="col-lg-2">
                  <div class="logo-div"><img src="images/host02.png" class="logo-img " alt="..."></div>
               </div>
            </div>
         </div>
      </section>
      <section class="page-section isuw-testimonies">
         <div class="container">
            <div class="section-title">
               <h2 class="text-black" style="background-color:lightgray;">ISUW Testimonies 2021</h2>
            </div>
            <div class="row justify-content-center ">
               <div class="col-lg-9 happy-client slick-initialized slick-slider"><button type="button" class="slick-prev pull-left slick-arrow" style="display: block;"><img src="images/arrow-left.png"></button>
                  <div aria-live="polite" class="slick-list draggable"><div class="slick-track" role="listbox" style="opacity: 1; width: 2912px; transform: translate3d(-832px, 0px, 0px);"><div class="testimonies-box d-flex slick-slide slick-cloned" data-slick-index="-2" aria-hidden="true" tabindex="-1" style="width: 386px;">
                     <img src="images/1.png" class="img-fluid " alt="...">
                     <div class="media-right text-black">
                        <p class="mb-4" style="text-align:justify;">Thank you for having me as a Speaker. The congregation of a wide spectrum of experts from their respective fields and an interchange of ideas on burning topics makes the ISUW a forum to look forward to.
                        </p><h5>Abel Didier Tella</h5>
                        <p><em>Power Utilities of Africa</em></p>
						<!--<a href="#" target="_blank">Read More</a>-->
                     </div>
                  </div><div class="testimonies-box d-flex slick-slide slick-cloned" data-slick-index="-1" aria-hidden="true" tabindex="-1" style="width: 386px;">
                     <img src="images/1.png" class="img-fluid " alt="...">
                     <div class="media-right text-white">
                        <p class="mb-4">Thank you for having me as a Speaker. The congregation of a wide spectrum of experts from their respective fields and an interchange of ideas on burning topics makes the ISUW a forum to look forward to.
                        </p>
                        <h5>Abel Didier Tella</h5>
                        <p><em>Power Utilities of Africa</em></p>
							<!--<a href="#" target="_blank">Read More</a>-->
                     </div>
                  </div><div class="testimonies-box d-flex slick-slide slick-current slick-active" data-slick-index="0" aria-hidden="false" tabindex="-1" role="option" aria-describedby="slick-slide10" style="width: 386px;">
                     <img src="images/1.png" class="img-fluid " alt="...">
                     <div class="media-right text-black">
                        <p class="mb-4" style="text-align:justify;">Thank you for having me as a Speaker. The congregation of a wide spectrum of experts from their respective fields and an interchange of ideas on burning topics makes the ISUW a forum to look forward to...
                        </p>
                        <h5>Abel Didier Tella</h5>
                        <p><em>Power Utilities of Africa</em></p>
							<!--<a href="#" target="_blank">Read More</a>-->
                     </div>
                  </div><div class="testimonies-box d-flex slick-slide slick-cloned" data-slick-index="3" aria-hidden="true" tabindex="-1" style="width: 386px;">
                     <img src="images/1.png" class="img-fluid " alt="...">
                     <div class="media-right text-black">
                        <p class="mb-4" style="text-align:justify;">Thank you for having me as a Speaker. The congregation of a wide spectrum of experts from their respective fields and an interchange of ideas on burning topics makes the ISUW a forum to look forward to...
                        </p>
                        <h5>Abel Didier Tella</h5>
                        <p><em>Power Utilities of Africa</em></p>
							<!--<a href="#" target="_blank">Read More</a>-->
                     </div>
                  </div><div class="testimonies-box d-flex slick-slide slick-cloned" data-slick-index="4" aria-hidden="true" tabindex="-1" style="width: 386px;">
                     <img src="images/1.png" class="img-fluid " alt="...">
                     <div class="media-right text-black">
                        <p class="mb-4" style="text-align:justify;">Thank you for having me as a Speaker. The congregation of a wide spectrum of experts from their respective fields and an interchange of ideas on burning topics makes the ISUW a forum to look forward to.
                        </p><h5>Abel Didier Tella</h5>
                        <p><em>Power Utilities of Africa</em></p>
							<!--<a href="#" target="_blank">Read More</a>-->
                     </div>
                  </div></div></div>
                  
                  
               <button type="button" class="slick-next pull-right slick-arrow" style="display: block;"><img src="images/arrow-right.png"></button></div>
            </div>
         </div>
      </section>
	  <section class="page-section section--three-column">
         <div class="container">
            
            <div class="row justify-content-center ">
			  <div class="col-lg-4">
                <div class="article--stats">
				<div class="article__icon"> 
     <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
    </div>
	<h3 class="article__header__title"> 7 </h3>
	<div class="article__body">
        Editions 
     </div>
				</div>
               </div>
			     <div class="col-lg-4">
                <div class="article--stats">
				<div class="article__icon"> 
     <i class="fa fa-users" aria-hidden="true"></i>
    </div>
	<h3 class="article__header__title"> 12000 </h3>
	<div class="article__body">
        Delegates
     </div>
				</div>
               </div>
			     <div class="col-lg-4">
                <div class="article--stats">
				<div class="article__icon"> 
     <i class="fa fa-volume-up" aria-hidden="true"></i>
    </div>
	<h3 class="article__header__title"> 1700 </h3>
	<div class="article__body">
        Speakers 
     </div>
				</div>
               </div>
			     <div class="col-lg-4">
                <div class="article--stats">
				<div class="article__icon"> 
     <img src="images/exhibitor.png" alt="exhibitor">
    </div>
	<h3 class="article__header__title"> 339 </h3>
	<div class="article__body">
        Exhibitors
     </div>
				</div>
               </div>
               <div class="col-lg-4">
                <div class="article--stats">
				<div class="article__icon"> 
     <i class="fa fa-building" aria-hidden="true"></i> 
    </div>
	<h3 class="article__header__title"> 50+ </h3>
	<div class="article__body">
       Countries
     </div>
				</div>
               </div>
			    <div class="col-lg-4">
                <div class="article--stats">
				<div class="article__icon"> 
     <i class="fa fa-clipboard" aria-hidden="true"></i> 
    </div>
	<h3 class="article__header__title"> 506 </h3>
	<div class="article__body">
       Technical Papers
     </div>
				</div>
               </div>
			    <div class="col-lg-4">
                <div class="article--stats">
				<div class="article__icon"> 
				<img src="images/recognition.png" alt="recognition">
    </div>
	<h3 class="article__header__title"> 179 </h3>
	<div class="article__body">
        Recognitions
     </div>
				</div>
               </div>
               
      
            </div>
         </div>
      </section>
	 	  
	
      <section class="page-section isuw-speark">
         <div class="container">
            <div class="section-title">
               <h2 class="text-black" style="background-color:#4EBC3C">Count down to ISUW 2022</h2>
            </div>
			<!--<div class="elementor-widget-container">
<div class="elementor-countdown-wrapper" data-date="1615556460">
<div class="elementor-countdown-item"><span class="elementor-countdown-digits elementor-countdown-days">00</span> <span class="elementor-countdown-label">Days</span></div><div class="elementor-countdown-item"><span class="elementor-countdown-digits elementor-countdown-hours">00</span> <span class="elementor-countdown-label">Hours</span></div><div class="elementor-countdown-item"><span class="elementor-countdown-digits elementor-countdown-minutes">00</span> <span class="elementor-countdown-label">Minutes</span></div><div class="elementor-countdown-item"><span class="elementor-countdown-digits elementor-countdown-seconds">00</span> <span class="elementor-countdown-label">Seconds</span></div> </div>
</div>-->
            <div class="balloon white d-none">
               <div class="star"></div>
               <div class="face">
                  <div class="eye"></div>
                  <div class="mouth happy"></div>
               </div>
               <div class="triangle"></div>
               <div class="string"></div>
            </div>
            <div class="balloon white d-none">
               <div class="star"></div>
               <div class="face">
                  <div class="eye"></div>
                  <div class="mouth happy"></div> 
               </div>
               <div class="triangle"></div>
               <div class="string"></div>
            </div>
            <div class="balloon white d-none">
               <div class="star"></div>
               <div class="face">
                  <div class="eye"></div>
                  <div class="mouth happy"></div>
               </div>
               <div class="triangle"></div>
               <div class="string"></div>
            </div>
            <div id="timer"><div class="days">            <div class="numbers">204</div>days</div>          <div class="hours">            <div class="numbers">13</div>hours</div>          <div class="minutes">            <div class="numbers">49</div>minutes</div>          <div class="seconds">            <div class="numbers">3</div>seconds</div>          </div>
         </div>
      </section>
      	  <!-- footer -->
           <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
      <script src="https://kenwheeler.github.io/slick/slick/slick.js"></script>
      <script src="js/bootstrap.bundle.min.js"></script>
      <script src="js/script.js"></script>
      <script>
         const year = new Date().getFullYear();
         const fourthOfJuly = new Date(year, 6,4).getTime();
         const fourthOfJulyNextYear = new Date(year + 1, 6, 4).getTime();
         const month = new Date().getMonth();
         
         // countdown
         let timer = setInterval(function() {
         
           // get today's date
           const today = new Date().getTime();
         
           // get the difference
           let diff;
           if(month > 6) {
             diff = fourthOfJulyNextYear - today;
           } else {
             diff = fourthOfJuly - today;
           }
         
         
         
         
           // math
           let days = Math.floor(diff / (1000 * 60 * 60 * 24));
           let hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
           let minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
           let seconds = Math.floor((diff % (1000 * 60)) / 1000);
         
           // display
           document.getElementById("timer").innerHTML =
             "<div class=\"days\"> \
           <div class=\"numbers\">" + days + "</div>days</div> \
         <div class=\"hours\"> \
           <div class=\"numbers\">" + hours + "</div>hours</div> \
         <div class=\"minutes\"> \
           <div class=\"numbers\">" + minutes + "</div>minutes</div> \
         <div class=\"seconds\"> \
           <div class=\"numbers\">" + seconds + "</div>seconds</div> \
         </div>";
         
         }, 1000);
             
      </script>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\newproject\resources\views/welcome.blade.php ENDPATH**/ ?>