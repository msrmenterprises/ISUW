<div class="pre-header">
         <div class="container">
            <div class="row">
               <div class="col-lg-7  col-7">
                  <ul class="info">
                     <li class="text-warning"  id="speakers-2021">Highlights of 2021</li>
                     <li class="mrq">
                        <marquee>1570+ Participants |  9 Supporting Ministries|  26 Key Partners | 31Exhibitors| 42 Supporting Organisations  | 25 Supporting Media Partners | 21 Theme and Session Partners | 23 Countries | 264 Participants from Utilities | 13 Themes Sessions | 4 Special Plenary Sessions | 7 Parallel Events | 5 Bi-lateral Workshops | 269 Speakers from 20+ Countries | 50 Technical Papers Published | 200+ Delegates in 4 Tracks of Master Classes | 50 Delegates in 2 Technical Tours | 8 Award Categories of ISGF Innovation Awards | 127 Award Nominations from 84 Organisations | 27 Winners of ISGF Innovation Awards | 16 Certificate of Merit | 12110 Social Media Votes for Award Winners </marquee>
                     </li>
                  </ul>
               </div>
               <div class="col-lg-5  col-5">
                  <ul class="social-media">
                     <li><a href="https://m.facebook.com/ISUW22/?ref=page_internal&mt_nav=0&paipv=1"><img src="https://www.isgw.in/staging/isuw/public/images/facebook.png"></a></li>
                     <li><a href="https://twitter.com/ISUW22"><img src="https://www.isgw.in/staging/isuw/public/images/twitter.png"></a></li>
                     <li><a href="https://www.linkedin.com/company/india-smart-grid-week/?viewAsMember=true"><img src="https://www.isgw.in/staging/isuw/public/images/linkedin.png"></a></li>
					 <li><a href="https://instagram.com/indiasmartgridforum?utm_medium=copy_link"><img src="https://www.isgw.in/staging/isuw/public/images/insta.jpg" style="width:25px; height:25px;"></a></li>
                     <li><a href="https://www.youtube.com/c/ISGFSMARTGRIDBulletin"><img src="https://www.isgw.in/staging/isuw/public/images/youtube.png"></a></li>
                     <li><a href="https://www.flickr.com/photos/indiasmartgridforum/"><img src="https://www.isgw.in/staging/isuw/public/images/flickr.png"></a></li>
                     <li><a href="#" class="getstarted ">Register Now</a></li>
                  </ul>
               </div>
            </div>
         </div>
      </div>
      <div class="site-header">
         <img src="https://www.isgw.in/staging/isuw/public/images/header.jpg" class="img-fluid"> 
      </div>
      <header id="header" class="navbar-expand-lg">
         <div class="container ">
         <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
         <span class="navbar-toggler-icon"></span>
         </button>
         <div class="collapse navbar-collapse navbar" id="navbarSupportedContent">
            <ul class="">
               <li><a class="nav-link scrollto active ps-0" href="/staging/isuw/public/">HOME</a></li>
			    <li class="dropdown">
                  <a href="/isuw-2021" class=" " data-bs-toggle="dropdown"><span>ABOUT ISUW</span> <i class="fa fa-chevron-down"></i></a>
                  <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
				     <li><a href="/staging/isuw/public/introduction">Introduction</a></li>
					 <li><a href="/staging/isuw/public/key-highlights">Key Highlights</a></li>
					 <li><a href="/staging/isuw/public/participating-countries">Participating Countries</a></li>
					 <li><a href="/staging/isuw/public/brochure">Brochure</a></li>
                     <li><a href="/staging/isuw/public/about-organizer">About Organizer</a></li>
					  <!--<li><a href="/staging/isuw/public/isuw-2021">ISUW 2021</a></li>-->
					  <li><a href="/staging/isuw/public/isgw-post-event-report">Last Edition Post Event Report</a></li>
                  </ul>
               </li>
			     <li class="dropdown">
                  <a href="#" class=" " data-bs-toggle="dropdown"><span>PROGRAM</span> <i class="fa fa-chevron-down"></i></a>
                  <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                     <li><a href="/staging/isuw/public/conference-themes">Conference Themes</a></li>
                      <li><a href="/staging/isuw/public/conference-agenda-and-program">Conference Agenda and Program</a></li>
                      <li><a href="#">Technical Paper – ISUW 2022</a></li>
                      <li><a href="#">Innovation Awards 2022</a></li>
                  </ul>
               </li>
               <li class="dropdown">
                  <a href="#" class=" " data-bs-toggle="dropdown"><span>PARTNERS</span> <i class="fa fa-chevron-down"></i></a>
                  <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                     <li><a href="/staging/isuw/public/partnership-opportunity-information">Partnership Opportunities</a></li>
                      <li><a href="/staging/isuw/public/key-partners">Key Partners</a></li>
                      <li><a href="/staging/isuw/public/supporting-organization">Supporting Organizations</a></li>
                      <li><a href="#">Supporting Ministries</a></li>
                      <li><a href="/staging/isuw/public/media-and-marketing-partner">Media and Marketing Partners</a></li>
                      <li><a href="/staging/isuw/public/theme-and-session-partners">Theme And Session Partners</a></li>
                      <li><a href="/staging/isuw/public/supporting-utilities-of-isuw">Supporting Utilities</a></li>
                     <li><a href="/staging/isuw/public/participating-utilies">Participating Utilities</a></li>
                     <li><a href="/staging/isuw/public/isuw-participated-utilties">Participated Utilities</a></li>
                  </ul>
               </li>
			 <li class="dropdown">
                  <a href="#" class=" " data-bs-toggle="dropdown"><span>EXHIBITION</span> <i class="fa fa-chevron-down"></i></a>
                  <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                     <li><a href="/staging/isuw/public/exhibition-themes">Exhibition Themes</a></li>
                      <li><a href="/staging/isuw/public/exhibition-package-2021">Exhibition Packages</a></li>
                      <li><a href="#">Exhibition Gallery</a></li>
                      <li><a href="/staging/isuw/public/confirmed-exhibitors">Confirmed Exhibitors</a></li>
                  </ul>
               </li>
              
               <li><a class="nav-link scrollto" href="/staging/isuw/public/speakers">SPEAKERS</a></li>
			    
			   <li><a class="nav-link scrollto" href="#">PRESENTATIONS</a></li>
				   <li class="dropdown">
                  <a href="#" class=" " data-bs-toggle="dropdown"><span>MEDIA</span> <i class="fa fa-chevron-down"></i></a>
                  <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                     <li><a href="https://indiasmartgrid.org/isgfeventgallery.php">Photos</a></li>
					  <li><a href="https://indiasmartgrid.org/isgf_videos.php">Videos</a></li>
					   <li><a href="#">Media Coverage</a></li>
					    <li><a href="#">Press Release</a></li>
                  </ul>
               </li>
               
			   <li class="dropdown">
                  <a href="#" class=" " data-bs-toggle="dropdown"><span>CONTACT US</span> <i class="fa fa-chevron-down"></i></a>
                  <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                     <li><a href="/staging/isuw/public/contact-us">Contact us</a></li>
					 <li><a href="#">Enquiry</a></li>
                  </ul>
               </li>
               <li><a class="getstarted scrollto" href="#">Register Now</a></li>
            </ul> 
            <!-- .navbar -->
         </div>
      </div></header><?php /**PATH /home2/rkumarisgf/public_html/isgw.in/staging/isuw/resources/views/components/header.blade.php ENDPATH**/ ?>