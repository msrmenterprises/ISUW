
<?php $__env->startSection('content'); ?>

 <div class="container">
 <div class="row justify-content-left ">
<p></p>
<h2 style="color:#f60;"> <br><strong>ISUW Key Highlights</strong> </h2>
<h4 style="color:green; text-align:center;">India Smart Utility Week (ISUW) 2021</h4> 
<div class="wp-block-image"><figure class="aligncenter"><a href="https://www.isgw.in/staging/isuw/public/uploads/images/Key highlights banner (1500x300 pxl).jpg"><img src="https://www.isgw.in/staging/isuw/public/uploads/images/Key highlights banner (1500x300 pxl).jpg" alt="" style="margin-left:140px;width:840px;height:394px;" class="wp-image-35119"/></a></figure></div>
<h4 style="color:green; text-align:center;">India Smart Utility Week (ISUW) 2020</h4>
<div class="wp-block-image"><figure class="aligncenter"><a href="https://www.isgw.in/staging/isuw/public/uploads/images/Key Highlights Banner 840 X 394 pixel.jpg"><img src="https://www.isgw.in/staging/isuw/public/uploads/images/Key Highlights Banner 840 X 394 pixel.jpg" alt="" style="margin-left:140px;width:840px;height:394px;" class="wp-image-35119"/></a></figure></div>

<h4 style="color:green; text-align:center;">India Smart Utility Week (ISUW) 2019</h4>
<div class="wp-block-image"><figure class="aligncenter"><a href="https://www.isgw.in/staging/isuw/public/uploads/images/ISUW 2019 KEY HIGHLIGHTS.PNG"><img src="https://www.isgw.in/staging/isuw/public/uploads/images/ISUW 2019 KEY HIGHLIGHTS.PNG" alt="" style="margin-left:140px;width:840px;height:394px;" class="wp-image-35119"/></a></figure></div>

<h4 style="color:green; text-align:center;">India Smart Utility Week (ISUW) 2018</h4>
<div class="wp-block-image"><figure class="aligncenter"><a href="https://www.isgw.in/staging/isuw/public/uploads/images/KEY HIGHLIGHTS ISGW 2018.PNG"><img src="https://www.isgw.in/staging/isuw/public/uploads/images/KEY HIGHLIGHTS ISGW 2018.PNG" alt="" style="margin-left:140px;width:840px;height:394px;" class="wp-image-35119"/></a></figure></div>

<!--<div class="wp-block-image"><figure class="aligncenter"><a href="http://localhost:8000/uploads/images/ISUW-banner.jpg"><img src="http://localhost:8000/uploads/images/ISUW-banner.jpg" alt="" class="wp-image-35119"/></a></figure></div>
-->

<p></p>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/rkumarisgf/public_html/isgw.in/staging/isuw/resources/views//components/key-highlights.blade.php ENDPATH**/ ?>