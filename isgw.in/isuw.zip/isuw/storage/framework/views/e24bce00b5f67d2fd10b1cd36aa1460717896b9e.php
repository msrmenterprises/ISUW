
<?php $__env->startSection('content'); ?>

 <div class="container">
 <div class="row justify-content-left ">
<p></p>
<style>
.themepackage {
	
	list-style: none;
}
</style>
<h2 style="color: #f60">Exhibition</style></h2>
<h4 class="headingclass"><b>3D DIGITAL EXHIBITION BOOTH AT ISUW 2021</b></h4>

<UL class="theme">
	<LI>The Exhibitors of
	ISUW have the opportunity to meet and network with the potential
	international and regional buyers and Utilities.</li>
	<LI>Utilities and
	select Technology Providers have the option to exhibit their
	products and solutions in the 3-D Booths which will give a unique
	experience of interacting with utilities, Technology Companies and
	Delegates from around the globe</li>
	<LI>Explain about your
	offerings sitting in the comfort of the home or office</li>
</UL>
<p></p>
<H4 class="headingclass" ><b>ISUW 2021 EXHIBITION SAMPLE BOOTH PREVIEW</b></H4>
<p></p>
<div class="row isgfkRow">
	<a href="#" target="_blank" rel="noopener">
        <img src="http://localhost:8000/uploads/images/exhibition-2021.jpg" alt="">
		</a>
    </div>
	<p></p>
<H4 class="headingclass"><b>ISUW 2021 EXHIBITION BOOTH PREMIUM FEATURES</b></H4>
<UL class="theme">
	<LI>Delegate Passes </LI>
	<LI>A personalized figurine for welcoming participants </LI>
	<LI>Premium Booth Location for early confirmations</LI>
	<LI>Slots to Download Marketing Collaterals</LI>
	<LI>One on One Video Chat between Exhibitor and Visitors</LI>
	<LI>Slots to play Company Video</LI>
	<LI>Simultaneous Text based Chatting between channels of Exhibitors and Visitors</LI>
	<LI>Direct Social Media Page View Buttons</LI>
</UL>
<p></p>
<h5 class="headingclass"><b>BOOTH INQUIRY AND PACKAGES</b></H5>
<P><B>For Special Participation Packages and list of Features of the Booths and other Inquiries</B></P>
<P>please contact: Ms. Ronkini Shome<BR>Email:&nbsp;<A HREF="mailto:ronkini.shome@indiasmartgrid.org"><FONT>ronkini.shome@indiasmartgrid.org</A></P>
<ul class="themepackage">
<li><a href="http://www.isgw.in/exhibition-package-2020-2/">ISGW 2020 Exhibitors</a></li>
<li><a href="http://www.isgw.in/exhibition-package-2019/">ISGW 2019 Exhibitors</a></li>
<li><a href="http://www.isgw.in/confirmed-exhibitors-2018/">ISGW 2018 Exhibitors</a></li>
<li><a href="http://www.isgw.in/confirmed-exhibitors-2017/">ISGW 2017 Exhibitors</a></li>
<li><a href="http://www.isgw.in/confirmed-exhibitors-2-2/">ISGW 2016 Exhibitors</a></li>
<li><a href="http://www.isgw.in/confirmed-exhibitors/">ISGW 2015 Exhibitors</a></li>
</ul>

<p></p>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/rkumarisgf/public_html/isgw.in/staging/isuw/resources/views//components/exhibition-package-2021.blade.php ENDPATH**/ ?>