
<?php $__env->startSection('content'); ?>

 <div class="container">
 <div class="row justify-content-left ">
<p></p>
<h3 style="color:green;"><strong>India Smart Grid Forum</strong></h3>
<p></p>
<div class="row clearfix">
<div class="box one ">
<strong>CBIP Building, Malcha Marg,<br>
Chanakyapuri, New Delhi, 110021</strong><p></p>
<p><strong>For General Queries</strong>, <strong>Call us at</strong>: 011 -41057658, Email: <a href="mailto:isuw@isuw.in">isuw@isuw.in</a><br>
<strong>For Sponsorship &amp; Exhibition,</strong> Contact Ms. Ronkini Shome: at <a href="mailto:ronkini.shome@indiasmartgrid.org">ronkini.shome@indiasmartgrid.org</a>, <strong>Call at</strong>  +91-11-41057658<br>
</p></div>
</div>
<hr>
<h4>For any enquiry, please </strong><a href="http://www.isgw.in/send-enquiry/" target="_blank" style="color:#ff6600" rel="noopener noreferrer">Click Here</a></h4>
<p></p>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\isuw\isuw\resources\views//components/contact-us.blade.php ENDPATH**/ ?>