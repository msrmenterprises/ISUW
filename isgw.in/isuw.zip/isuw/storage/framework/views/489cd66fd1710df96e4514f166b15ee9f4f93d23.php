
<?php $__env->startSection('content'); ?>

 <div class="container">
 <div class="row justify-content-left ">
<p></p>
	<style>
	.themepar {
		margin-left: 20px;
	}
</style>
<h4 style="color: #f60;">PARTICIPATED UTILITIES IN ISUW</style></h4>
<h5 style="color: green;"><strong><u>Electricity Utilities</u></strong></h5>
<ol class="themepar">
<li>	Adani Electricity Mumbai Limited 	</li>
<li>	Andhra Pradesh Southern Power Distribution Company Limited	</li>
<li>	Assam Power Distribution Company Ltd	</li>
<li>	Bangalore Electricity Supply Company Ltd.	</li>
<li>	BSES Rajdhani Power Ltd.	</li>
<li>	BSES Yamuna Power Ltd.	</li>
<li>	CESC Kolkata	</li>
<li>	Chamudeshwari Electricity Supply Company Ltd.	</li>
<li>	Chandigarh Electricity department&nbsp;	</li>
<li>	Chhattisgarh State Power Distribution Company Ltd.	</li>
<li>	Dakshin Gujarat Vij Company Ltd.	</li>
<li>	Dakshin Haryana Bijli Vitran Nigam	</li>
<li>	Department of Power – Arunachal Pradesh	</li>
<li>	Gujarat Urja Vikas Nigam	</li>
<li>	Himachal Pradesh State Electricity Board	</li>
<li>	Hubli Electricity Supply Co. Ltd	</li>
<li>	India Power Corporation Limited	</li>
<li>	India Power Corporation Ltd.	</li>
<li>	Jodhpur Vidyut Vitran Nigam Ltd.	</li>
<li>	Karnataka Power Corporation Limited	</li>
<li>	Kerala State Electricity Board Ltd.	</li>
<li>	M.P. Power Management Co. Ltd.	</li>
<li>	Madhya Gujarat Vij Co. Ltd.	</li>
<li>	Madhyanchal Vidyut Vitran Nigam Ltd.	</li>
<li>	Maharashtra State Electricity Distribution Company Ltd.	</li>
<li>	Maharashtra State Electricity Transmission Company	</li>
<li>	Maharashtra State Power Generation Company	</li>
<li>	Mangalore Electricity Supply Co. Ltd	</li>
<li>	MP Paschim Khestra Vitran Co. Ltd	</li>
<li>	MP Power Management Company Ltd.  	</li>
<li>	New Delhi Municipal Council	</li>
<li>	Noida Power Company Ltd.	</li>
<li>	North Eastern Electricity Supply Company of Orissa Ltd.	</li>
<li>	NTPC Ltd.	</li>
<li>	Paschim Gujarat Vij. Co. Ltd	</li>
<li>	Power System Operation Corporation Ltd.	</li>
<li>	Punjab State Power Corporation Ltd.	</li>
<li>	Tata Power Delhi Distribution Ltd.	</li>
<li>	Telangana State Southern Power Distribution Company Limited	</li>
<li>	The Tata Power Company Ltd.	</li>
<li>	Tripura State Power Corporation  Ltd.	</li>
<li>	Uttar Haryana Bijli Vitran Nigam	</li>
<li>	Uttarkhand Power Corporation Ltd.	</li>
<li>	West Bengal State Electricity Distribution Company Ltd.	</li>
</ol>
<h5 style="color: green;"><strong><u>Regulatory</u></strong></h5>
<ol class="theme">
<li>	Central Electricity Regulatory Commission
</li><li>	Andhra Pradesh Electricity Regulatory Commission
</li><li>	Bihar Electricity Regulatory Commission
</li><li>	Haryana Electricity Regulatory Commission
</li><li>	Kerala State Electricity Regulatory Commission
</li><li>	Punjab  State Electricity Regulatory Commission
</li><li>	Uttar Pradesh Electricity Regulatory Commission
</li><li>	West Bengal Electricity Regulatory Commission
</li><li>	Joint Electricity Regulatory Commission 
</li></ol>
<h5 style="color: green;"><strong><u>Gas Utilities</u></strong></h5>
<ol class="theme">
<li>	Gas Authority of India (GAIL)	</li>
<li>	Indraprastha Gas Limited (IGL)	</li>
<li>	Think Gas Distibution Pvt Ltd 	</li>
<li>	Green Gas Limited 	</li>
<li>	Maharasthra Natural Gas Limited 	</li>
<li>	Atlantic Gulf and Pacific  AG&amp;P 	</li>
<li>	Rajasthan State Gas Limited 	</li>
<li>	Assam Gas Company Ltd 	</li>
<li>	Central UP Gas Ltd 	</li>

</ol>



<p></p>

<p></p>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/rkumarisgf/public_html/isgw.in/staging/isuw/resources/views//components/isuw-participated-utilties.blade.php ENDPATH**/ ?>