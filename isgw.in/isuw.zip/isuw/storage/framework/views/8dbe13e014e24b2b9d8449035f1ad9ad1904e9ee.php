<div class="header_wrapper">
<ul class="admin_ul">
  <li class="admin_li"><a href="/admin">Edit Banners</a></li>
  <li class="admin_li"><a href="/admin/speakers">Edit Speakers</a></li>
  <li class="admin_li"><a href="/admin/utility">Edit Utility</a></li>
  <li class="admin_li"><a href="/admin/partners">Edit Partners</a></li>
  <li class="admin_li"><a href="/admin/exhibitor">Edit Exhibitor</a></li>
  <li class="admin_li"><a href="/admin/testimonial">Edit Testimonial</a></li>
</ul>
</div><?php /**PATH /home2/rkumarisgf/public_html/isgw.in/staging/isuw/resources/views/admin/adminHeader.blade.php ENDPATH**/ ?>