<style>
h6{
color:#EF7B00;
}
</style>
<section class="footer py-5 text-white">
         <div class="container">
		 <div class="register-now" style="
    text-align: center;"><a href="http://www.isgw.in/isuw-registration-2021/" target="_blank"><img src="http://www.isgw.in/wp-content/uploads/2017/09/Register_Now_Button.png" style="width:15%;"></a></div>
            <p></p>
			<p></p>
			<div class="row ">
               <div class="col-lg-3">
                  <div class="widget">
                     <h6>ISUW 2021 Venue</h6>
                     <p><i class="fa fa-home" aria-hidden="true"></i> On Digital Platform</p>
                      <h6>  For General Queries</h6>
					 <p><i class="fa fa-phone" aria-hidden="true"></i> Call us at: 011 -41057658<br>
                        <i class="fa fa-envelope-o" aria-hidden="true"></i> isuw@isuw.in<br></p>
						<h6><a href="https://goo.gl/maps/YDuKXJGDNiVaLXYJ6" title="Find us on map" style="color:#EF7B00;">
						<i aria-hidden="true"></i> Find us on Map</a></h6>
						<h6>Mark your Calendar</h6>
						<h6>Follow Live Updates</h6>
                     <p></p>
                     <ul class="social-media d-flex">
                        <li class="ms-0"><a href="https://m.facebook.com/ISUW22/?ref=page_internal&mt_nav=0&paipv=1"><img src="images/facebook.png"></a></li>
                        <li><a href="https://twitter.com/ISUW2020"><img src="images/twitter.png"></a></li>
                        <li><a href="https://www.linkedin.com/company/india-smart-grid-week/?viewAsMember=true"><img src="images/linkedin.png"></a></li>
						<li><a href="https://instagram.com/indiasmartgridforum?utm_medium=copy_link"><img src="images/insta.jpg" style="width:25px; height:25px;"></a></li>
                        <li><a href="https://www.youtube.com/c/ISGFSMARTGRIDBulletin"><img src="images/youtube.png"></a></li>
                        <li><a href="https://www.flickr.com/photos/indiasmartgridforum/"><img src="images/flickr.png"></a></li>
                     </ul>
                  </div>
               </div>
              <div class="col-lg-3">
                  <div class="widget">
                     <h6>ISGF Innovation Award 2022</h6>
					 <p style="color:#4EBC3C;"><b>Last Nomination Date: 15 Dec 2021</b><br>
<p>
                     <ol class="list-group list-group-numbered">
                     <li>Best Smart Grid Project in India by Utility/ Technology Company</li>
                     <li>Most Successful Program for Rooftop Solar by DISCOM</li>
                     <li>Smart Technology</li>
                     <li>Emerging Innovation in Electric Mobility Domain</li>
                     <li>Adoption of Disruptive Technology/Solution by a Utility/Industry</li>
                     <li>Smart Start-up of the Year</li> 
                     <li>Smart Incubator of the Year</li>
					 <li>Best Survival Effort, Business Continuity and Innovation to deal with Crisis Periods (Pandemic/ Natural Calamity) – Utility/Industry</li>
                     <li> Best Business Growth and Innovation amongst previous years ISGF Innovation Award Winners</li>
 
                     </ol>
					 <div class="register-now">
					 <a href="http://www.isgw.in/isuw-registration-2021/" class="button" target="_blank">Read details</a>
					 <a href="http://www.isgw.in/isuw-registration-2021/" class="button" target="_blank">Submit Nomination</a>
					 </div>
					 <br/>
					 <p style="font-size:18px;">
                        <i class="fa fa-envelope-o" aria-hidden="true"></i> awards@isuw.in<br></p>
					 
                  </div>
               </div>
               <div class="col-lg-3">
                  <div class="widget">
                     <h6>ISUW 2022 Event Structure</h6>
                     <h5 style="color:#4EBC3C;">Day 1 : Wednesday, 02 March 2022</h5>
                     <p>Conference &amp; Exhibition</p>
                     <h5 style="color:#4EBC3C;">Day 2 : Thursday, 03 March 2022</h5>
                     <p>Conference &amp; Exhibition</p>
                     <h5 style="color:#4EBC3C;">Day 3 : Friday, 04 March 2022</h5>
                     <p>Conference &amp; Exhibition | ISGF Innovation Awards 2022</p>
                     
                  </div>
				   <div class="register-now">
					 <a href="http://www.isgw.in/isuw-registration-2021/" class="button" target="_blank">Program Agenda</a>
					 </div>
               </div>
               <div class="col-lg-3">
                  <div class="widget">
                     <h6>Social Media Iframe</h6>
                  </div>
               </div>
            </div>
         </div>
         <hr>
         <div class="footer-bottom">
		 <p>Previous Year Editions</p>
		  <ul> 
		       <li><a href="#">2015</a></li>
		       <li><a href="#">2016</a></li>
               <li><a href="#">2017</a></li>
               <li><a href="#">2018</a></li>
               <li><a href="#">2019</a></li>
               <li><a href="#">2020</a></li>
               <li><a href="#">2021</a></li>
            </ul>
			<br>
            <ul>
               <li><a href="#">Home</a></li>
               <li><a href="/privacy-policy">Privacy Policy</a></li>
               <li><a href="/terms-and-conditions">Terms and Conditions</a></li>
               <li><a href="/refund-and-cancellation">Refund and Cancellation</a></li>
               <li><a href="/contact-us">Contact Us</a></li>
               <li><a href="/important-information-for-foreign-delegates">Important Information for Foreign Delegates</a></li>
               <!--<li><a href="/mobile-apps">ISUW Mobile App</a></li>-->
               <li>Copyright © ISGF.</li>
            </ul>
         </div>
		 <div class="k_fixed_bro">
    <a href="http://localhost:8000/uploads/images/India-Smart-Utility-Week-2022.pdf" class="buttonbrochure" target="_blank">Download Brochure</a>
	</div>
      </section><?php /**PATH C:\xampp\htdocs\isuw\isuw\resources\views/components/footer.blade.php ENDPATH**/ ?>