<!DOCTYPE html>
<html>
<head>
      <title>Admin</title>
    </head>
<body>
<div id="content">
  
  <form method="POST" 
        action="<?php echo e(url('upload-speaker')); ?>"
        enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <label> enter name</label>
        <input type="text" name="name" id="name" />

        <br />
        <label> enter company</label>
        <input type="text" name="company" id="company" />

        <br />
        <label> enter desc</label>
        <textarea id="desc" name="desc" rows="4" cols="50"></textarea>
      <input type="file" 
             name="uploadfile" 
             id="uploadfile" 
             accept="image/*" />
             <br />
             <label> Image alt text </label>
<input type="text" name="altText" id="altText"  />
      <div>
          <button type="submit"
                  name="upload">
            UPLOAD
          </button>
      </div>
  </form>
</div>
</body>
</html><?php /**PATH D:\prsnl\Projects\isuw\resources\views//admin/speakers.blade.php ENDPATH**/ ?>