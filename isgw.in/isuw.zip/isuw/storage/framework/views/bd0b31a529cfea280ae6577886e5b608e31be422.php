
<?php $__env->startSection('content'); ?>

 <div class="container">
 <div class="row justify-content-left ">
<p></p>

<p><style type="text/css">
td{border:0px !important;}<br />
</style></p>
  
                         <h3><span style="color: #ff6600;">Supporting Organisations 2021</span></h3>
                        <p></p>
 <div class="col-lg-3">
 <div class="logo-div"><a href="https://gbci.org/" target="_blank" rel="noopener noreferrer"><img class="aligncenter size-full wp-image-5610" src="http://www.isgw.in/wp-content/uploads/2020/01/GBCI-logo.jpg" alt="TIE" width="120" height="130"></a></div></div>
 <div class="col-lg-3">
<div class="logo-div"><a href="https://fsr.eui.eu/" target="_blank" rel="noopener noreferrer"><img class="alignleft size-medium wp-image-38051" style="width: 55%;" src="http://www.isgw.in/wp-content/uploads/2020/01/FSR-Global_Logo.png"></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="http://www.tie.org" target="_blank" rel="noopener noreferrer"><img class="aligncenter size-full wp-image-5610" src="http://www.isgw.in/wp-content/uploads/2015/07/tie-delhi-ncr-logo-1.png" alt="TIE" width="120" height="130"></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://www.cenelec.eu/" target="_blank" rel="attachment noopener wp-att-5807 noreferrer"><img class="aligncenter size-full wp-image-5807" style="width: 55% !important;" src="http://www.isgw.in/wp-content/uploads/2017/06/cenelec2.jpg" alt="CEN LEC"></a></div></div>

<div class="col-lg-3"><div class="logo-div"><a href="https://www.cen.eu/" target="_blank" rel="attachment wp-att-5807 noopener noreferrer"><img class="aligncenter size-full wp-image-5807" style="width: 55% !important;" src="http://www.isgw.in/wp-content/uploads/2018/11/cen_download.png" alt="CEN" height="193"></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://www.etsi.org/" target="_blank" rel="noopener noreferrer"><img class="alignleft size-medium wp-image-38056" src="http://www.isgw.in/wp-content/uploads/2020/12/ETSI-1.png" alt="" width="300" height="104"></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="http://globalsmartenergy.org/" target="_blank" rel="noopener noreferrer"><img class="alignleft size-medium wp-image-38056" src="http://www.isgw.in/wp-content/uploads/2020/12/GSEF-LOGO-1.png" alt="" width="300" height="104"></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://indiasmartgrid.org/#" target="_blank" rel="noopener noreferrer"><img class="alignleft size-medium wp-image-38056" src="http://www.isgw.in/wp-content/uploads/2021/01/India-CGD-Forum.jpeg" alt="" width="300" height="104"></a></div></div>


<div class="col-lg-3"><div class="logo-div"><a href="https://www.vjti.ac.in/" target="_blank" rel="noopener noreferrer"><img class="alignleft size-medium wp-image-38051" src="http://www.isgw.in/wp-content/uploads/2019/09/vjti_mumbai.png" alt="" width="300" height="125"> </a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://www.macfound.org/" target="_blank" rel="noopener noreferrer"><img class="alignleft size-medium wp-image-38056" src="http://www.isgw.in/wp-content/uploads/2019/09/MACARTHUR.png" alt="" width="300" height="104"></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://www.teriin.org/" target="_blank" rel="noopener noreferrer"><img class="alignleft size-medium wp-image-38051" src="http://www.isgw.in/wp-content/uploads/2019/12/TERI-LOGO.jpg" alt="" width="200" height="80"> </a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://www.worldwildlife.org/" target="_blank" rel="noopener noreferrer"><img class="alignleft size-medium wp-image-38051" src="http://www.isgw.in/wp-content/uploads/2019/10/wwf.png" alt="" width="200" height="80"> </a></div></div>


<div class="col-lg-3"><div class="logo-div"><a href="https://boci.org.in/" target="_blank" rel="noopener noreferrer"><img class="alignleft size-medium wp-image-38051" style="width: 75%;" src="http://www.isgw.in/wp-content/uploads/2021/01/BOCI.jpg"> </a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://www.phdcci.in/" target="_blank" rel="noopener noreferrer"><img class="alignleft size-medium wp-image-38051" style="width: 75%;" src="http://www.isgw.in/wp-content/uploads/2021/01/PHD.png"> </a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://ngsindia.org/" target="_blank" rel="noopener noreferrer"><img class="alignleft size-medium wp-image-38051" style="width: 75%;" src="http://www.isgw.in/wp-content/uploads/2020/02/ngs-PARTNER-UTILITY-GAS.png"></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://www.thinksmartgrids.fr/en" target="_blank" rel="noopener noreferrer"><img class="alignleft size-medium wp-image-38051" style="width: 75%;" src="http://www.isgw.in/wp-content/uploads/2020/02/reisg_logo_rvb.jpg"></a></div></div>


<div class="col-lg-3"><div class="logo-div"><a href="https://standards.ieee.org/" target="_blank" rel="noopener noreferrer"><img class="alignleft size-medium wp-image-38051" style="width: 68%;" src="http://www.isgw.in/wp-content/uploads/2021/01/IEEE-SA.jpg"> </a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="http://www.cwc.gov.in/" target="_blank" rel="noopener noreferrer"><img class="alignleft size-medium wp-image-38051" style="width: 70%;" src="http://www.isgw.in/wp-content/uploads/2021/01/CWC-Logo-1-1.jpg"> </a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://www.aeee.in/" target="_blank" rel="noopener noreferrer"><img class="alignleft size-medium wp-image-38051" style="width: 90%;" src="http://www.isgw.in/wp-content/uploads/2021/01/AEEE-Logo.png"> </a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://www.germi.org/" target="_blank" rel="noopener noreferrer"><img class="alignleft size-medium wp-image-38051" style="width: 68%; height: 125px;" src="http://www.isgw.in/wp-content/uploads/2021/02/Germi-Logo.png"> </a></div></div>


<div class="col-lg-3"><div class="logo-div"><a href="https://csep.org/" target="_blank" rel="noopener noreferrer"><img class="alignleft size-medium wp-image-38051" style="width: 100%; height: 70%;" src="http://www.isgw.in/wp-content/uploads/2021/02/CSEP-1.png"> </a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://indiaesa.info/" target="_blank" rel="noopener noreferrer"><img class="alignleft size-medium wp-image-38051" style="width: 100%; height: 45px;" src="http://www.isgw.in/wp-content/uploads/2021/02/IESA-NEW.png"> </a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://www.apuea.org/" target="_blank" rel="noopener noreferrer"><img class="alignleft size-medium wp-image-38051" style="width: 100%;" src="http://www.isgw.in/wp-content/uploads/2021/01/apuea-logo.jpg"> </a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://www.igef.net/" target="_blank" rel="noopener noreferrer"><img class="alignleft size-medium wp-image-38051" style="width: 95%;" src="http://www.isgw.in/wp-content/uploads/2021/02/igef_logo.jpg"> </a></div></div>


<!--<div class="col-lg-3"><div class="logo-div"><a href="http://southasia.iclei.org/" target="_blank" rel="noopener noreferrer"><img class="alignleft size-medium wp-image-38051" style="width: 100%; height: 130%;" src="http://www.isgw.in/wp-content/uploads/2021/02/ICLEI-southasia-mainlogo-RGB-1.jpg"> </a></div></div>-->
<div class="col-lg-3"><div class="logo-div"><a href="http://www.cbip.org/" target="_blank" rel="noopener noreferrer"><img class="alignleft size-medium wp-image-38051" style="width: 100%;" src="http://www.isgw.in/wp-content/uploads/2021/02/CBIP.png"> </a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="http://niua.org/" target="_blank" rel="noopener noreferrer"><img class="alignleft size-medium wp-image-38051" style="width: 100%; height: 80%;" src="http://www.isgw.in/wp-content/uploads/2021/02/NIUA.png"> </a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://sscgj.in/" target="_blank" rel="noopener noreferrer"><img class="alignleft size-medium wp-image-38051" style="width: 100%; height: 100%;" src="http://www.isgw.in/wp-content/uploads/2021/02/SCGJ.jpg"> </a></div></div>


<div class="col-lg-3"><div class="logo-div"><a href="https://www.cigre.org/" target="_blank" rel="noopener noreferrer"><img class="alignleft size-medium wp-image-38051" style="width: 100%;" src="http://www.isgw.in/wp-content/uploads/2021/02/CIGRE.png"> </a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://www.cigre.org/" target="_blank" rel="noopener noreferrer"><img class="alignleft size-medium wp-image-38051" style="width: 100%;" src="http://www.isgw.in/wp-content/uploads/2021/02/CIGRE-INTERNTIONAL.png"> </a></div></div>
<!--<li><a href="" target="_blank" rel="noopener noreferrer"><img class="alignleft size-medium wp-image-38051" style="width: 100%; height: 70%;" src=""> </a></li>
<li><a href="" target="_blank" rel="noopener noreferrer"><img class="alignleft size-medium wp-image-38051" style="width: 100%; height: 70%;" src=""> </a></li>-->


<p></p>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/rkumarisgf/public_html/isgw.in/staging/isuw/resources/views//components/supporting-organization.blade.php ENDPATH**/ ?>