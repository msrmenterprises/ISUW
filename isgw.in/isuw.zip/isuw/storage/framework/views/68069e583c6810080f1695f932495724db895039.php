
<?php $__env->startSection('content'); ?>

 <div class="container">
 <div class="row justify-content-left ">
<p></p>
<h3 style="color: #f60;">ISUW 2021 Post Event Report</h3>
<p></p>
<p><a href="http://localhost:8000/uploads/images/Post-Event-Report-ISGW-2020.pdf" target="_blank" rel="noreferrer noopener">Please click to view ISUW 2020 Post Event Report</a></p>

<p></p>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\isuw\isuw\resources\views//components/isgw-post-event-report.blade.php ENDPATH**/ ?>