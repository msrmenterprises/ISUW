
<?php $__env->startSection('content'); ?>

 <div class="container">
 <div class="row justify-content-left ">
<p></p>

<h3><span style="color: #ff6600;">Participating Utilities </span></h3>
<p></p>
<div class="col-lg-3"><div class="logo-div"><a href="https://www.tssouthernpower.com/" target="_blank" rel="noopener noreferrer"><img class="alignleft size-medium wp-image-38051"  src="http://www.isgw.in/wp-content/uploads/2020/02/Southern-Power-Distribution-Company-of-Telangana-State-Ltd.jpg" alt="" height="125" /> </a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="http://www.recpdcl.in/" target="_blank" rel="noopener noreferrer"><img class="alignleft size-medium wp-image-38051"  src="http://www.isgw.in/wp-content/uploads/2020/02/pdcllogo.png" alt="" height="125" /> </a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://posoco.in/" target="_blank" rel="noopener noreferrer"><img class="alignleft size-medium wp-image-38051"  src="http://www.isgw.in/wp-content/uploads/2020/02/POSOCO_Final_Logo.png" alt="" height="125" /> </a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://www.indiapower.com/" target="_blank" rel="noopener noreferrer"><img class="alignleft size-medium wp-image-38051"  src="http://www.isgw.in/wp-content/uploads/2020/02/INDIA-POWER.png" alt="" height="125" /> </a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://www.dvvnl.org/" target="_blank" rel="noopener noreferrer"><img class="alignleft size-medium wp-image-38051"  src="http://www.isgw.in/wp-content/uploads/2020/02/Dakshinanchal-Vidyut-Vitran-Nigam-Ltd.png" alt="" height="125" /> </a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://www.apspdcl.in/" target="_blank" rel="noopener noreferrer"><img class="alignleft size-medium wp-image-38051"  src="http://www.isgw.in/wp-content/uploads/2020/02/APSPDCL.png" alt="" height="125" /> </a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://www.apeasternpower.com/" target="_blank" rel="noopener noreferrer"><img class="alignleft size-medium wp-image-38051"  src="http://www.isgw.in/wp-content/uploads/2020/02/APEPDCL.png" alt="" height="125" /> </a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://energy.rajasthan.gov.in/avvnl" target="_blank" rel="noopener noreferrer"><img class="alignleft size-medium wp-image-38051"  style="width: 75% !important;" src="http://www.isgw.in/wp-content/uploads/2020/02/Ajmer-Vidyut-Vitran-Nigam-Ltd.jpg" alt="" height="125" /> </a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="http://www.ugvcl.com/" target="_blank" rel="noopener noreferrer"><img class="alignleft size-medium wp-image-38051"  src="http://www.isgw.in/wp-content/uploads/2020/02/Uttar-Gujarat-Vij-Company-Ltd..jpg" alt="" height="125" /> </a></div></div>

<p></p>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/rkumarisgf/public_html/isgw.in/staging/isuw/resources/views//components/participating-utilies.blade.php ENDPATH**/ ?>