
<?php $__env->startSection('content'); ?>

<section class="page-section pt-pb-100 bg-white">
         <div class="container">
           
            <div class="row justify-content-left ">
			 <p></p>
               <div class="col-lg-12 ">
                  <div class="d-flex ">
  <div class="flex-shrink-0">
   <img src="<?php echo e($speaker->imageUrl); ?>" class="img-fluid " alt="<?php echo e($speaker->imageAlt); ?>">
  </div>
  <div class="flex-grow-1 ms-3">
    <b><?php echo e($speaker->name); ?>,<?php echo e($speaker->company); ?></b><br/>
    <?php echo e($speaker->description); ?>

	<p></p>
  </div>
</div>
                  </div>
				
				  
				
            </div>
         </div>
      </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/rkumarisgf/public_html/isgw.in/staging/isuw/resources/views/components/speakerdetail.blade.php ENDPATH**/ ?>