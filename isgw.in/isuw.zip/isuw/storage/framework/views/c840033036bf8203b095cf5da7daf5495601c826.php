
<?php $__env->startSection('content'); ?>

 <div class="container">
 <div class="row justify-content-left ">
<p></p>
<style>
.centeralign {
margin-left: 408px;
}
</style>
<h4><span style="color: #ff6600;"><b>KEY PARTNERS 2021</b></span></h4>

<h5 style="text-align:center;"><b>Powered by</b></h5>
<div class="centeralign">
<div class="col-lg-3"><div class="logo-div"><a href="https://aws.amazon.com/" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2021/02/AWS_logo_RGB.png" alt="" width="213" height="115" style="display:inline;"></a></div></div>
</div>
<p></p>
<h5 style="text-align:center;"><b>Host Utilities</b></h5>
<div class="col-lg-3"><div class="logo-div"><a href="https://www.tatapower-ddl.com/" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2017/04/82e95c5adb5b4433b0c9d63f77396e63.jpg" alt="" width="213" height="102"></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://www.tatapower.com/" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2019/01/Tata-Power-Stacked-Logo-blue-01.jpg" alt="" width="200" height="115" style="margin-top:-6px;display:inline"></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://www.bsesdelhi.com/web/bypl#loaded" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2018/02/BYPL.gif" alt="" width="213;" height="102;" style="margin-top:-6px;display:inline"></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://www.bsesdelhi.com/web/brpl" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2019/01/bses_rajdhani.png" alt="" width="300;" height="102;" style="margin-top:-6px;display:inline"></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://www.iglonline.net/english/Default.aspx" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2021/02/igllogo.png" alt="" width="300;" height="102;" style="margin-top:-6px;display:inline"></a></div></div>		
<p></p>		
<h5 style="text-align:center;"><b>	Co-Host Utilities</b></h5>
<div class="col-lg-3"><div class="logo-div"><a href="https://bescom.co.in/SCP/Myhome.aspx" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2019/02/BESCOM-1.jpg" style="margin-top:-6px;display:inline"></a></div></div> 
				<div class="col-lg-3"><div class="logo-div"><a href="https://www.cesc.co.in/" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2019/03/cesc.png" alt="" width="200" height="115" style="margin-top:-6px;display:inline"></a></div></div>
			<div class="col-lg-3"><div class="logo-div"><a href="https://www.bsesdelhi.com/web/bypl#loaded" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2018/02/BYPL.gif" alt="" style="width="213;" height="102;""></a></div></div>
				<div class="col-lg-3"><div class="logo-div"><a href="https://www.bsesdelhi.com/web/brpl" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2019/01/bses_rajdhani.png" alt="" width="300;" height="102;"></a></div></div>
<p></p>				
<h5 style="text-align:center;"><b> Partner Utilities</b></h5>
	<div class="col-lg-3"><div class="logo-div"><a href="http://www.mpwz.co.in/" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2021/02/MPPKVVCL-logo_Partner-Utility-1.jpg" style="margin-top:-6px;display:inline"></a></div></div> 
				<div class="col-lg-3"><div class="logo-div"><a href="https://posoco.in/" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2021/02/POSOCO-LOGO_Partner-Utility-1.jpg" alt="" width="200" height="115" style="margin-top:-6px;display:inline"></a></div></div>
				<div class="col-lg-3"><div class="logo-div"><a href="https://www.tsecl.in/irj/go/km/docs/internet/TRIPURA/webpage/pages/Home.html" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2021/02/Tripura.jpg" alt="" width="213" height="102" style="display:inline;"></a></div></div>
				<div class="col-lg-3"><div class="logo-div"><a href="https://www.noidapower.com/" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2021/02/npcl.jpg" alt="" width="213" height="102" style="display:inline;"></a></div></div>

<p></p>
<h5 style="text-align:center;"><b>Platinum Partner</b></h5>
<div class="centeralign">
<div class="col-lg-3"><div class="logo-div"><a href="https://www.hitachiabb-powergrids.com/in/en/" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2021/02/HItachi-ABB-logo.jpg" alt="" width="213" height="115" style="display:inline;"></a></div></div>
</div>
			
 <h5 style="text-align:center;"><b>ISGF Innovation Awards Partner</b></h5>
 <div class="centeralign">
 <div class="col-lg-3"><div class="logo-div"><a href="https://www.nedo.go.jp/english/" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2021/02/NEDO.png" alt="" width="213" height="115" style="display:inline;"></a></div></div>
</div>
			
<h5 style="text-align:center;"><b>Gold Partner</b></h5>
 <div class="centeralign">
 <div class="col-lg-3"><div class="logo-div"><a href="https://www.sew.ai/" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2021/02/SEW-Logo.png" alt="" width="213" height="115" style="display:inline;"></a></div></div>
</div>
			
<h5 style="text-align:center;"><b> Session Partner</b></h5>
<div class="centeralign">
<div class="col-lg-3"><div class="logo-div"><a href="https://www.sap.com/india/index.html" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2020/01/SAP_Best_R_grad_blk.png" alt="" width="213" height="115" style="display:inline;"></a></div></div>
</div>
			
<h5 style="text-align:center;"><b>Technology Partner</b></h5>
<div class="centeralign">
<div class="col-lg-3"><div class="logo-div"><a href="http://www.fluentgrid.com/" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2020/02/Fluentgrid-logoTM.jpg" alt="" width="213" height="102" style="display:inline;"></a></div></div>
</div>
	<p></p>		
<h5 style="text-align:center;"><b>Silver Partners</b></h5>
		
		<div class="col-lg-3"><div class="logo-div"><a href="http://www.g3-plc.com/home/" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2017/12/logo-G3.png" alt="" width="213" height="102" style="display:inline;"></a></div></div>

		<div class="col-lg-3"><div class="logo-div"><a href="https://wi-sun.org/" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2019/02/wisun.png" alt="" width="213" height="102" style="display:inline;"></a></div></div>	
		<!--<div class="col-lg-3"><div class="logo-div"><a href="http://www.iglonline.net/english/Default.aspx" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2020/03/igllogo.png" alt="" width="200" height="115" style="margin-top:-6px;display:inline"></a></div></div>-->
		<div class="col-lg-3"><div class="logo-div"><a href="https://www.nokia.com/" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2019/03/NOKIA_LOGO_RGB_LR.png" alt="" width="213" height="102" style="display:inline"></a></div></div>
		<div class="col-lg-3"><div class="logo-div"><a href="https://www.altec.com/" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2021/02/Altec-black-w-124.jpg" alt="" width="213" height="102" style="display:inline"></a></div></div>
		
<p></p>	<h5 style="text-align:center;"><b>Country Partners</b></h5>
		
		<div class="col-lg-3"><div class="logo-div"><a href="https://sweden.se/" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2021/02/SWEDISH-ENERGY-AGENCY.png" alt="" width="213" height="102" style="display:inline;"></a></div></div>

		<div class="col-lg-3"><div class="logo-div"><a href="https://sweden.se/" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2021/02/Team-Sweden-logga-1.jpg" alt="" width="213" height="102" style="display:inline;"></a></div></div>	
		
        <div class="col-lg-3"><div class="logo-div"><a href="https://europa.eu/european-union/index_en" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2021/02/EU-INDIA-1.png" alt="" width="213" height="102" style="display:inline;"></a></div></div>
        <div class="col-lg-3"><div class="logo-div"><a href="https://europa.eu/european-union/index_en" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2021/02/EU-Flag_High-Res-1.jpg" alt="" width="213" height="102" style="display:inline;"></a></div></div>					
		
<p></p>	<h5 style="text-align:center;"><b>Bronze Partners</b></h5>
		
		<div class="col-lg-3"><div class="logo-div"><a href="https://www.sfotechnologies.net/" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2021/02/NeSTIT_logo.png" alt="" width="355" height="132" style="display:inline;"></a></div></div>
        <div class="col-lg-3"><div class="logo-div"><a href="https://www.hms-networks.com/" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2021/02/hms-logo.png" alt="" width="213" height="120" style="display:inline;height: 120px;"></a></div></div>	
		<div class="col-lg-3"><div class="logo-div"><a href="http://ulepl.com/" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2021/02/UL-Group-Logo-Transperant.png" alt="" width="213" height="120" style="display:inline;height: 120px;"></a></div></div>	
		<!--<div class="col-lg-3"><div class="logo-div"><a href="http://www.iglonline.net/english/Default.aspx" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2020/03/igllogo.png" alt="" width="200" height="115" style="margin-top:-6px;display:inline"></a></div></div>-->
		<div class="col-lg-3"><div class="logo-div"><a href="https://www.cms.co.in/" target="_blank" rel="noopener noreferrer"><img src="http://www.isgw.in/wp-content/uploads/2021/02/cmslogo.jpg" alt="" width="213" height="120" style="display:inline;height: 120px;"></a></div></div>	
		
	<!--<p><a href="http://www.isgw.in/key-partner-2019/" target="_blank" rel="noopener noreferrer">KEY PARTNERS 2019</a></div></div></p>-->
	<p><a href="http://www.isgw.in/key-partners-2020/" target="_blank" rel="noopener noreferrer">KEY PARTNERS 2020</a></div></div></p>
</div>

<p></p>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/rkumarisgf/public_html/isgw.in/staging/isuw/resources/views//components/key-partners.blade.php ENDPATH**/ ?>