
<?php $__env->startSection('content'); ?>
<section class="page-section pt-pb-100 bg-white">
         <div class="container">
            		
               <h2 style="color:#f60;" >ISUW Speakers</h2>			    
           <p></p>
            <div class="row justify-content-left ">
			<?php $__currentLoopData = $speakers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $speaker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if($speaker->isActive==1): ?>
               <div class="col-lg-3 ">
		         <div class="logo-div">
                  <div class="sprk-box sprk-detail">
                     <img src="<?php echo e($speaker->imageUrl); ?>" class="img-fluid " alt="<?php echo e($speaker->imageAlt); ?>">
                     <h5><?php echo e($speaker->name); ?></h5>
                     <p><?php echo e($speaker->company); ?></p>
                     <p><a  href="/staging/isuw/public/speaker/<?php echo e($speaker->id); ?>" class="text-warning">Read bio...</a></p>
                  </div>
				  </div>
                  </div>	
				  <?php endif; ?>
				  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>			 
            </div>
         </div>
      </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/rkumarisgf/public_html/isgw.in/staging/isuw/resources/views/components/speaker.blade.php ENDPATH**/ ?>