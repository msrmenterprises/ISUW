
<?php $__env->startSection('content'); ?>

 <div class="container">
 <div class="row justify-content-left ">
<p></p>

<h3 style="color: #f60;">Media and Marketing Partners</h3>



<div class="col-lg-3"><div class="logo-div"><a href="http://www.powerline.net.in" target="_blank" rel="noopener noreferrer"><img class="size-full wp-image-5798" src="http://www.isgw.in/wp-content/uploads/2015/07/Powerline-1.jpg" alt=""  ></a></div></div>

<h3 style="color: #f60;">Supporting Media Partner of ISUW 2021</h3>




<div class="col-lg-3"><div class="logo-div"><a href="https://plugvolt.com/" target="_blank" rel="noopener noreferrer"><img class="size-full wp-image-5798" src="http://www.isgw.in/wp-content/uploads/2021/01/PlugvoltRounded-scaled.jpg" alt=""  ></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://www.eletimes.com/" target="_blank" rel="noopener noreferrer"><img class="size-full wp-image-5798" src="http://www.isgw.in/wp-content/uploads/2021/02/ET-10-Yrs-Logo-New-1.png" alt=""  height="63"></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://www.devdiscourse.com/" target="_blank" rel="noopener noreferrer"><img class="size-full wp-image-5798" src="http://www.isgw.in/wp-content/uploads/2020/02/devdiscourse_logo.jpg" alt=""  ></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="http://www.energetica-india.net/" target="_blank" rel="noopener noreferrer"><img class="size-full wp-image-5798" src="http://www.isgw.in/wp-content/uploads/2019/12/Energetica-India-Logo-PNG.png" alt=""  ></a></div></div>


<div class="col-lg-3"><div class="logo-div"><a href="https://solarquarter.com/" target="_blank" rel="noopener noreferrer"><img class="size-full wp-image-5798" src="http://www.isgw.in/wp-content/uploads/2021/02/SolarQuarter_LogoVertical_HighRes-1-1.png" alt="" ></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://www.constructionworld.in/" target="_blank" rel="noopener noreferrer"><img class="size-full wp-image-5798" src="http://www.isgw.in/wp-content/uploads/2019/12/CW-india-logo.jpg" alt="" ></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://mercomindia.com/" target="_blank" rel="noopener noreferrer"><img class="size-full wp-image-5798" src="http://www.isgw.in/wp-content/uploads/2019/11/Mercom-India-Logo.jpg" alt=""  ></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="http://infrastructuretoday.co.in/" target="_blank" rel="noopener noreferrer"><img class="size-full wp-image-5798" src="http://www.isgw.in/wp-content/uploads/2019/12/infrastruc.png" alt=""  ></a></div></div>


<div class="col-lg-3"><div class="logo-div"><a href="https://www.mojo4industry.com/" target="_blank" rel="noopener noreferrer"><img class="size-full wp-image-5798" src="http://www.isgw.in/wp-content/uploads/2021/02/mojo-indusry.jpg" alt="" ></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://timestech.in/" target="_blank" rel="noopener noreferrer"><img class="size-full wp-image-5798" src="http://www.isgw.in/wp-content/uploads/2021/02/TimesTech-Logo.jpg" alt="" ></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="http://www.tndindia.com/" target="_blank" rel="noopener noreferrer"><img class="size-full wp-image-5798" src="http://www.isgw.in/wp-content/uploads/2021/02/TD-Logo.png" alt="" ></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://emobilityplus.com/" target="_blank" rel="noopener noreferrer"><img class="size-full wp-image-5798" src="http://www.isgw.in/wp-content/uploads/2021/02/Brand-Event-Logos-16.png" alt="" ></a></div></div>


<div class="col-lg-3"><div class="logo-div"><a href="https://energystoragepro.com/" target="_blank" rel="noopener noreferrer"><img class="size-full wp-image-5798" src="http://www.isgw.in/wp-content/uploads/2021/02/LOGOS-130-by-40-2.png" alt="" ></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://windinsider.com/" target="_blank" rel="noopener noreferrer"><img class="size-full wp-image-5798" src="http://www.isgw.in/wp-content/uploads/2021/02/FirstView-Brand-Logos-1.png" alt="" ></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://about.bnef.com/" target="_blank" rel="noopener noreferrer"><img class="size-full wp-image-5798" src="http://www.isgw.in/wp-content/uploads/2021/02/BloombergNEF_long_blk-1.png" alt="" ></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://electronicsmaker.com/" target="_blank" rel="noopener noreferrer"><img class="size-full wp-image-5798" src="http://www.isgw.in/wp-content/uploads/2021/02/electronicsmaker-logo-1.png" alt="" ></a></div></div>


<div class="col-lg-3"><div class="logo-div"><a href="https://www.metrorailnews.in/" target="_blank" rel="noopener noreferrer"><img class="size-full wp-image-5798" src="http://www.isgw.in/wp-content/uploads/2021/02/Metro-Rail-News.png" alt="" ></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://www.oemupdate.com/" target="_blank" rel="noopener noreferrer"><img class="size-full wp-image-5798" src="http://www.isgw.in/wp-content/uploads/2021/02/OEM-logo.jpg"  ></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="http://www.gruppoitaliaenergia.it/" target="_blank" rel="noopener noreferrer"><img class="size-full wp-image-5798" src="http://www.isgw.in/wp-content/uploads/2021/02/gruppo-italia-energia-logo-300x85-1.jpg" ></a></div></div>
<div class="col-lg-3"><div class="logo-div"><a href="https://www.nbnco.com.au/" target="_blank" rel="noopener noreferrer"><img class="size-full wp-image-5798" src="http://www.isgw.in/wp-content/uploads/2021/02/NBN-logo-slogan-en_EN.png" alt="" ></a></div></div>



<p><a href="http://www.isgw.in/media-and-marketing-partner-2020/" target="_blank" rel="noopener">Media and Marketing Partners of ISUW 2020</a></p>

<p></p>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/rkumarisgf/public_html/isgw.in/staging/isuw/resources/views//components/media-and-marketing-partner.blade.php ENDPATH**/ ?>