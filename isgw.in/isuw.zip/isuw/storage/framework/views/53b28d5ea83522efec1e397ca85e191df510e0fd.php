<!DOCTYPE html>
<html>
<head>
      <title>Admin</title>
    </head>
<body>
<div id="content">
  
  <form method="POST" 
        action="<?php echo e(url('upload-exhibitor')); ?>"
        enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
      <input type="file" 
             name="uploadfile" 
             id="uploadfile" 
             accept="image/*" />
<input type="text" name="altText" id="altText"  />
      <div>
          <button type="submit"
                  name="upload">
            UPLOAD
          </button>
      </div>
  </form>
</div>
</body>
</html><?php /**PATH D:\prsnl\Projects\isuw\resources\views//admin/exhibitor.blade.php ENDPATH**/ ?>