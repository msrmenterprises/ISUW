
<?php $__env->startSection('content'); ?>

 <div class="container">
 <div class="row justify-content-left ">
<p></p>
<style>
  
</style>
<h2 style="color: #f60;">THEME AND SESSION PARTNERS</h2>
<table class="tabletheme">
	<tr>
		<td align="left" valign=bottom bgcolor="green"><b><font size=3 color="white">Partners Link</font></b></td>
		<td  align="left" valign=bottom bgcolor="green"><b><font size=3 color="white">Partners Name</font></b></td>
	</tr>
	<tr>
		
		<td  align="left" valign=bottom ><font color="#000000"><a href="http://niua.org/" target="_blank">http://niua.org/</a></font></td>
		<td  align="left" valign=bottom ><font color="#000000"><img class="size-medium wp-image-38225 alignleft" src="https://www.isgw.in/wp-content/uploads/2021/02/NIUA.png"></font></td>
	</tr>
	<tr>
		
		<td  align="left" valign=bottom ><font color="#000000"><a href="http://europa.eu/" target="_blank">http://europa.eu/</a></font></td>
		<td  align="left" valign=bottom ><font color="#000000"><img class="size-medium wp-image-38225 alignleft" src="https://www.isgw.in/wp-content/uploads/2021/02/EU-Flag_High-Res-1.jpg" style="width: 220px;"> </font></td>
	</tr>
	<tr>
		
		<td  align="left" valign=bottom ><font color="#000000"><a href="https://tsdsi.in/" target="_blank">https://tsdsi.in/</a></font></td>
		<td  align="left" valign=bottom ><font color="#000000"><img class="size-medium wp-image-38225 alignleft" src="http://www.isgw.in/wp-content/uploads/2021/02/TSDSI_FINAL-Logo-with-tag-line-002.png" style="width: 220px;"></font></td>
	</tr>
	<tr>
	
		<td  align="left" valign=bottom ><font color="#000000"><a href="https://www.energy.gov/" target="_blank">https://www.energy.gov/</a></font></td>
		<td  align="left" valign=bottom ><font color="#000000"><img class="size-medium wp-image-38225 alignleft" src="http://www.isgw.in/wp-content/uploads/2021/02/US-doe-logo-1.jpg"></font></td>
	</tr>
	<tr>
		
		<td  align="left" valign=bottom ><font color="#000000"><a href="https://www.usibc.com/" target="_blank">https://www.usibc.com/</a></font></td>
		<td  align="left" valign=bottom ><font color="#000000"><img class="size-medium wp-image-38225 alignleft" src="http://www.isgw.in/wp-content/uploads/2021/02/US-IBC.png" style="width: 180px;"></font></td>
	</tr>
	<tr>
		
		<td  align="left" valign=bottom ><font color="#000000"><a href="https://www.state.gov/asia-edge/" target="_blank">https://www.state.gov/asia-edge/</a></font></td>
		<td  align="left" valign=bottom ><font color="#000000"><img class="size-medium wp-image-38225 alignleft" src="http://www.isgw.in/wp-content/uploads/2021/02/asia.jpg" style="width: 220px;"></font></td>
	</tr>
	<tr>
		
		<td  align="left" valign=bottom ><font color="#000000"><a href="http://www.dst.gov.in/" target="_blank">http://www.dst.gov.in/</a></font></td>
		<td  align="left" valign=bottom ><font color="#000000"><img class="size-medium wp-image-38225 alignleft" src="http://www.isgw.in/wp-content/uploads/2021/02/DST.jpg"></font></td>
	</tr>
	<tr>
		
		<td  align="left" valign=bottom ><u><font color="#0000FF"><a href="https://www.energimyndigheten.se/en/">https://www.energimyndigheten.se/en/</a></font></u></td>
		<td  align="left" valign=bottom ><font color="#000000"><img class="size-medium wp-image-38225 alignleft" src="https://www.isgw.in/wp-content/uploads/2021/02/SWEDISH-ENERGY-AGENCY.png"></font></td>
	</tr>
	<tr>
		
		<td  align="left" valign=bottom ><u><font color="#0000FF"><a href="https://www.altec.com/">https://www.altec.com/</a></font></u></td>
		<td  align="left" valign=bottom ><font color="#000000"><img class="size-medium wp-image-38225 alignleft" src="https://www.isgw.in/wp-content/uploads/2021/02/Altec-black-w-124.jpg"></font></td>
	</tr>
	<tr>
		
		<td  align="left" valign=bottom ><font color="#000000"><a href="https://www.iec.ch/" target="_blank">https://www.iec.ch/</a></font></td>
		<td  align="left" valign=bottom ><font color="#000000"><img class="size-medium wp-image-38225 alignleft" src="http://www.isgw.in/wp-content/uploads/2021/02/iec-logo.png"></font></td>
	</tr>
	<tr>
		
		<td  align="left" valign=bottom ><font color="#000000"><a href="https://spectrum.ieee.org/" target="_blank">https://spectrum.ieee.org/</a></font></td>
		<td  align="left" valign=bottom ><font color="#000000"><img class="size-medium wp-image-38225 alignleft" src="http://www.isgw.in/wp-content/uploads/2021/02/IEEE.png"></font></td>
	</tr>
	<tr>
		
		<td  align="left" valign=bottom ><font color="#000000"><a href="http://aws.amazon.com/" target="_blank">http://aws.amazon.com/</a></font></td>
		<td  align="left" valign=bottom ><font color="#000000"><img class="size-medium wp-image-38225 alignleft" src="https://www.isgw.in/wp-content/uploads/2021/02/AWS_logo_RGB.png"></font></td>
	</tr>
	<tr>
		
		<td  align="left" valign=bottom ><font color="#000000"><a href="http://www.nisg.org/" target="_blank">http://www.nisg.org/</a></font></td>
		<td  align="left" valign=bottom ><font color="#000000"><img class="size-medium wp-image-38225 alignleft" src="http://www.isgw.in/wp-content/uploads/2021/02/NISG.jpg" style="width: 200px;"></font></td>
	</tr>
</table>
<p></p>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/rkumarisgf/public_html/isgw.in/staging/isuw/resources/views//components/theme-and-session-partners.blade.php ENDPATH**/ ?>