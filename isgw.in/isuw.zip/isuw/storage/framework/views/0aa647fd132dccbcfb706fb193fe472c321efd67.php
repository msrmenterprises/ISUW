<div class="pre-header">
         <div class="container">
            <div class="row">
               <div class="col-lg-7  col-7">
                  <ul class="info">
                     <li class="text-warning"  id="speakers-2021">Highlights of 2021</li>
                     <li class="mrq">
                        <marquee>1570+ Participants |  9 Supporting Ministries|  26 Key Partners | 31Exhibitors| 42 Supporting Organisations  | 25 Supporting Media Partners | 21 Theme and Session Partners | 23 Countries | 264 Participants from Utilities | 13 Themes Sessions | 4 Special Plenary Sessions | 7 Parallel Events | 5 Bi-lateral Workshops | 269 Speakers from 20+ Countries | 50 Technical Papers Published | 200+ Delegates in 4 Tracks of Master Classes | 50 Delegates in 2 Technical Tours | 8 Award Categories of ISGF Innovation Awards | 127 Award Nominations from 84 Organisations | 27 Winners of ISGF Innovation Awards | 16 Certificate of Merit | 12110 Social Media Votes for Award Winners </marquee>
                     </li>
                  </ul>
               </div>
               <div class="col-lg-5  col-5">
                  <ul class="social-media">
                     <li><a href="https://m.facebook.com/ISUW22/?ref=page_internal&mt_nav=0&paipv=1"><img src="/images/facebook.png"></a></li>
                     <li><a href="https://twitter.com/ISUW2020"><img src="/images/twitter.png"></a></li>
                     <li><a href="https://www.linkedin.com/company/india-smart-grid-week/?viewAsMember=true"><img src="/images/linkedin.png"></a></li>
					 <li><a href="https://instagram.com/indiasmartgridforum?utm_medium=copy_link"><img src="/images/insta.jpg" style="width:25px; height:25px;"></a></li>
                     <li><a href="https://www.youtube.com/c/ISGFSMARTGRIDBulletin"><img src="/images/youtube.png"></a></li>
                     <li><a href="https://www.flickr.com/photos/indiasmartgridforum/"><img src="/images/flickr.png"></a></li>
                     <li><a href="#" class="getstarted ">Register Now</a></li>
                  </ul>
               </div>
            </div>
         </div>
      </div>
      <div class="site-header">
         <img src="/images/top-img.jpeg" class="img-fluid">
      </div>
      <header id="header" class="navbar-expand-lg">
         <div class="container ">
         <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
         <span class="navbar-toggler-icon"></span>
         </button>
         <div class="collapse navbar-collapse navbar" id="navbarSupportedContent">
            <ul class="">
               <li><a class="nav-link scrollto active ps-0" href="/">HOME</a></li>
			    <li class="dropdown">
                  <a href="/isuw-2021" class=" " data-bs-toggle="dropdown"><span>ABOUT ISUW 2021</span> <i class="fa fa-chevron-down"></i></a>
                  <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
				     <li><a href="/isuw-2021">Introduction</a></li>
					 <li><a href="/isuw-2021">Key Highlights</a></li>
					 <li><a href="/isuw-2021">Participating Countries</a></li>
					 <li><a href="/brochure">Brochure 2021</a></li>
                     <li><a href="/isuw-2021">About Organizer</a></li>
					  <li><a href="/isuw-2021">ISUW 2021</a></li>
					  <li><a href="/isgw-post-event-report">ISGW 2020 Post Event Report</a></li>
                  </ul>
               </li>
			     <li class="dropdown">
                  <a href="#" class=" " data-bs-toggle="dropdown"><span>PROGRAMS</span> <i class="fa fa-chevron-down"></i></a>
                  <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                     <li><a href="/conference-themes">Conference Themes</a></li>
                      <li><a href="/conference-agenda-and-program">Conference Agenda and Program</a></li>
                      <li><a href="#">Technical Paper – ISUW 2022</a></li>
                      <li><a href="#">Innovation Awards 2022</a></li>
                  </ul>
               </li>
               <li class="dropdown">
                  <a href="#" class=" " data-bs-toggle="dropdown"><span>PARTNERS</span> <i class="fa fa-chevron-down"></i></a>
                  <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                     <li><a href="/partnership-opportunity-information">Partnership Opportunities</a></li>
                      <li><a href="#">Key Partners</a></li>
                      <li><a href="/supporting-organization">Supporting Organizations</a></li>
                      <li><a href="#">Supporting Ministries</a></li>
                      <li><a href="#">Media and Marketing Partners</a></li>
                      <li><a href="#">Theme And Session Partners</a></li>
                      <li><a href="#">Supporting Utilities</a></li>
                     <li><a href="#">Participating Utilities</a></li>
                     <li><a href="/isuw-participated-utilties">Participated Utilities</a></li>
                  </ul>
               </li>
			 <li class="dropdown">
                  <a href="#" class=" " data-bs-toggle="dropdown"><span>EXHIBITION</span> <i class="fa fa-chevron-down"></i></a>
                  <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                     <li><a href="/exhibition-themes">Exhibition Themes</a></li>
                      <li><a href="/exhibition-package-2021">Exhibition Packages</a></li>
                      <li><a href="#">Exhibition Gallery</a></li>
                      <li><a href="#">Confirmed Exhibitors</a></li>
                  </ul>
               </li>
              
               <li><a class="nav-link scrollto" href="/speakers">SPEAKERS</a></li>
			    
			   <li><a class="nav-link scrollto" href="#">PRESENTATION</a></li>
				   <li class="dropdown">
                  <a href="#" class=" " data-bs-toggle="dropdown"><span>MEDIA</span> <i class="fa fa-chevron-down"></i></a>
                  <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                     <li><a href="https://indiasmartgrid.org/isgfeventgallery.php">Photos</a></li>
					  <li><a href="https://indiasmartgrid.org/isgf_videos.php">Videos</a></li>
					   <li><a href="#">Media Coverage</a></li>
					    <li><a href="#">Press Release</a></li>
                  </ul>
               </li>
               
			   <li class="dropdown">
                  <a href="#" class=" " data-bs-toggle="dropdown"><span>CONTACT US</span> <i class="fa fa-chevron-down"></i></a>
                  <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                     <li><a href="/contact-us">Contact us</a></li>
					 <li><a href="#">Enquiry</a></li>
                  </ul>
               </li>
               <li><a class="getstarted scrollto" href="#">Register Now</a></li>
            </ul> 
            <!-- .navbar -->
         </div>
      </div></header><?php /**PATH C:\xampp\htdocs\isuw\isuw\resources\views/components/header.blade.php ENDPATH**/ ?>