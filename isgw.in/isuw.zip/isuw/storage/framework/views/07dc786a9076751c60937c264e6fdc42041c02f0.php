
<?php $__env->startSection('content'); ?>
 <section class="page-section isuw-testimonies">
         <div class="container">
            <div class="section-title">
               <h2 class="" style="background-color:#4EBC3C;">ISUW TESTIMONIES</h2>
            </div>
            <div class="row justify-content-center ">
               <div class="col-lg-9 happy-client">
                
               <?php $__currentLoopData = $testimonial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <?php if($testimonia->isActive==1): ?>
                   <div class="testimonies-box d-flex">
                     <img src="<?php echo e($testimonia->imageUrl); ?>" class="img-fluid " alt="...">
                     <div class="media-right text-white">
                        <p class="mb-4" style="text-align:justify;"><?php echo e($testimonia->description); ?>

                        </p>
                        <h5><?php echo e($testimonia->name); ?></h5>
                        <p><em><?php echo e($testimonia->comapny); ?></em></p>
                     </div>
                  </div>
               <?php endif; ?>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </div>
            </div>
           </div>
      </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/rkumarisgf/public_html/isgw.in/staging/isuw/resources/views//components/testimonial.blade.php ENDPATH**/ ?>