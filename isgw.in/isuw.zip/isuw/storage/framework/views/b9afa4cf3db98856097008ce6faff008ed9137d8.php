
<?php $__env->startSection('content'); ?>

 <div class="container">
 <div class="row justify-content-left ">
<p></p>
		
<h4 style="color: #f60;">For ISUW 2020 Partnership Opportunity Information and Special Packages for Participation: </h4>
<!--<p><iframe src="http://www.isgw.in/wp-content/uploads/2020/01/For-ISUW-2020-Partnership-Opportunity-Information-and-Special-Packages-for-Participation.pdf" style="width:100%;height:600px;"></iframe><br>
<b>Contact Team ISGF</b><br> -->
<p></p>
<p><b>Kindly Contact Ronkini Shome,</b><br> 
<b>Email us at <a href="mailto:ronkini.shome@indiasmartgrid.org">ronkini.shome@indiasmartgrid.org</a><br>
<b>M:+ +91-11-41057658<br>Please refer ISUW Brochure at following link: <a href="http://localhost:8000/brochure/">http://www.isgw.in/brochure/</a>  </p>
<p></p>

<p></p>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\isuw\isuw\resources\views//components/partnership-opportunity-information.blade.php ENDPATH**/ ?>