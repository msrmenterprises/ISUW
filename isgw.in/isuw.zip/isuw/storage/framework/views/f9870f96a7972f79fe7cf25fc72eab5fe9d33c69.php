<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
  .header_wrapper{
margin: 10px;
  }

.admin_ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
}

.admin_li {
  margin: 10px;
  display: inline;
}
.margin_10{
  margin:10px;
}
.admin_banner_div{
  display:flex;
}
.admin_banner_img{
  width:250px;
}
.admin_banner_div {    flex-flow: row wrap;    height: 250px;
    overflow-y: scroll;}
.container { position: relative; }
.container img { display: block; }
.container .fa-close { position: absolute; top:0; right:0; cursor: pointer;}
</style>
      <title>Admin</title>
    </head>
<body>
<?php echo $__env->make('admin.adminHeader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h1>All Utilities <h3>(To Remove Click :-  <i class="fa fa-close" style="font-size:15px;color:red"></i>)</h3></h1>
<div class="admin_banner_div">
            <?php $__currentLoopData = $utilityimages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($image->isActive==1): ?>
              <div class="container">
                     <img src="<?php echo e($image->imageUrl); ?>" class="admin_banner_img" alt="<?php echo e($image->altText); ?>">
                     <i class="fa fa-close" style="font-size:48px;color:red"></i>
             </div>
                     <?php endif; ?>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <h1>Add New Utility</h1>

<div id="content">
  
  <form method="POST" 
        action="<?php echo e(url('upload-utility')); ?>"
        enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="margin_10">
        Choose Category : <select name="categoryId" id="categoryId">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($category->categoryId); ?>"><?php echo e($category->CategoryName); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
</div><div class="margin_10">
Choose Image : <input type="file" 
             name="uploadfile" 
             id="uploadfile" 
             accept="image/*" />
</div>
<div class="margin_10">
Alt Text :
<input type="text" name="altText" id="altText"  />
</div>
      <div>
          <button type="submit"
                  name="upload">
            UPLOAD
          </button>
      </div>
  </form>
</div>
</body>
</html><?php /**PATH D:\prsnl\Projects\isuw\resources\views/admin/utility.blade.php ENDPATH**/ ?>