

<?php $__env->startSection('content'); ?>

<div class="banner ">
         <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
            <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($banner->displayBanner==1): ?>
            <?php if($loop->first): ?>
               <div class="carousel-item active">
                  <div class="first-div ">
                     <img src="<?php echo e($banner->BannerUrl); ?>" class="d-block w-100" alt="<?php echo e($banner->ImageAltText); ?>">
                  </div>
               </div>
               <?php else: ?>
               <div class="carousel-item">
                  <div class="first-div ">
                     <img src="<?php echo e($banner->BannerUrl); ?>" class="d-block w-100" alt="<?php echo e($banner->ImageAltText); ?>">
                  </div>
               </div>
               <?php endif; ?>
               <?php endif; ?>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
            </button>
         </div>
      </div>
      <section class="page-section key-spoort">
         <div class="container">
            <div class="section-title d-none">
               <h2>About Us</h2>
            </div>
            <div class="row">
               <div class="col-lg-3">
                  <div class="card-box ministry">
                     <h2>Supporting 
                        Ministries 2021
                     </h2>
                     <div class="logo-div"><img src="images/mlogo01.png" class="logo-img " alt="..."></div>
                     <div class="logo-div"><img src="images/mlogo02.png" class="logo-img " alt="..."></div>
                     <div class="logo-div"><img src="images/mlogo03.png" class="logo-img " alt="..."></div>
                     <div class="logo-div"><img src="images/mlogo04.png" class="logo-img " alt="..."></div>
                     <div class="logo-div"><img src="images/mlogo05.png" class="logo-img " alt="..."></div>
                     <div class="logo-div"><img src="images/mlogo06.png" class="logo-img " alt="..."></div>
					 <!--<h2>Thematic Session Partners
                     </h2>
                     <div class="logo-div"><img src="images/mlogo01.png" class="logo-img " alt="..."></div>
					 <div class="logo-div"><img src="images/mlogo01.png" class="logo-img " alt="..."></div>-->
					  <div class="row justify-content-center mt-4">
                       <h2>Thematic Session Partners
                     </h2>
                        <div class="col-lg-8 utilitesSlick slick-initialized slick-slider"><button type="button" class="slick-prev pull-left slick-arrow" style="display: block;"><img src="images/arrow-left2.png"></button>
						<div aria-live="polite" class="slick-list draggable"><div class="slick-track" role="listbox" style="opacity: 1; width: 876px; transform: translate3d(-146px, 0px, 0px);"><div class="logo-div slick-slide slick-cloned" data-slick-index="-1" aria-hidden="true" tabindex="-1" style="width: 116px;"><img src="images/AWS_logo_RGB.png" class="logo-img " alt="..."></div><div class="logo-div slick-slide slick-current slick-active" data-slick-index="0" aria-hidden="false" tabindex="-1" role="option" aria-describedby="slick-slide20" style="width: 116px;"><img src="images/AWS_logo_RGB.png" class="logo-img " alt="..."></div><div class="logo-div slick-slide" data-slick-index="1" aria-hidden="true" tabindex="-1" role="option" aria-describedby="slick-slide21" style="width: 116px;"><img src="images/host04.png" class="logo-img " alt="..."></div><div class="logo-div slick-slide" data-slick-index="2" aria-hidden="true" tabindex="-1" role="option" aria-describedby="slick-slide22" style="width: 116px;"><img src="images/host04.png" class="logo-img " alt="..."></div><div class="logo-div slick-slide" data-slick-index="3" aria-hidden="true" tabindex="-1" role="option" aria-describedby="slick-slide23" style="width: 116px;"><img src="images/host04.png" class="logo-img " alt="..."></div><div class="logo-div slick-slide slick-cloned" data-slick-index="4" aria-hidden="true" tabindex="-1" style="width: 116px;"><img src="images/host04.png" class="logo-img " alt="..."></div></div></div>
				 <button type="button" class="slick-next pull-right slick-arrow" style="display: block;"><img src="images/arrow-right2.png"></button></div>
                     </div>
                  </div>
               </div>
               <div class="col-lg-6">
                  <div class="card-box">
                     <div class="row justify-content-center">
                        <div class="col-lg-3">
                           <div class="spot-div">
                              <a href="#">
                                 <img src="images/spot01.png" class="logo-img " alt="...">
                                 <h3>Mark your 
                                    Calendar
                                 </h3>
                              </a>
                           </div>
                        </div>
                        <div class="col-lg-3">
                           <div class="spot-div">
                              <a href="#">
                                 <img src="images/spot02.png" class="logo-img " alt="...">
                                 <h3>Participation 
                                    Opportunities
                                 </h3>
                              </a>
                           </div>
                        </div>
                        <div class="col-lg-3">
                           <div class="spot-div">
                              <a href="#">
                                 <img src="images/spot03.png" class="logo-img " alt="...">
                                 <h3>Technical 
                                    Papers
                                 </h3>
                              </a>
                           </div>
                        </div>
                        <div class="col-lg-3">
                           <div class="spot-div">
                              <a href="#">
                                 <img src="images/spot04.png" class="logo-img " alt="..." style="height:47px;">
                                 <h3>Innovation 
                                    Awards
                                 </h3>
                              </a>
                           </div>
                        </div>
                     </div>
                     <h2 class="mt-4">Key Partners 2021
                     </h2>
                     <?php $__currentLoopData = $partnercategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <div class="row justify-content-center">
                        <div class="col-lg-12">
                           <div class="logo-title">
                              <h4><?php echo e($pcategory->name); ?></h4>
                           </div>
                        </div>
                        <?php $__currentLoopData = $partnerimages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pimage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($pimage->categoryId==$pcategory->id): ?>
                        <?php if($pimage->isActive==1): ?>
                        <div class="col-lg-3">
                        <div class="logo-div"><img src="<?php echo e($pimage->imageUrl); ?>" class="logo-img " alt="<?php echo e($pimage->altText); ?>"></div>
                        </div>
                    
                     <?php endif; ?>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     
                     
                   
                  </div>
               </div>
               <div class="col-lg-3">
                    <div class="card-box utilities">
                     <div class="row justify-content-center">
                        <div class="col-lg-12">
                           <h2>Supporting Utilities 2021</h2>
                        </div>
                     </div>
                     <?php $__currentLoopData = $utilitycategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					    <div class="row justify-content-center">
						  <div class="col-lg-12">
                           <div class="logo-title">
                              <h4><?php echo e($category->CategoryName); ?></h4>
                           </div>
                        </div>
                        <?php $__currentLoopData = $utilityimages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($image->categoryId==$category->categoryId): ?>
                        <?php if($image->isActive==1): ?>
                        <div class="col-lg-12">
                           <div class="logo-div"><img src="<?php echo e($image->imageUrl); ?>" class="logo-img " alt="<?php echo e($image->altText); ?>"></div>
                        </div>
                        <?php endif; ?>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
					   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
            </div>
         </div>
      </section>
      <section class="page-section isuw-speark">
         <div class="container">
            <div class="section-title pb-0">
			
               <h2 class="text-black" style="background-color:lightgray">ISUW 2021 Speakers</h2>
		
			     <div class="col-lg-12 mb-4 text-end">
                  <a class="btn btn-light" style="margin-top: -32px;" href="/speakers">View All</a>
               </div>
            </div>
            <div class="row justify-content-center ">
               <div class="col-lg-12 responsive slick-initialized slick-slider"><button type="button" class="slick-prev pull-left slick-arrow" style="display: block;"><img src="images/arrow-left.png"></button>
                  <div aria-live="polite" class="slick-list draggable">
                     <div class="slick-track" role="listbox" style="opacity: 1; width: 3627px; transform: translate3d(-1116px, 0px, 0px);">
                     <?php $__currentLoopData = $speakers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $speaker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <?php if($speaker->isActive==1): ?>
           
                     <div class="sprk-box slick-slide slick-cloned" aria-hidden="true"  style="width: 249px;">
                     <img src="<?php echo e($speaker->imageUrl); ?>" class="img-fluid " alt="<?php echo e($speaker->imageAlt); ?>">
                     <h5><?php echo e($speaker->name); ?></h5>
                     <p><?php echo e($speaker->company); ?></p>
                     <p><a href="/speaker/<?php echo e($speaker->id); ?>" class="text-warning" tabindex="-1">Read bio...</a></p>
                  </div>
                  <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </div></div>
                  
                  
                  
                  
               <button type="button" class="slick-next pull-right slick-arrow" style="display: block;"><img src="images/arrow-right.png"></button></div>
            </div>
         </div>
      </section>
      <section class="page-section isuw-exhibitors">
         <div class="container">
            <div class="section-title">
               <h2>ISUW 2021 Exhibitors</h2>
            </div>
            <div class="row justify-content-center ">
            <?php $__currentLoopData = $exhibitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exhibitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <?php if($exhibitor->isActive==1): ?>
            <div class="col-lg-2">
                  <div class="logo-div"><img src="<?php echo e($exhibitor->imageUrl); ?>" class="logo-img " alt="<?php echo e($exhibitor->altText); ?>"></div>
               </div>
               <?php endif; ?>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
         </div>
      </section>
      <section class="page-section isuw-testimonies">
         <div class="container">
            <div class="section-title">
               <h2 class="text-black" style="background-color:#4EBC3C;">ISUW 2021 Testimonies</h2>
            </div>
            <div class="row justify-content-center ">
               <div class="col-lg-9 happy-client slick-initialized slick-slider"><button type="button" class="slick-prev pull-left slick-arrow" style="display: block;"><img src="images/arrow-left.png"></button>
                  <div aria-live="polite" class="slick-list draggable"><div class="slick-track" role="listbox" style="opacity: 1; width: 2912px; transform: translate3d(-832px, 0px, 0px);"><div class="testimonies-box d-flex slick-slide slick-cloned" data-slick-index="-2" aria-hidden="true" tabindex="-1" style="width: 386px;">
                     <img src="images/1.png" class="img-fluid " alt="...">
                     <div class="media-right text-black">
                        <p class="mb-4" style="text-align:justify;">Thank you for having me as a Speaker. The congregation of a wide spectrum of experts from their respective fields and an interchange of ideas on burning topics makes the ISUW a forum to look forward to.
                        </p><h5>Abel Didier Tella</h5>
                        <p><em>Power Utilities of Africa</em></p>
						<!--<a href="#" target="_blank">Read More</a>-->
                     </div>
                  </div><div class="testimonies-box d-flex slick-slide slick-cloned" data-slick-index="-1" aria-hidden="true" tabindex="-1" style="width: 386px;">
                     <img src="images/1.png" class="img-fluid " alt="...">
                     <div class="media-right text-white">
                        <p class="mb-4">Thank you for having me as a Speaker. The congregation of a wide spectrum of experts from their respective fields and an interchange of ideas on burning topics makes the ISUW a forum to look forward to.
                        </p>
                        <h5>Abel Didier Tella</h5>
                        <p><em>Power Utilities of Africa</em></p>
							<!--<a href="#" target="_blank">Read More</a>-->
                     </div>
                  </div><div class="testimonies-box d-flex slick-slide slick-current slick-active" data-slick-index="0" aria-hidden="false" tabindex="-1" role="option" aria-describedby="slick-slide10" style="width: 386px;">
                     <img src="images/1.png" class="img-fluid " alt="...">
                     <div class="media-right text-black">
                        <p class="mb-4" style="text-align:justify;">Thank you for having me as a Speaker. The congregation of a wide spectrum of experts from their respective fields and an interchange of ideas on burning topics makes the ISUW a forum to look forward to...
                        </p>
                        <h5>Abel Didier Tella</h5>
                        <p><em>Power Utilities of Africa</em></p>
							<!--<a href="#" target="_blank">Read More</a>-->
                     </div>
                  </div><div class="testimonies-box d-flex slick-slide slick-cloned" data-slick-index="3" aria-hidden="true" tabindex="-1" style="width: 386px;">
                     <img src="images/1.png" class="img-fluid " alt="...">
                     <div class="media-right text-black">
                        <p class="mb-4" style="text-align:justify;">Thank you for having me as a Speaker. The congregation of a wide spectrum of experts from their respective fields and an interchange of ideas on burning topics makes the ISUW a forum to look forward to...
                        </p>
                        <h5>Abel Didier Tella</h5>
                        <p><em>Power Utilities of Africa</em></p>
							<!--<a href="#" target="_blank">Read More</a>-->
                     </div>
                  </div><div class="testimonies-box d-flex slick-slide slick-cloned" data-slick-index="4" aria-hidden="true" tabindex="-1" style="width: 386px;">
                     <img src="images/1.png" class="img-fluid " alt="...">
                     <div class="media-right text-black">
                        <p class="mb-4" style="text-align:justify;">Thank you for having me as a Speaker. The congregation of a wide spectrum of experts from their respective fields and an interchange of ideas on burning topics makes the ISUW a forum to look forward to.
                        </p><h5>Abel Didier Tella</h5>
                        <p><em>Power Utilities of Africa</em></p>
							<!--<a href="#" target="_blank">Read More</a>-->
                     </div>
                  </div></div></div>
                  
                  
               <button type="button" class="slick-next pull-right slick-arrow" style="display: block;"><img src="images/arrow-right.png"></button></div>
            </div>
         </div>
      </section>
	  <section class="page-section section--three-column">
         <div class="container">
           <div class="section-title">
			 <h2 class="text-black" style="background-color:#F1EBE9">ISUW Key Highlights</h2>
            </div>
            <div class="row justify-content-center ">
			  <div class="col-lg-4">
                <div class="article--stats">
				<div class="article__icon"> 
     <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
    </div>
	<h3 class="article__header__title"> 7 </h3>
	<div class="article__body">
        Editions 
     </div>
				</div>
               </div>
			     <div class="col-lg-4">
                <div class="article--stats">
				<div class="article__icon"> 
     <i class="fa fa-users" aria-hidden="true"></i>
    </div>
	<h3 class="article__header__title"> 12000 </h3>
	<div class="article__body">
        Delegates
     </div>
				</div>
               </div>
			     <div class="col-lg-4">
                <div class="article--stats">
				<div class="article__icon"> 
     <i class="fa fa-volume-up" aria-hidden="true"></i>
    </div>
	<h3 class="article__header__title"> 1700 </h3>
	<div class="article__body">
        Speakers 
     </div>
				</div>
               </div>
			     <div class="col-lg-4">
                <div class="article--stats">
				<div class="article__icon"> 
     <img src="images/exhibitor.png" alt="exhibitor">
    </div>
	<h3 class="article__header__title"> 339 </h3>
	<div class="article__body">
        Exhibitors
     </div>
				</div>
               </div>
               <div class="col-lg-4">
                <div class="article--stats">
				<div class="article__icon"> 
     <i class="fa fa-building" aria-hidden="true"></i> 
    </div>
	<h3 class="article__header__title"> 50+ </h3>
	<div class="article__body">
       Countries
     </div>
				</div>
               </div>
			    <div class="col-lg-4">
                <div class="article--stats">
				<div class="article__icon"> 
     <i class="fa fa-clipboard" aria-hidden="true"></i> 
    </div>
	<h3 class="article__header__title"> 506 </h3>
	<div class="article__body">
       Technical Papers
     </div>
				</div>
               </div>
			    <div class="col-lg-4">
                <div class="article--stats">
				<div class="article__icon"> 
				<img src="images/recognition.png" alt="recognition">
    </div>
	<h3 class="article__header__title"> 179 </h3>
	<div class="article__body">
        Recognitions
     </div>
				</div>
               </div>
               
      
            </div>
         </div>
      </section>
	 	  
	
      <section class="page-section isuw-countdown">
         <div class="container">
            <div class="section-title">
               <h2 class="text-black" style="background-color:#4EBC3C">Countdown to ISUW 2022</h2>
            </div>
			<!--<div class="elementor-widget-container">
<div class="elementor-countdown-wrapper" data-date="1615556460">
<div class="elementor-countdown-item"><span class="elementor-countdown-digits elementor-countdown-days">00</span> <span class="elementor-countdown-label">Days</span></div><div class="elementor-countdown-item"><span class="elementor-countdown-digits elementor-countdown-hours">00</span> <span class="elementor-countdown-label">Hours</span></div><div class="elementor-countdown-item"><span class="elementor-countdown-digits elementor-countdown-minutes">00</span> <span class="elementor-countdown-label">Minutes</span></div><div class="elementor-countdown-item"><span class="elementor-countdown-digits elementor-countdown-seconds">00</span> <span class="elementor-countdown-label">Seconds</span></div> </div>
</div>-->
            <div class="balloon white d-none">
               <div class="star"></div>
               <div class="face">
                  <div class="eye"></div>
                  <div class="mouth happy"></div>
               </div>
               <div class="triangle"></div>
               <div class="string"></div>
            </div>
            <div class="balloon white d-none">
               <div class="star"></div>
               <div class="face">
                  <div class="eye"></div>
                  <div class="mouth happy"></div> 
               </div>
               <div class="triangle"></div>
               <div class="string"></div>
            </div>
            <div class="balloon white d-none">
               <div class="star"></div>
               <div class="face">
                  <div class="eye"></div>
                  <div class="mouth happy"></div>
               </div>
               <div class="triangle"></div>
               <div class="string"></div>
            </div>
            <div id="timer"><div class="days">            <div class="numbers">59</div>days</div>          <div class="hours">            <div class="numbers">10</div>hours</div>          <div class="minutes">            <div class="numbers">49</div>minutes</div>          <div class="seconds">            <div class="numbers">3</div>seconds</div>          </div>
         </div>
      </section>
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\isuw\isuw\resources\views/components/home.blade.php ENDPATH**/ ?>