
<?php $__env->startSection('content'); ?>

 <div class="container">
 <div class="row justify-content-left ">
<p></p>


<h2 style="color: #f60;margin-left: 55px;">ISUW 2021 Brochure</h2>
<iframe src="http://localhost:8000/uploads/images/Final-Brochure-ISUW-2021-1.pdf" height="600" width="150" title="Iframe Example" style="
    width: 800px;
    text-align: center;
    margin-left: 67px;
"></iframe>

<p></p>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\isuw\isuw\resources\views//components/brochure.blade.php ENDPATH**/ ?>