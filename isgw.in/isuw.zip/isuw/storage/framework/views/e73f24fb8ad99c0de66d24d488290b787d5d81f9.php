
<?php $__env->startSection('content'); ?>

 <div class="container">
 <div class="row justify-content-left ">
<p></p>

<style type="text/css">.diff_ss1{margin-left:30px;}</style>

<h3 style="color: #f60; ">India Smart Utility Week (SUW 2021) </h3>

<h5 style="text-align: center;"><FONT COLOR="#00b050"><B>ISUW
2021: CONFERENCE THEMATIC SESSIONS</B></FONT></h5>


<TABLE style="width:90%;">
	
	<TR VALIGN=TOP>
		<TD   BGCOLOR="#ed7d31" STYLE="border: 1px solid #ed7d31; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P LANG="en-IN" ALIGN=CENTER><B><FONT COLOR="#000000"><FONT SIZE=3>S/N</FONT></FONT></B></P>
		</TD>
		<TD  BGCOLOR="#ed7d31" STYLE="border: 1px solid #ed7d31; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P LANG="en-IN" ALIGN=CENTER><B><FONT COLOR="#000000"><FONT SIZE=3>Sessions</FONT></FONT></B></P>
		</TD>
		<TD  BGCOLOR="#ed7d31" STYLE="border: 1px solid #ed7d31; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P LANG="en-IN" ALIGN=CENTER><B><FONT COLOR="#000000"><FONT SIZE=3>Time
			(India)</FONT></FONT></B></P>
		</TD>
	</TR>
	<TR>
		<TD COLSPAN=3   VALIGN=TOP BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<H1 CLASS="western" STYLE="margin-top: 0in"><B><FONT COLOR="#000000"><FONT FACE="Calibri, serif"><FONT SIZE=3><SPAN LANG="en-GB">2ND
			MARCH 2021 (TUESDAY) - DAY 1</SPAN></FONT></FONT></FONT></B></H1>
		</TD>
	</TR>
	<TR VALIGN=TOP>
		<TD   STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<OL TYPE=i>
				<LI><P LANG="en-IN" ALIGN=CENTER></P>
			</OL>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT SIZE=3><SPAN LANG="en-GB"><B>Session - 1: Innovation in
			Utilities During the Pandemic</B></SPAN></FONT></P>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P LANG="en-IN"><FONT SIZE=3><B>14:00 ~ 16:00</B></FONT></P>
		</TD>
	</TR>
	<TR VALIGN=TOP>
		<TD  BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<OL TYPE=i START=2>
				<LI><P LANG="en-IN" ALIGN=CENTER></P>
			</OL>
		</TD>
		<TD  BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT SIZE=3><SPAN LANG="en-GB"><B>Session - 2: Regulatory
			Support in Different Countries for Revival of Utilities</B></SPAN></FONT></P>
		</TD>
		<TD  BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P LANG="en-IN"><FONT SIZE=3><B>16:00 ~ 18:00</B></FONT></P>
		</TD>
	</TR>
	<TR VALIGN=TOP>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<OL TYPE=i START=3>
				<LI><P LANG="en-IN" ALIGN=CENTER></P>
			</OL>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT SIZE=3><SPAN LANG="en-GB"><B>Special Plenary - 1:
			Customer Rights Protection Order by Ministry of Power – Action
			by Utilities and Regulators</B></SPAN></FONT></P>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P LANG="en-IN"><FONT SIZE=3><B>19:00 ~ 21:00</B></FONT></P>
		</TD>
	</TR>
	<TR>
		<TD COLSPAN=3   VALIGN=TOP BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<H1 CLASS="western" STYLE="margin-top: 0in"><B><FONT COLOR="#000000"><FONT FACE="Calibri, serif"><FONT SIZE=3><SPAN LANG="en-GB">3RD
			MARCH 2021 (WEDNESDAY) - DAY 2</SPAN></FONT></FONT></FONT></B></H1>
		</TD>
	</TR>
	<TR VALIGN=TOP>
		<TD   STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<OL TYPE=i>
				<LI><P LANG="en-IN"></P>
			</OL>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT SIZE=3><SPAN LANG="en-GB"><B>Session - 3: Smart Meter
			Rollout in India </B></SPAN></FONT>
			</P>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P LANG="en-IN"><FONT SIZE=3><B>11:30 ~ 13:30</B></FONT></P>
		</TD>
	</TR>
	<TR VALIGN=TOP>
		<TD  BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<OL TYPE=i START=2>
				<LI><P LANG="en-IN"></P>
			</OL>
		</TD>
		<TD  BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT SIZE=3><SPAN LANG="en-GB"><B>Session - 4:  Energy Storage
			Systems – Technologies, Business Models and Regulations</B></SPAN></FONT></P>
		</TD>
		<TD  BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P LANG="en-IN"><FONT SIZE=3><B>14:00 ~ 16:00</B></FONT></P>
		</TD>
	</TR>
	<TR VALIGN=TOP>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<OL TYPE=i START=3>
				<LI><P LANG="en-IN"></P>
			</OL>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT SIZE=3><SPAN LANG="en-GB"><B>Session - 5: Disaster (and
			Pandemic) Resilient Utilities and Cities (In partnership with
			NIUA)</B></SPAN></FONT></P>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P LANG="en-IN"><FONT SIZE=3><B>16:00 ~ 18:00</B></FONT></P>
		</TD>
	</TR>
	<TR>
		<TD COLSPAN=3   VALIGN=TOP BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<H1 CLASS="western" STYLE="margin-top: 0in"><B><FONT COLOR="#000000"><FONT FACE="Calibri, serif"><FONT SIZE=3><SPAN LANG="en-GB">4TH
			MARCH 2021 (THURSDAY) - DAY 3</SPAN></FONT></FONT></FONT></B></H1>
		</TD>
	</TR>
	<TR VALIGN=TOP>
		<TD   STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<OL TYPE=i>
				<LI><P LANG="en-IN"></P>
			</OL>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT SIZE=3><SPAN LANG="en-GB"><B>Session - 6: Cyber Security
			for Digital Utilities</B></SPAN></FONT></P>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT SIZE=3><SPAN LANG="en-GB"><B>11:30 ~ 13:30</B></SPAN></FONT></P>
		</TD>
	</TR>
	<TR VALIGN=TOP>
		<TD   BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<OL TYPE=i START=2>
				<LI><P LANG="en-IN"></P>
			</OL>
		</TD>
		<TD  BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT SIZE=3><SPAN LANG="en-GB"><B>Session - 7: Disruptive
			Technologies and Innovations for Utilities: Part - A</B></SPAN></FONT></P>
		</TD>
		<TD  BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT SIZE=3><SPAN LANG="en-GB"><B>14:00 ~ 16:00</B></SPAN></FONT></P>
		</TD>
	</TR>
	<TR VALIGN=TOP>
		<TD   STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<OL TYPE=i START=3>
				<LI><P LANG="en-IN"></P>
			</OL>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT SIZE=3><SPAN LANG="en-GB"><B>Session - 8: New Revenue
			Opportunities For Utilities</B></SPAN></FONT></P>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT SIZE=3><SPAN LANG="en-GB"><B>16:00 ~ 18:00</B></SPAN></FONT></P>
		</TD>
	</TR>
	<TR VALIGN=TOP>
		<TD   BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<OL TYPE=i START=4>
				<LI><P LANG="en-IN"></P>
			</OL>
		</TD>
		<TD  BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT SIZE=3><SPAN LANG="en-GB"><B>Special Plenary - 2: Grid
			Integrated Vehicles (GIV) and Standards for GIVs</B></SPAN></FONT></P>
		</TD>
		<TD  BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT SIZE=3><SPAN LANG="en-GB"><B>19:00 ~ 21:00</B></SPAN></FONT></P>
		</TD>
	</TR>
	<TR>
		<TD COLSPAN=3   VALIGN=TOP STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<H1 CLASS="western" STYLE="margin-top: 0in"><B><FONT COLOR="#00000a"><FONT FACE="Calibri, serif"><FONT SIZE=3><SPAN LANG="en-GB">5TH
			MARCH 2021 (FRIDAY) - DAY 4</SPAN></FONT></FONT></FONT></B></H1>
		</TD>
	</TR>
	<TR VALIGN=TOP>
		<TD   BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<OL TYPE=i>
				<LI><P LANG="en-IN"></P>
			</OL>
		</TD>
		<TD  BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT SIZE=3><SPAN LANG="en-GB"><B>Session - 9: Disruptive
			Technologies and Innovations for Utilities: Part-B</B></SPAN></FONT></P>
		</TD>
		<TD  BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P LANG="en-IN"><FONT SIZE=3><B>11:30~13:30</B></FONT></P>
		</TD>
	</TR>
</TABLE>
<br><br>
<H1 CLASS="western" ALIGN=CENTER STYLE="margin-top: 0in; line-height: 100%">
<FONT COLOR="#000000"><FONT FACE="Calibri, serif"><FONT SIZE=5><SPAN LANG="en-GB"><B>ISUW
2021: WORKSHOPS, SEMINARS AND ROUNDTABLES</B></SPAN></FONT></FONT></FONT></H1>
<P LANG="en-GB" STYLE="margin-bottom: 0in; line-height: 100%"><BR>
</P>
<TABLE style="width:90%;">
	
	<TR VALIGN=TOP>
		<TD   BGCOLOR="#ed7d31" STYLE="border: 1px solid #ed7d31; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P LANG="en-IN" ALIGN=CENTER><B><FONT COLOR="#000000"><FONT SIZE=3>S/N</FONT></FONT></B></P>
		</TD>
		<TD  BGCOLOR="#ed7d31" STYLE="border: 1px solid #ed7d31; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P LANG="en-IN" ALIGN=CENTER><B><FONT COLOR="#000000"><FONT SIZE=3>Theme</FONT></FONT></B></P>
		</TD>
		<TD  BGCOLOR="#ed7d31" STYLE="border: 1px solid #ed7d31; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P LANG="en-IN" ALIGN=CENTER><B><FONT COLOR="#000000"><FONT SIZE=3>Date</FONT></FONT></B></P>
		</TD>
		<TD  BGCOLOR="#ed7d31" STYLE="border: 1px solid #ed7d31; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P LANG="en-IN" ALIGN=CENTER><B><FONT COLOR="#000000"><FONT SIZE=3>Time
			(India)</FONT></FONT></B></P>
		</TD>
	</TR>
	<TR>
		<TD COLSPAN=4   VALIGN=TOP BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<H1 CLASS="western" STYLE="margin-top: 0in"><B><FONT COLOR="#000000"><FONT FACE="Calibri, serif"><FONT SIZE=3><SPAN LANG="en-GB">WORKSHOPS</SPAN></FONT></FONT></FONT></B></H1>
		</TD>
	</TR>
	<TR VALIGN=TOP>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<OL TYPE=i>
				<LI><P LANG="en-IN"></P>
			</OL>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT FACE="Calibri, serif"><FONT SIZE=2><FONT COLOR="#000000"><FONT FACE="Calibri, serif"><FONT SIZE=3><SPAN LANG="en-GB"><B>10</B></SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><SUP><FONT FACE="Calibri, serif"><FONT SIZE=3><SPAN LANG="en-GB"><B>th</B></SPAN></FONT></FONT></SUP></FONT><FONT COLOR="#000000"><FONT FACE="Calibri, serif"><FONT SIZE=3><SPAN LANG="en-GB"><B>
			EU - INDIA Smart Grid Workshop – Part A (In partnership with EU)</B></SPAN></FONT></FONT></FONT></FONT></FONT></P>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P LANG="en-IN"><FONT SIZE=3><B>02 March 2021 (Tue)</B></FONT></P>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P LANG="en-IN"><FONT SIZE=3><B>14:30~16:00</B></FONT></P>
		</TD>
	</TR>
	<TR VALIGN=TOP>
		<TD  BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<OL TYPE=i START=2>
				<LI><P LANG="en-IN"></P>
			</OL>
		</TD>
		<TD  BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT COLOR="#000000"><FONT SIZE=3><SPAN LANG="en-GB"><B>5G for
			Smart Utilities and Smart Cities (In partnership with TSDSI)</B></SPAN></FONT></FONT></P>
		</TD>
		<TD  BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P LANG="en-IN"><FONT SIZE=3><B>03 March 2021 (Wed)</B></FONT></P>
		</TD>
		<TD  BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT SIZE=3><SPAN LANG="en-GB"><B>11:00~13:00</B></SPAN></FONT></P>
		</TD>
	</TR>
	<TR VALIGN=TOP>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<OL TYPE=i START=3>
				<LI><P LANG="en-IN"></P>
			</OL>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT FACE="Calibri, serif"><FONT SIZE=2><FONT COLOR="#000000"><FONT FACE="Calibri, serif"><FONT SIZE=3><SPAN LANG="en-GB"><B>10</B></SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><SUP><FONT FACE="Calibri, serif"><FONT SIZE=3><SPAN LANG="en-GB"><B>th</B></SPAN></FONT></FONT></SUP></FONT><FONT COLOR="#000000"><FONT FACE="Calibri, serif"><FONT SIZE=3><SPAN LANG="en-GB"><B>
			EU - INDIA Smart Grid Workshop – Part B (In partnership with EU)</B></SPAN></FONT></FONT></FONT></FONT></FONT></P>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P LANG="en-IN"><FONT SIZE=3><B>03 March 2021 (Wed)</B></FONT></P>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P LANG="en-IN"><FONT SIZE=3><B>14:00~17:00</B></FONT></P>
		</TD>
	</TR>
	<TR VALIGN=TOP>
		<TD  BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<OL TYPE=i START=4>
				<LI><P LANG="en-IN"></P>
			</OL>
		</TD>
		<TD  BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT FACE="Calibri, serif"><FONT SIZE=2><FONT COLOR="#000000"><FONT FACE="Calibri, serif"><FONT SIZE=3><SPAN LANG="en-GB"><B>7</B></SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><SUP><FONT FACE="Calibri, serif"><FONT SIZE=3><SPAN LANG="en-GB"><B>th</B></SPAN></FONT></FONT></SUP></FONT><FONT COLOR="#000000"><FONT FACE="Calibri, serif"><FONT SIZE=3><SPAN LANG="en-GB"><B>
			US - INDIA Smart Grid Workshop (In partnership with US Commercial
			Services; US DoE; and USIBC)</B></SPAN></FONT></FONT></FONT></FONT></FONT></P>
		</TD>
		<TD  BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P LANG="en-IN"><FONT SIZE=3><B>03 March 2021 (Wed)</B></FONT></P>
		</TD>
		<TD  BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P LANG="en-IN"><FONT SIZE=3><B>18:00~21:30</B></FONT></P>
		</TD>
	</TR>
	<TR VALIGN=TOP>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<OL TYPE=i START=5>
				<LI><P LANG="en-IN"></P>
			</OL>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT COLOR="#000000"><FONT SIZE=3><SPAN LANG="en-GB"><B>Workshop
			on District Cooling Systems (In partnership with APUEA)</B></SPAN></FONT></FONT></P>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P LANG="en-IN"><FONT SIZE=3><B>04 March 2021 (Thur)</B></FONT></P>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT SIZE=3><SPAN LANG="en-GB"><B>11:00~13:30</B></SPAN></FONT></P>
		</TD>
	</TR>
	<TR VALIGN=TOP>
		<TD  BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<OL TYPE=i START=6>
				<LI><P LANG="en-IN"></P>
			</OL>
		</TD>
		<TD  BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT FACE="Calibri, serif"><FONT SIZE=2><FONT COLOR="#000000"><FONT FACE="Calibri, serif"><FONT SIZE=3><SPAN LANG="en-GB"><B>5</B></SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><SUP><FONT FACE="Calibri, serif"><FONT SIZE=3><SPAN LANG="en-GB"><B>th</B></SPAN></FONT></FONT></SUP></FONT><FONT COLOR="#000000"><FONT FACE="Calibri, serif"><FONT SIZE=3><SPAN LANG="en-GB"><B>
			SWEDEN - INDIA Smart Grid Workshop (In partnership with DST and
			SEA, and Business Sweden)</B></SPAN></FONT></FONT></FONT></FONT></FONT></P>
		</TD>
		<TD  BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P LANG="en-IN"><FONT SIZE=3><B>04 March 2021 (Thur)</B></FONT></P>
		</TD>
		<TD  BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P LANG="en-IN"><FONT SIZE=3><B>14:30~17:30</B></FONT></P>
		</TD>
	</TR>
	<TR VALIGN=TOP>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<OL TYPE=i START=7>
				<LI><P LANG="en-IN"></P>
			</OL>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT COLOR="#000000"><FONT SIZE=3><SPAN LANG="en-GB"><B>Workshop
			on Live Line Maintenance in Utilities</B></SPAN></FONT></FONT></P>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P LANG="en-IN"><FONT SIZE=3><B>05 March 2021 (Fri)</B></FONT></P>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT SIZE=3><SPAN LANG="en-GB"><B>10:00~13:00</B></SPAN></FONT></P>
		</TD>
	</TR>
	<TR>
		<TD COLSPAN=4   VALIGN=TOP BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<H1 CLASS="western" STYLE="margin-top: 0in"><B><FONT COLOR="#000000"><FONT FACE="Calibri, serif"><FONT SIZE=3><SPAN LANG="en-GB">SEMINARS</SPAN></FONT></FONT></FONT></B></H1>
		</TD>
	</TR>
	<TR VALIGN=TOP>
		<TD   STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<OL TYPE=i>
				<LI><P LANG="en-IN" ALIGN=JUSTIFY></P>
			</OL>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT COLOR="#000000"><FONT SIZE=3><SPAN LANG="en-GB"><B>Presentation
			of Select Technical Papers: Part - 1</B></SPAN></FONT></FONT></P>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P LANG="en-IN"><FONT SIZE=3><B>02 March 2021 (Tue)</B></FONT></P>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT SIZE=3><SPAN LANG="en-GB"><B>14:00~18:00</B></SPAN></FONT></P>
		</TD>
	</TR>
	<TR VALIGN=TOP>
		<TD   BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<OL TYPE=i START=2>
				<LI><P LANG="en-IN" ALIGN=JUSTIFY></P>
			</OL>
		</TD>
		<TD  BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT COLOR="#000000"><FONT SIZE=3><SPAN LANG="en-GB"><B>Smart
			Water Distribution</B></SPAN></FONT></FONT></P>
		</TD>
		<TD  BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P LANG="en-IN"><FONT SIZE=3><B>03 March 2021 (Wed)</B></FONT></P>
		</TD>
		<TD  BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT SIZE=3><SPAN LANG="en-GB"><B>11:30~13:30</B></SPAN></FONT></P>
		</TD>
	</TR>
	<TR VALIGN=TOP>
		<TD   STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<OL TYPE=i START=3>
				<LI><P LANG="en-IN" ALIGN=JUSTIFY></P>
			</OL>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT COLOR="#000000"><FONT SIZE=3><SPAN LANG="en-GB"><B>IEC –
			IEEE World Smart Energy Standardization Coordination Workshop</B></SPAN></FONT></FONT></P>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P LANG="en-IN"><FONT SIZE=3><B>03 March 2021 (Wed)</B></FONT></P>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT SIZE=3><SPAN LANG="en-GB"><B>14:00~17:30</B></SPAN></FONT></P>
		</TD>
	</TR>
	<TR VALIGN=TOP>
		<TD   BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<OL TYPE=i START=4>
				<LI><P LANG="en-IN" ALIGN=JUSTIFY></P>
			</OL>
		</TD>
		<TD  BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT COLOR="#000000"><FONT SIZE=3><SPAN LANG="en-GB"><B>Smart
			City Gas Distribution and Green Hydrogen</B></SPAN></FONT></FONT></P>
		</TD>
		<TD  BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P LANG="en-IN"><FONT SIZE=3><B>04 March 2021 (Thur)</B></FONT></P>
		</TD>
		<TD  BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT SIZE=3><SPAN LANG="en-GB"><B>14:00~18:00</B></SPAN></FONT></P>
		</TD>
	</TR>
	<TR VALIGN=TOP>
		<TD   STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<OL TYPE=i START=5>
				<LI><P LANG="en-IN" ALIGN=JUSTIFY></P>
			</OL>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT COLOR="#000000"><FONT SIZE=3><SPAN LANG="en-GB"><B>Presentation
			of Select Technical Papers: Part - 2</B></SPAN></FONT></FONT></P>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P LANG="en-IN"><FONT SIZE=3><B>05 March 2021 (Fri)</B></FONT></P>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT SIZE=3><SPAN LANG="en-GB"><B>11:30~13:30</B></SPAN></FONT></P>
		</TD>
	</TR>
	<TR>
		<TD COLSPAN=4   VALIGN=TOP BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><B><FONT COLOR="#000000"><FONT SIZE=3><SPAN LANG="en-GB">ROUNDTABLES</SPAN></FONT></FONT></B></P>
		</TD>
	</TR>
	<TR VALIGN=TOP>
		<TD   STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<OL TYPE=i>
				<LI><P LANG="en-IN"></P>
			</OL>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT COLOR="#000000"><FONT SIZE=3><SPAN LANG="en-GB"><B>Roundtable
			- 1: Interconnection of Regional Grids in Asia</B></SPAN></FONT></FONT></P>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P LANG="en-IN"><FONT SIZE=3><B>02 March 2021 (Tue)</B></FONT></P>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT SIZE=3><SPAN LANG="en-GB"><B>15:00~18:00</B></SPAN></FONT></P>
		</TD>
	</TR>
	<TR VALIGN=TOP>
		<TD   BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<OL TYPE=i START=2>
				<LI><P LANG="en-IN"></P>
			</OL>
		</TD>
		<TD  BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT COLOR="#000000"><FONT SIZE=3><SPAN LANG="en-GB"><B>Roundtable
			- 2: Electric Cooking</B></SPAN></FONT></FONT></P>
		</TD>
		<TD  BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P LANG="en-IN"><FONT SIZE=3><B>03 March 2021 (Wed)</B></FONT></P>
		</TD>
		<TD  BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P LANG="en-IN"><FONT SIZE=3><B>11:30~13:30</B></FONT></P>
		</TD>
	</TR>
	<TR VALIGN=TOP>
		<TD   STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<OL TYPE=i START=3>
				<LI><P LANG="en-IN"></P>
			</OL>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT COLOR="#000000"><FONT SIZE=3><SPAN LANG="en-GB"><B>Roundtable
			- 3: Digital Architecture and System Integration for Smart
			Metering (Powered by Amazon Web Services &amp; in Partnership with
			NISG)</B></SPAN></FONT></FONT></P>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P LANG="en-IN"><FONT SIZE=3><B>03 March 2021 (Wed)</B></FONT></P>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT SIZE=3><SPAN LANG="en-GB"><B>14:00~17:00</B></SPAN></FONT></P>
		</TD>
	</TR>
	<TR VALIGN=TOP>
		<TD   BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<OL TYPE=i START=4>
				<LI><P LANG="en-IN"></P>
			</OL>
		</TD>
		<TD  BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT COLOR="#000000"><FONT SIZE=3><SPAN LANG="en-GB"><B>Roundtable
			- 4: Urban Air Mobility Systems (UAM)</B></SPAN></FONT></FONT></P>
		</TD>
		<TD  BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P LANG="en-IN"><FONT SIZE=3><B>04 March 2021 (Thur)</B></FONT></P>
		</TD>
		<TD  BGCOLOR="#fbe4d5" STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT SIZE=3><SPAN LANG="en-GB"><B>11:30~13:30</B></SPAN></FONT></P>
		</TD>
	</TR>
	<TR VALIGN=TOP>
		<TD   STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<OL TYPE=i START=5>
				<LI><P LANG="en-IN"></P>
			</OL>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT COLOR="#000000"><FONT SIZE=3><SPAN LANG="en-GB"><B>Roundtable
			- 5: Blockchain Applications in Energy Sector</B></SPAN></FONT></FONT></P>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P LANG="en-IN"><FONT SIZE=3><B>04 March 2021 (Thur)</B></FONT></P>
		</TD>
		<TD  STYLE="border: 1px solid #f4b083; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0.08in">
			<P><FONT SIZE=3><SPAN LANG="en-GB"><B>14:00~17:30</B></SPAN></FONT></P>
		</TD>
	</TR>
</TABLE>


<p></p>

<FONT COLOR="#f60"><B>For
ISUW 2021 detailed Agenda and Program:</B></FONT><BR></FONT></FONT>
<B>Kindly visit following link-</B><B><a href="http://localhost:8000/conference-agenda-and-program">http://www.isgw.in/conference-agenda-and-program/</a></B></P>


<p></p>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\isuw\isuw\resources\views//components/conference-themes.blade.php ENDPATH**/ ?>