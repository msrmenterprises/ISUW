﻿

function formValidation() {

    getDateTime();

    if (document.forms[0].elements.txtccnumber.value == "") {
        alert("Please enter Credit Card Number");
        return false;
    }
    else if (document.forms[0].elements.ddlmonth.value == "MM" || document.forms[0].elements.ddlyear.value == "YYYY") {
        alert("Please Select expires");
        return false;
    }
    else if (document.forms[0].elements.txtcvv.value == "") {
        alert("Please enter CVV Number");
        return false;
    }
    else if (document.forms[0].elements.txtfirstname.value == "") {
        alert("Please Enter from Credit Card Holder's First Name");
        document.forms[0].elements.txtfirstname.focus();
        return false;
    }
    else if (document.forms[0].elements.txtlastname.value == "") {
        alert("Please Enter from Credit Card Holder's Last Name");
        document.forms[0].elements.txtlastname.focus();
        return false;
    }
    else if (document.forms[0].elements.txtaddress1.value == "") {
        alert("Please Enter Address");
        document.forms[0].elements.txtaddress1.focus();
        return false;
    }
    else if (document.forms[0].elements.txtcity.value == "") {
        alert("Please Enter City");
        document.forms[0].elements.txtcity.focus();
        return false;
    }
    else if (document.forms[0].elements.txtzip.value == "") {
        alert("Please Enter Zip Code");
        document.forms[0].elements.txtzip.focus();
        return false;
    }
    else if (document.forms[0].elements.txtphone.value == "") {
        alert("Please Enter Phone");
        document.forms[0].elements.txtphone.focus();
        return false;
    }    
    else if (!PhoneCheck()) {
        return false;
    }    
    else if (!PhoneCheck2()) {
        return false;
    }
    else if (!ZipCheck()) {
        return false;
    }
    else if (document.forms[0].elements.txtemail.value == "") {
        alert("Please Enter Email");
        document.forms[0].elements.txtemail.focus();
        return false;
    }
    else if (!EmailCheck()) {
        return false;
    }
 }

 function formValidation1() {

     getDateTime();

     if (document.forms[0].elements.txtccnumber.value == "") {
         alert("Please enter Credit Card Number");
         return false;
     }
     else if (document.forms[0].elements.ddlmonth.value == "MM" || document.forms[0].elements.ddlyear.value == "YYYY") {
         alert("Please Select expires");
         return false;
     }
     else if (document.forms[0].elements.txtcvv.value == "") {
         alert("Please enter CVV Number");
         return false;
     }
     else if (document.forms[0].elements.txtfirstname.value == "") {
         alert("Please Enter from Credit Card Holder's First Name");
         document.forms[0].elements.txtfirstname.focus();
         return false;
     }
     else if (document.forms[0].elements.txtlastname.value == "") {
         alert("Please Enter from Credit Card Holder's Last Name");
         document.forms[0].elements.txtlastname.focus();
         return false;
     }
     else if (document.forms[0].elements.txtaddress1.value == "") {
         alert("Please Enter Address");
         document.forms[0].elements.txtaddress1.focus();
         return false;
     }
     else if (document.forms[0].elements.txtcity.value == "") {
         alert("Please Enter City");
         document.forms[0].elements.txtcity.focus();
         return false;
     }
     else if (document.forms[0].elements.ddlstate.value == "Other" & document.forms[0].elements.txtState.value.trim() == '') {
         alert("Please Enter State");
         document.forms[0].elements.txtState.focus();
         return false;
     }
     else if (document.forms[0].elements.txtzip.value == "") {
         alert("Please Enter Zip Code");
         document.forms[0].elements.txtzip.focus();
         return false;
     }
     else if (document.forms[0].elements.txtphone.value == "") {
         alert("Please Enter Phone");
         document.forms[0].elements.txtphone.focus();
         return false;
     }
     else if (!PhoneCheck()) {
         return false;
     }
     else if (!PhoneCheck2()) {
         return false;
     }
     else if (!ZipCheck()) {
         return false;
     }
     else if (document.forms[0].elements.txtemail.value == "") {
         alert("Please Enter Email");
         document.forms[0].elements.txtemail.focus();
         return false;
     }
     else if (!EmailCheck()) {
         return false;
     }
 }

 function PhoneCheck() {

     var regx = /^\d{3}-\d{3}-\d{4}/;
     if (document.forms[0].elements.txtphone.value != "") {
         if (!regx.test(document.forms[0].elements.txtphone.value)) {
             alert("Please Enter Valid Phone Number");
             document.forms[0].elements.txtphone.value = "";
             document.forms[0].elements.txtphone.focus();
             return false;
         }
         else {
             return true;
         }
     }     
 }

 function PhoneCheck2() {

     var regx = /^\d{3}-\d{3}-\d{4}/;
     if (document.forms[0].elements.txtphone2.value != "") {
         if (!regx.test(document.forms[0].elements.txtphone2.value)) {
             alert("Please Enter Valid Alternate Phone Number");
             document.forms[0].elements.txtphone2.value = "";
             document.forms[0].elements.txtphone2.focus();
             return false;
         }
         else {
             return true;
         }
     }
     else {
         return true;
     }
 }

 function ZipCheck() {

     var regx = /^\d{5}/;
     if (!regx.test(document.forms[0].elements.txtzip.value)) {
         alert("Please Enter Valid Zip Code");
         document.forms[0].elements.txtzip.value = "";
         document.forms[0].elements.txtzip.focus();
         return false;
     }
     else {
         return true;
     }
 }


 function EmailCheck() {

     //var regx = /^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}/;
     var regx = /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*/;
     if (!regx.test(document.forms[0].elements.txtemail.value)) {
         alert("Please Enter Valid Email");
         document.forms[0].elements.txtemail.focus();
         return false;
     }
     else {
         return true;
     }
 }

 function getDateTime() {
     var now = new Date();
     var strDateTime = [[now.getFullYear(), AddZero(now.getMonth() + 1), AddZero(now.getDate())].join("-"), [AddZero(now.getHours()), AddZero(now.getMinutes()), "00"].join(":")].join(" ");
     document.forms[0].elements.hFieldDT.value = strDateTime;     
 }

 function AddZero(num) {
     return (num >= 0 && num < 10) ? "0" + num : num + "";
 } 