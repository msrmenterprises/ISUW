	 $(function(){
var url = window.location.href; 
$("header ul  li a").each(function() {
    if(url == (this.href)) { 
        $(this).closest("a").addClass("hover");
    }
});
$("section ul  li a").each(function() {
    if(url == (this.href)) { 
        $(this).closest("a").addClass("hover");
    }
});
$("footer p a").each(function() {
    if(url == (this.href)) { 
        $(this).closest("a").addClass("hover");
    }
});
$( ".seals" ).replaceWith( "<div id='vdowrap'></div>" );
});